#!/usr/bin/env bash
# Hadron Sync – Installer (Autor: Dennis Peteranderl <hadron.unfreeze611@passmail.net>)
# Installiert bzw. aktualisiert die offizielle Proton Drive CLI (aktuelle Version aus Protons
# Download-Index, mit SHA-512-Pruefung) und das Werkzeug Hadron Sync fuer den aktuellen Benutzer.
# Erneut ausfuehren = aktualisieren. Einstellungen und Sync-Stand bleiben erhalten.
# Inoffizielles, privates, nicht-kommerzielles Projekt; mithilfe von Claude und Mistral AI erstellt.
# Installation und Nutzung auf eigenes Risiko.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INDEX_URL="${HADRON_SYNC_INDEX_URL:-https://proton.me/download/drive/cli/index.html}"
DOWNLOAD_PREFIX="https://proton.me/download/drive/cli/"
DOWNLOAD_REWRITE="${HADRON_SYNC_DOWNLOAD_REWRITE:-}"   # nur fuer Tests
APP_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/hadron-sync"
USER_BIN="$HOME/.local/bin"
SYSTEM_BIN="/usr/local/bin"

OPT_USER=0; OPT_DEPS=1; OPT_CLI=1; OPT_YES=0; OPT_LOGIN=1; OPT_START=1; OPT_FORCE=0; OPT_AUTOSTART=""

CONTACT="hadron.unfreeze611@passmail.net"
case "${LANGUAGE:-${LC_ALL:-${LC_MESSAGES:-${LANG:-}}}}" in
    de*) UI=de ;; es*) UI=es ;; fr*) UI=fr ;; *) UI=en ;;
esac
# shellcheck source=messages.sh
. "$SCRIPT_DIR/messages.sh"

msg() {  # msg SCHLUESSEL [printf-Argumente]
    local key="M_${1}_${UI}" fallback="M_${1}_en"
    local fmt="${!key:-${!fallback:-$1}}"
    shift
    # shellcheck disable=SC2059
    printf "$fmt\n" "$@"
}
raw() { local key="M_${1}_${UI}" fallback="M_${1}_en"; local fmt="${!key:-${!fallback:-$1}}"; shift; printf "$fmt" "$@"; }
say()  { msg "$@"; }
info() { printf '\033[1;34m==>\033[0m '; msg "$@"; }
warn() { printf '\033[1;33m[!]\033[0m ' >&2; msg "$@" >&2; }
die()  { printf '\033[1;31m[x]\033[0m ' >&2; msg "$@" >&2; exit 1; }
ask()  {  # ask SCHLUESSEL [printf-Argumente] -> 0 = ja
    [ "$OPT_YES" = 1 ] && return 0
    [ -t 0 ] || return 1
    local a; read -r -p "$(raw "$@")" a
    case "${a,,}" in ""|j|ja|y|yes|s|si|sí|o|oui) return 0 ;; *) return 1 ;; esac
}

usage() {
    say usage
    return 0
}

while [ $# -gt 0 ]; do
    case "$1" in
        --user) OPT_USER=1 ;; --no-deps) OPT_DEPS=0 ;; --skip-cli) OPT_CLI=0 ;; --force) OPT_FORCE=1 ;;
        --autostart) OPT_AUTOSTART=on ;; --no-autostart) OPT_AUTOSTART=off ;;
        --no-login) OPT_LOGIN=0 ;; --no-start) OPT_START=0 ;; -y|--yes) OPT_YES=1 ;;
        -h|--help) usage; exit 0 ;;
        *) usage; die unknown_opt "$1" ;;
    esac
    shift
done

[ "$(id -u)" -ne 0 ] || die run_as_user
[ -f "$SCRIPT_DIR/hadron_sync.py" ] || die missing_file

HAVE_SUDO=0
if command -v sudo >/dev/null 2>&1; then HAVE_SUDO=1; fi
as_root() { if [ "$HAVE_SUDO" = 1 ]; then sudo "$@"; else return 1; fi; }

TMP="$(mktemp -d)"; chmod 700 "$TMP"
trap 'rm -rf "$TMP"' EXIT

fetch() { # fetch URL ZIEL
    local url="$1" out="$2"
    case "$url" in
        https://*) ;;
        file://*) [ -n "${HADRON_SYNC_INDEX_URL:-}${DOWNLOAD_REWRITE}" ] || die https_only "$url" ;;
        *) die https_only "$url" ;;
    esac
    if command -v curl >/dev/null 2>&1; then
        curl -fsSL --retry 3 --proto '=https,file' --tlsv1.2 -o "$out" "$url"
    elif command -v wget >/dev/null 2>&1 && [ "${url#file://}" = "$url" ]; then
        wget -q --https-only -O "$out" "$url"
    else
        die no_downloader
    fi
}

# --------------------------------------------------------------------------- 1. Systempakete
install_deps() {
    local pm="" pkgs=() missing=()
    if command -v apt-get >/dev/null 2>&1; then
        pm=apt
        pkgs=(python3 python3-gi gir1.2-gtk-3.0 gir1.2-ayatanaappindicator3-0.1 libglib2.0-bin gnome-keyring libsecret-1-0 curl ca-certificates)
        for p in "${pkgs[@]}"; do dpkg -s "$p" >/dev/null 2>&1 || missing+=("$p"); done
    elif command -v dnf >/dev/null 2>&1; then
        pm=dnf; missing=(python3 python3-gobject gtk3 libayatana-appindicator-gtk3 glib2 gnome-keyring libsecret curl)
    elif command -v pacman >/dev/null 2>&1; then
        pm=pacman; missing=(python python-gobject gtk3 libayatana-appindicator glib2 gnome-keyring libsecret curl)
    elif command -v zypper >/dev/null 2>&1; then
        pm=zypper; missing=(python3 python3-gobject python3-gobject-Gdk typelib-1_0-Gtk-3_0 typelib-1_0-AyatanaAppIndicator3-0_1 glib2-tools gnome-keyring libsecret-1-0 curl)
    else
        warn pkgs_unknown
        return 0
    fi
    [ "$pm" = apt ] || warn pkgs_untested "$pm"
    if [ ${#missing[@]} -eq 0 ]; then info pkgs_complete; return 0; fi
    info pkgs_needed "${missing[*]}"
    if [ "$HAVE_SUDO" = 0 ]; then
        warn pkgs_nosudo; return 0
    fi
    ask pkgs_install_q || { warn pkgs_skipped; return 0; }
    case "$pm" in
        apt) as_root apt-get update -qq && as_root apt-get install -y "${missing[@]}" ;;
        dnf) as_root dnf install -y "${missing[@]}" ;;
        pacman) as_root pacman -S --needed --noconfirm "${missing[@]}" ;;
        zypper) as_root zypper --non-interactive install "${missing[@]}" ;;
    esac || warn pkgs_failed
}

# --------------------------------------------------------------------------- 2. Proton Drive CLI
detect_platform() {
    if [ -n "${HADRON_SYNC_PLATFORM:-}" ]; then echo "$HADRON_SYNC_PLATFORM"; return; fi
    local arch musl=""
    case "$(uname -m)" in
        x86_64|amd64) arch=x64 ;;
        aarch64|arm64) arch=arm64 ;;
        *) die arch "$(uname -m)" ;;
    esac
    if ldd --version 2>&1 | grep -qi musl; then musl="-musl"; fi
    if [ "$arch" = x64 ] && [ -z "$musl" ] && ! grep -qw avx2 /proc/cpuinfo 2>/dev/null; then
        echo "linux-x64-baseline"; return
    fi
    echo "linux-${arch}${musl}"
}

cli_version() { # Version einer installierten CLI, z. B. 0.8.0
    "$1" version 2>/dev/null | grep -oE 'cli-drive@[0-9]+(\.[0-9]+)+' | head -1 | cut -d@ -f2 || true
}

resolve() { # resolve PLATTFORM -> setzt CLI_URL, CLI_SHA, CLI_VER
    local platform="$1" html
    html="$(cat "$TMP/index.html")"
    CLI_URL="$(grep -oE "https://proton\.me/download/drive/cli/[0-9][0-9A-Za-z.+-]*/${platform}/proton-drive" <<<"$html" | head -1 || true)"
    [ -n "$CLI_URL" ] || return 1
    CLI_SHA="$(grep -oE '[0-9a-fA-F]{128}' <<<"${html#*"$CLI_URL"}" | head -1 | tr 'A-F' 'a-f' || true)"
    [ ${#CLI_SHA} -eq 128 ] || die cli_nosum "$platform"
    CLI_VER="${CLI_URL#"$DOWNLOAD_PREFIX"}"; CLI_VER="${CLI_VER%%/*}"
}

download_verified() { # download_verified ZIEL
    local url="$CLI_URL"
    [ -n "$DOWNLOAD_REWRITE" ] && url="${DOWNLOAD_REWRITE}${CLI_URL#"$DOWNLOAD_PREFIX"}"
    info cli_download "$CLI_VER" "$PLATFORM"
    fetch "$url" "$1"
    local got; got="$(sha512sum "$1" | cut -d' ' -f1)"
    if [ "$got" != "$CLI_SHA" ]; then
        rm -f "$1"
        die cli_sum_bad
    fi
    chmod 755 "$1"
    info cli_sum_ok
}

install_cli() {
    local existing="" target dir
    existing="$(command -v proton-drive 2>/dev/null || true)"
    for c in "$SYSTEM_BIN/proton-drive" "$USER_BIN/proton-drive"; do
        [ -z "$existing" ] && [ -x "$c" ] && existing="$c"
    done
    if [ "$OPT_USER" = 1 ] || [ "$HAVE_SUDO" = 0 ]; then dir="$USER_BIN"
    elif [ -n "$existing" ] && [ "$(dirname "$existing")" = "$USER_BIN" ]; then dir="$USER_BIN"
    else dir="$SYSTEM_BIN"; fi
    target="$dir/proton-drive"

    info cli_lookup
    fetch "$INDEX_URL" "$TMP/index.html"
    PLATFORM="$(detect_platform)"
    resolve "$PLATFORM" || die cli_notfound "$PLATFORM"

    local have=""; [ -n "$existing" ] && have="$(cli_version "$existing")"
    if [ -n "$have" ] && [ "$have" = "$CLI_VER" ] && [ "$OPT_FORCE" = 0 ]; then
        info cli_uptodate "$have" "$existing"
        CLI_PATH="$existing"; return 0
    fi
    if [ -n "$have" ] && [ "$have" != "$CLI_VER" ]; then
        info cli_update "$have" "$CLI_VER"
    fi

    download_verified "$TMP/proton-drive"
    set +e; "$TMP/proton-drive" version >/dev/null 2>&1; local rc=$?; set -e
    if [ $rc -eq 132 ] && [ "$PLATFORM" = linux-x64 ]; then  # Illegal instruction: CPU ohne AVX2
        warn cli_baseline
        PLATFORM=linux-x64-baseline; resolve "$PLATFORM" || die cli_nobaseline
        download_verified "$TMP/proton-drive"
        set +e; "$TMP/proton-drive" version >/dev/null 2>&1; rc=$?; set -e
    fi
    [ $rc -eq 0 ] || die cli_nostart "$rc"

    if [ "$dir" = "$USER_BIN" ]; then
        mkdir -p "$USER_BIN"; install -m 0755 "$TMP/proton-drive" "$target"
    else
        info cli_sudo "$target"
        as_root install -m 0755 "$TMP/proton-drive" "$target" || die cli_instfail "$target"
    fi
    CLI_PATH="$target"
    info cli_installed "$(cli_version "$target")" "$target"
    if [ -n "$existing" ] && [ "$existing" != "$target" ]; then
        warn cli_other "$existing" "$target"
    fi
}

# --------------------------------------------------------------------------- 3. Hadron Sync
RUNNING=0
stop_tool() {
    if pgrep -u "$(id -u)" -f 'hadron_sync\.py' >/dev/null 2>&1; then
        RUNNING=1
        info stop
        pkill -TERM -u "$(id -u)" -f 'hadron_sync\.py' || true
        for _ in 1 2 3 4 5 6 7 8 9 10; do pgrep -u "$(id -u)" -f 'hadron_sync\.py' >/dev/null 2>&1 || break; sleep 0.5; done
    fi
}

install_tool() {
    stop_tool
    mkdir -p "$APP_DIR" "$USER_BIN"
    install -m 0644 "$SCRIPT_DIR/hadron_sync.py" "$APP_DIR/hadron_sync.py"
    [ -f "$SCRIPT_DIR/uninstall.sh" ] && install -m 0755 "$SCRIPT_DIR/uninstall.sh" "$APP_DIR/uninstall.sh"
    [ -f "$SCRIPT_DIR/messages.sh" ] && install -m 0644 "$SCRIPT_DIR/messages.sh" "$APP_DIR/messages.sh"
    cat > "$USER_BIN/hadron-sync" <<EOF
#!/bin/sh
exec python3 "$APP_DIR/hadron_sync.py" "\$@"
EOF
    chmod 755 "$USER_BIN/hadron-sync"
    local args=(--setup)
    [ -n "${CLI_PATH:-}" ] && args+=(--cli "$CLI_PATH")
    if [ -z "$OPT_AUTOSTART" ] && [ ! -f "$HOME/.config/autostart/hadron-sync.desktop" ]; then
        if ask autostart_q; then OPT_AUTOSTART=on; fi
    fi
    [ -n "$OPT_AUTOSTART" ] && args+=(--autostart "$OPT_AUTOSTART")
    python3 "$APP_DIR/hadron_sync.py" "${args[@]}"
    info installed "$(python3 "$APP_DIR/hadron_sync.py" --version | sed 's/^Hadron Sync //')" "$APP_DIR"
}

check_gui() {
    python3 - <<'EOF' 2>/dev/null || warn gtk_missing
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk
EOF
    python3 - <<'EOF' 2>/dev/null || warn appind_missing
import gi
gi.require_version("AyatanaAppIndicator3", "0.1")
EOF
}

# --------------------------------------------------------------------------- Ablauf
say title
say note "$CONTACT"
if [ "$OPT_YES" != 1 ]; then
    accepted=0
    if [ -t 0 ]; then
        read -r -p "$(raw accept_q)" a
        case "${a,,}" in j|ja|y|yes|s|si|sí|o|oui) accepted=1 ;; esac
    fi
    [ "$accepted" = 1 ] || die accept_no
fi
[ "$OPT_DEPS" = 1 ] && install_deps
command -v python3 >/dev/null 2>&1 || die py_missing
CLI_PATH=""
if [ "$OPT_CLI" = 1 ]; then install_cli; else CLI_PATH="$(command -v proton-drive 2>/dev/null || true)"; fi
install_tool
check_gui

case ":$PATH:" in *":$USER_BIN:"*) ;; *)
    warn path_warn "$USER_BIN" ;;
esac

if [ "$OPT_LOGIN" = 1 ] && [ -n "$CLI_PATH" ]; then
    if timeout 60 "$CLI_PATH" filesystem list /my-files </dev/null >/dev/null 2>&1; then
        info signed_in
    elif ask login_q; then
        "$CLI_PATH" auth login || warn login_fail
    fi
fi

if [ "$OPT_START" = 1 ] && { [ -n "${DISPLAY:-}" ] || [ -n "${WAYLAND_DISPLAY:-}" ]; }; then
    if [ "$RUNNING" = 1 ] || ask start_q; then
        nohup python3 "$APP_DIR/hadron_sync.py" >/dev/null 2>&1 &
        info started
    fi
fi
say done "$APP_DIR/uninstall.sh" "$CONTACT"
