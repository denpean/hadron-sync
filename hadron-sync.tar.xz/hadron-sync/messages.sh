# Hadron Sync – Meldungen für install.sh und uninstall.sh (de, en, es, fr).
# Wird von beiden Skripten eingebunden. Platzhalter sind printf-Formate (%s).

M_title_de="Hadron Sync – Installation"
M_title_en="Hadron Sync – installation"
M_title_es="Hadron Sync – instalación"
M_title_fr="Hadron Sync – installation"

M_note_de="
HINWEIS: Hadron Sync ist ein inoffizielles, privates und nicht-kommerzielles Projekt von Dennis Peteranderl
<%s>. Es steht in keiner Verbindung zu Proton AG und wird von Proton weder unterstützt noch
geprüft. Die Software wurde mithilfe der KI-Assistenten Claude (Anthropic) und Mistral AI erstellt.
Installation und Nutzung erfolgen auf eigenes Risiko und ohne Gewähr. Lege vor der Nutzung Sicherungskopien
deiner Daten an.
"
M_note_en="
NOTE: Hadron Sync is an unofficial, private and non-commercial project by Dennis Peteranderl
<%s>. It is not affiliated with Proton AG and is neither supported nor reviewed by Proton.
The software was created with the help of the AI assistants Claude (Anthropic) and Mistral AI. You install and
use it at your own risk and without any warranty. Back up your data before using it.
"
M_note_es="
AVISO: Hadron Sync es un proyecto no oficial, privado y sin fines comerciales de Dennis Peteranderl
<%s>. No tiene relación con Proton AG y Proton no lo respalda ni lo revisa. El software se creó
con ayuda de los asistentes de IA Claude (Anthropic) y Mistral AI. La instalación y el uso son bajo tu
propia responsabilidad y sin garantía. Haz copias de seguridad de tus datos antes de usarlo.
"
M_note_fr="
REMARQUE : Hadron Sync est un projet non officiel, privé et non commercial de Dennis Peteranderl
<%s>. Il n’est pas affilié à Proton AG et n’est ni soutenu ni vérifié par Proton. Le logiciel a été
créé avec l’aide des assistants IA Claude (Anthropic) et Mistral AI. L’installation et l’utilisation se font à
vos propres risques et sans garantie. Sauvegardez vos données avant de l’utiliser.
"

M_accept_q_de="Auf eigenes Risiko installieren? [j/N] "
M_accept_q_en="Install at your own risk? [y/N] "
M_accept_q_es="¿Instalar bajo tu propia responsabilidad? [s/N] "
M_accept_q_fr="Installer à vos propres risques ? [o/N] "

M_accept_no_de="Installation abgebrochen (Hinweis nicht bestätigt; ohne Rückfrage: --yes)."
M_accept_no_en="Installation cancelled (note not accepted; non-interactive: --yes)."
M_accept_no_es="Instalación cancelada (aviso no aceptado; sin preguntas: --yes)."
M_accept_no_fr="Installation annulée (remarque non acceptée ; sans question : --yes)."

M_usage_de="Verwendung: ./install.sh [Optionen]
  --user            CLI nach ~/.local/bin installieren (ohne sudo)
  --no-deps         keine Systempakete installieren
  --skip-cli        Proton Drive CLI nicht installieren/aktualisieren
  --force           CLI auch bei gleicher Version neu herunterladen
  --autostart       Autostart beim Anmelden einschalten (--no-autostart: ausschalten)
  --no-login        keine Anmeldung bei Proton anbieten
  --no-start        Hadron Sync am Ende nicht starten
  -y, --yes         alle Rückfragen mit Ja beantworten (inkl. Hinweis: Nutzung auf eigenes Risiko)
  -h, --help        diese Hilfe"
M_usage_en="Usage: ./install.sh [options]
  --user            install the CLI to ~/.local/bin (no sudo)
  --no-deps         do not install system packages
  --skip-cli        do not install/update the Proton Drive CLI
  --force           download the CLI even if the version is unchanged
  --autostart       enable autostart at login (--no-autostart: disable)
  --no-login        do not offer to sign in to Proton
  --no-start        do not start Hadron Sync at the end
  -y, --yes         answer yes to all questions (incl. the note: use at your own risk)
  -h, --help        show this help"
M_usage_es="Uso: ./install.sh [opciones]
  --user            instalar la CLI en ~/.local/bin (sin sudo)
  --no-deps         no instalar paquetes del sistema
  --skip-cli        no instalar ni actualizar la CLI de Proton Drive
  --force           descargar la CLI aunque la versión no cambie
  --autostart       activar el inicio automático (--no-autostart: desactivar)
  --no-login        no ofrecer el inicio de sesión en Proton
  --no-start        no iniciar Hadron Sync al final
  -y, --yes         responder sí a todo (incluido el aviso: uso bajo tu responsabilidad)
  -h, --help        mostrar esta ayuda"
M_usage_fr="Utilisation : ./install.sh [options]
  --user            installer la CLI dans ~/.local/bin (sans sudo)
  --no-deps         ne pas installer de paquets système
  --skip-cli        ne pas installer/mettre à jour la CLI Proton Drive
  --force           télécharger la CLI même si la version est inchangée
  --autostart       activer le démarrage automatique (--no-autostart : désactiver)
  --no-login        ne pas proposer la connexion à Proton
  --no-start        ne pas lancer Hadron Sync à la fin
  -y, --yes         répondre oui à tout (y compris la remarque : utilisation à vos risques)
  -h, --help        afficher cette aide"

M_unknown_opt_de="Unbekannte Option: %s"
M_unknown_opt_en="Unknown option: %s"
M_unknown_opt_es="Opción desconocida: %s"
M_unknown_opt_fr="Option inconnue : %s"

M_run_as_user_de="Bitte als normaler Benutzer ausführen (nicht als root). Für Systempakete wird bei Bedarf sudo verwendet."
M_run_as_user_en="Please run as a normal user (not root). sudo is used for system packages when needed."
M_run_as_user_es="Ejecútalo como usuario normal (no como root). Para los paquetes del sistema se usa sudo si hace falta."
M_run_as_user_fr="Exécutez en tant qu’utilisateur normal (pas root). sudo est utilisé au besoin pour les paquets système."

M_missing_file_de="hadron_sync.py fehlt neben install.sh."
M_missing_file_en="hadron_sync.py is missing next to install.sh."
M_missing_file_es="Falta hadron_sync.py junto a install.sh."
M_missing_file_fr="hadron_sync.py est absent à côté de install.sh."

M_https_only_de="Nur HTTPS erlaubt: %s"
M_https_only_en="Only HTTPS allowed: %s"
M_https_only_es="Solo se permite HTTPS: %s"
M_https_only_fr="HTTPS uniquement : %s"

M_no_downloader_de="Weder curl noch wget gefunden."
M_no_downloader_en="Neither curl nor wget found."
M_no_downloader_es="No se encontró ni curl ni wget."
M_no_downloader_fr="Ni curl ni wget n’ont été trouvés."

M_pkgs_unknown_de="Unbekannter Paketmanager – bitte Python 3, PyGObject (GTK 3), Ayatana AppIndicator, gio, gnome-keyring und curl selbst installieren."
M_pkgs_unknown_en="Unknown package manager – please install Python 3, PyGObject (GTK 3), Ayatana AppIndicator, gio, gnome-keyring and curl yourself."
M_pkgs_unknown_es="Gestor de paquetes desconocido: instala tú mismo Python 3, PyGObject (GTK 3), Ayatana AppIndicator, gio, gnome-keyring y curl."
M_pkgs_unknown_fr="Gestionnaire de paquets inconnu – installez vous-même Python 3, PyGObject (GTK 3), Ayatana AppIndicator, gio, gnome-keyring et curl."

M_pkgs_untested_de="Paketnamen für %s sind nicht getestet."
M_pkgs_untested_en="Package names for %s are untested."
M_pkgs_untested_es="Los nombres de paquetes para %s no están probados."
M_pkgs_untested_fr="Les noms de paquets pour %s ne sont pas testés."

M_pkgs_complete_de="Systempakete sind vollständig."
M_pkgs_complete_en="System packages are complete."
M_pkgs_complete_es="Los paquetes del sistema están completos."
M_pkgs_complete_fr="Les paquets système sont complets."

M_pkgs_needed_de="Benötigte Pakete: %s"
M_pkgs_needed_en="Required packages: %s"
M_pkgs_needed_es="Paquetes necesarios: %s"
M_pkgs_needed_fr="Paquets requis : %s"

M_pkgs_nosudo_de="sudo fehlt – bitte die Pakete selbst installieren."
M_pkgs_nosudo_en="sudo is missing – please install the packages yourself."
M_pkgs_nosudo_es="Falta sudo: instala los paquetes tú mismo."
M_pkgs_nosudo_fr="sudo est absent – installez les paquets vous-même."

M_pkgs_install_q_de="Jetzt mit sudo installieren? [J/n] "
M_pkgs_install_q_en="Install now with sudo? [Y/n] "
M_pkgs_install_q_es="¿Instalarlos ahora con sudo? [S/n] "
M_pkgs_install_q_fr="Installer maintenant avec sudo ? [O/n] "

M_pkgs_skipped_de="Pakete übersprungen."
M_pkgs_skipped_en="Packages skipped."
M_pkgs_skipped_es="Paquetes omitidos."
M_pkgs_skipped_fr="Paquets ignorés."

M_pkgs_failed_de="Paketinstallation fehlgeschlagen – bitte die Ausgabe prüfen."
M_pkgs_failed_en="Package installation failed – please check the output."
M_pkgs_failed_es="La instalación de paquetes falló: revisa la salida."
M_pkgs_failed_fr="L’installation des paquets a échoué – vérifiez la sortie."

M_py_missing_de="python3 fehlt."
M_py_missing_en="python3 is missing."
M_py_missing_es="Falta python3."
M_py_missing_fr="python3 est absent."

M_arch_de="Nicht unterstützte Architektur: %s"
M_arch_en="Unsupported architecture: %s"
M_arch_es="Arquitectura no compatible: %s"
M_arch_fr="Architecture non prise en charge : %s"

M_cli_lookup_de="Suche aktuelle Version der Proton Drive CLI …"
M_cli_lookup_en="Looking up the latest Proton Drive CLI …"
M_cli_lookup_es="Buscando la versión más reciente de la CLI de Proton Drive …"
M_cli_lookup_fr="Recherche de la dernière version de la CLI Proton Drive …"

M_cli_notfound_de="Keine Proton Drive CLI für %s im Index gefunden."
M_cli_notfound_en="No Proton Drive CLI for %s found in the index."
M_cli_notfound_es="No se encontró la CLI de Proton Drive para %s en el índice."
M_cli_notfound_fr="Aucune CLI Proton Drive pour %s dans l’index."

M_cli_nosum_de="Keine Prüfsumme für %s im Index gefunden."
M_cli_nosum_en="No checksum for %s found in the index."
M_cli_nosum_es="No se encontró la suma de verificación de %s en el índice."
M_cli_nosum_fr="Aucune somme de contrôle pour %s dans l’index."

M_cli_download_de="Lade Proton Drive CLI %s (%s) …"
M_cli_download_en="Downloading Proton Drive CLI %s (%s) …"
M_cli_download_es="Descargando la CLI de Proton Drive %s (%s) …"
M_cli_download_fr="Téléchargement de la CLI Proton Drive %s (%s) …"

M_cli_sum_ok_de="Prüfsumme (SHA-512) bestätigt."
M_cli_sum_ok_en="Checksum (SHA-512) verified."
M_cli_sum_ok_es="Suma de verificación (SHA-512) confirmada."
M_cli_sum_ok_fr="Somme de contrôle (SHA-512) vérifiée."

M_cli_sum_bad_de="Prüfsumme stimmt nicht – Download verworfen, nichts installiert."
M_cli_sum_bad_en="Checksum mismatch – download discarded, nothing installed."
M_cli_sum_bad_es="La suma de verificación no coincide: descarga descartada, no se instaló nada."
M_cli_sum_bad_fr="Somme de contrôle incorrecte – téléchargement rejeté, rien n’a été installé."

M_cli_uptodate_de="Proton Drive CLI %s ist aktuell (%s)."
M_cli_uptodate_en="Proton Drive CLI %s is up to date (%s)."
M_cli_uptodate_es="La CLI de Proton Drive %s está actualizada (%s)."
M_cli_uptodate_fr="La CLI Proton Drive %s est à jour (%s)."

M_cli_update_de="Aktualisiere Proton Drive CLI %s → %s"
M_cli_update_en="Updating Proton Drive CLI %s → %s"
M_cli_update_es="Actualizando la CLI de Proton Drive %s → %s"
M_cli_update_fr="Mise à jour de la CLI Proton Drive %s → %s"

M_cli_baseline_de="Die Standardversion läuft auf dieser CPU nicht – verwende die Baseline-Version."
M_cli_baseline_en="The default build does not run on this CPU – using the baseline build."
M_cli_baseline_es="La versión estándar no funciona en esta CPU: se usa la versión baseline."
M_cli_baseline_fr="La version standard ne fonctionne pas sur ce processeur – utilisation de la version baseline."

M_cli_nobaseline_de="Baseline-Version nicht im Index."
M_cli_nobaseline_en="Baseline build not in the index."
M_cli_nobaseline_es="La versión baseline no está en el índice."
M_cli_nobaseline_fr="Version baseline absente de l’index."

M_cli_nostart_de="Die heruntergeladene CLI startet nicht (Code %s)."
M_cli_nostart_en="The downloaded CLI does not start (code %s)."
M_cli_nostart_es="La CLI descargada no arranca (código %s)."
M_cli_nostart_fr="La CLI téléchargée ne démarre pas (code %s)."

M_cli_sudo_de="Installiere nach %s (sudo) …"
M_cli_sudo_en="Installing to %s (sudo) …"
M_cli_sudo_es="Instalando en %s (sudo) …"
M_cli_sudo_fr="Installation dans %s (sudo) …"

M_cli_instfail_de="Installation nach %s fehlgeschlagen."
M_cli_instfail_en="Installing to %s failed."
M_cli_instfail_es="Falló la instalación en %s."
M_cli_instfail_fr="Échec de l’installation dans %s."

M_cli_installed_de="Proton Drive CLI %s installiert: %s"
M_cli_installed_en="Proton Drive CLI %s installed: %s"
M_cli_installed_es="CLI de Proton Drive %s instalada: %s"
M_cli_installed_fr="CLI Proton Drive %s installée : %s"

M_cli_other_de="Es gibt eine weitere CLI unter %s – das Werkzeug nutzt %s."
M_cli_other_en="There is another CLI at %s – the tool uses %s."
M_cli_other_es="Hay otra CLI en %s; la herramienta usa %s."
M_cli_other_fr="Une autre CLI se trouve dans %s – l’outil utilise %s."

M_stop_de="Beende laufendes Hadron Sync …"
M_stop_en="Stopping running Hadron Sync …"
M_stop_es="Deteniendo Hadron Sync en ejecución …"
M_stop_fr="Arrêt de Hadron Sync en cours d’exécution …"

M_autostart_q_de="Hadron Sync beim Anmelden automatisch starten? [J/n] "
M_autostart_q_en="Start Hadron Sync automatically at login? [Y/n] "
M_autostart_q_es="¿Iniciar Hadron Sync automáticamente al iniciar sesión? [S/n] "
M_autostart_q_fr="Démarrer Hadron Sync automatiquement à la connexion ? [O/n] "

M_installed_de="Hadron Sync %s installiert: %s"
M_installed_en="Hadron Sync %s installed: %s"
M_installed_es="Hadron Sync %s instalado: %s"
M_installed_fr="Hadron Sync %s installé : %s"

M_gtk_missing_de="GTK für Python fehlt – die Oberfläche startet so nicht (siehe Systempakete)."
M_gtk_missing_en="GTK for Python is missing – the interface will not start (see system packages)."
M_gtk_missing_es="Falta GTK para Python: la interfaz no se iniciará (consulta los paquetes del sistema)."
M_gtk_missing_fr="GTK pour Python est absent – l’interface ne démarrera pas (voir les paquets système)."

M_appind_missing_de="Ayatana AppIndicator fehlt – das Tray-Symbol wird nicht angezeigt."
M_appind_missing_en="Ayatana AppIndicator is missing – no tray icon will be shown."
M_appind_missing_es="Falta Ayatana AppIndicator: no se mostrará el icono en la bandeja."
M_appind_missing_fr="Ayatana AppIndicator est absent – aucune icône de notification ne sera affichée."

M_path_warn_de="%s ist nicht im PATH – „hadron-sync“ im Terminal geht erst nach einer Neuanmeldung (Menüeintrag funktioniert sofort)."
M_path_warn_en="%s is not in PATH – 'hadron-sync' in the terminal works after logging in again (the menu entry works right away)."
M_path_warn_es="%s no está en el PATH: «hadron-sync» en el terminal funcionará tras volver a iniciar sesión (la entrada de menú ya funciona)."
M_path_warn_fr="%s n’est pas dans le PATH – « hadron-sync » dans le terminal fonctionnera après une reconnexion (l’entrée de menu fonctionne déjà)."

M_signed_in_de="Bei Proton angemeldet."
M_signed_in_en="Signed in to Proton."
M_signed_in_es="Sesión iniciada en Proton."
M_signed_in_fr="Connecté à Proton."

M_login_q_de="Jetzt bei Proton anmelden (öffnet den Browser)? [J/n] "
M_login_q_en="Sign in to Proton now (opens the browser)? [Y/n] "
M_login_q_es="¿Iniciar sesión en Proton ahora (abre el navegador)? [S/n] "
M_login_q_fr="Se connecter à Proton maintenant (ouvre le navigateur) ? [O/n] "

M_login_fail_de="Anmeldung nicht abgeschlossen – später über „Anmelden“ im Werkzeug möglich."
M_login_fail_en="Sign-in not completed – you can sign in later via 'Sign in' in the tool."
M_login_fail_es="Inicio de sesión no completado: puedes hacerlo luego con «Iniciar sesión» en la herramienta."
M_login_fail_fr="Connexion non terminée – possible plus tard via « Se connecter » dans l’outil."

M_start_q_de="Hadron Sync jetzt starten? [J/n] "
M_start_q_en="Start Hadron Sync now? [Y/n] "
M_start_q_es="¿Iniciar Hadron Sync ahora? [S/n] "
M_start_q_fr="Lancer Hadron Sync maintenant ? [O/n] "

M_started_de="Hadron Sync gestartet."
M_started_en="Hadron Sync started."
M_started_es="Hadron Sync iniciado."
M_started_fr="Hadron Sync démarré."

M_done_de="
Fertig. Hadron Sync findest du im Anwendungsmenü. Zum Aktualisieren install.sh erneut ausführen,
zum Entfernen: %s
Fragen und Rückmeldungen: %s"
M_done_en="
Done. Hadron Sync is in your application menu. Run install.sh again to update,
to remove it: %s
Questions and feedback: %s"
M_done_es="
Listo. Hadron Sync está en el menú de aplicaciones. Vuelve a ejecutar install.sh para actualizar,
para quitarlo: %s
Preguntas y comentarios: %s"
M_done_fr="
Terminé. Hadron Sync est dans votre menu d’applications. Relancez install.sh pour mettre à jour,
pour le supprimer : %s
Questions et retours : %s"

# --- Deinstallation
M_un_title_de="Hadron Sync – Deinstallation (deine Dateien bleiben unangetastet)"
M_un_title_en="Hadron Sync – uninstall (your files are not touched)"
M_un_title_es="Hadron Sync – desinstalación (tus archivos no se tocan)"
M_un_title_fr="Hadron Sync – désinstallation (vos fichiers ne sont pas touchés)"

M_un_usage_de="Verwendung: uninstall.sh [--purge] [--logout] [--remove-cli] [-y]
  --purge       auch Einstellungen, Sync-Stand und Protokoll löschen
  --logout      bei Proton abmelden (Sitzung aus dem Schlüsselbund entfernen)
  --remove-cli  auch die Proton Drive CLI entfernen
  -y, --yes     ohne Rückfragen (entfernt nur, was per Option verlangt ist)"
M_un_usage_en="Usage: uninstall.sh [--purge] [--logout] [--remove-cli] [-y]
  --purge       also delete settings, sync state and log
  --logout      sign out of Proton (remove the session from the keyring)
  --remove-cli  also remove the Proton Drive CLI
  -y, --yes     no questions (only removes what the options request)"
M_un_usage_es="Uso: uninstall.sh [--purge] [--logout] [--remove-cli] [-y]
  --purge       borrar también ajustes, estado de sincronización y registro
  --logout      cerrar sesión en Proton (quitarla del llavero)
  --remove-cli  quitar también la CLI de Proton Drive
  -y, --yes     sin preguntas (solo quita lo que pidan las opciones)"
M_un_usage_fr="Utilisation : uninstall.sh [--purge] [--logout] [--remove-cli] [-y]
  --purge       supprimer aussi les réglages, l’état de synchronisation et le journal
  --logout      se déconnecter de Proton (retirer la session du trousseau)
  --remove-cli  supprimer aussi la CLI Proton Drive
  -y, --yes     sans question (ne retire que ce que demandent les options)"

M_un_stop_de="Beende Hadron Sync …"
M_un_stop_en="Stopping Hadron Sync …"
M_un_stop_es="Deteniendo Hadron Sync …"
M_un_stop_fr="Arrêt de Hadron Sync …"

M_un_removed_de="Programm, Menüeintrag, Autostart und Symbole entfernt."
M_un_removed_en="Program, menu entry, autostart and icons removed."
M_un_removed_es="Programa, entrada de menú, inicio automático e iconos eliminados."
M_un_removed_fr="Programme, entrée de menu, démarrage automatique et icônes supprimés."

M_un_purge_q_de="Auch Einstellungen, Sync-Stand und Protokoll löschen? [j/N] "
M_un_purge_q_en="Also delete settings, sync state and log? [y/N] "
M_un_purge_q_es="¿Borrar también ajustes, estado de sincronización y registro? [s/N] "
M_un_purge_q_fr="Supprimer aussi les réglages, l’état et le journal ? [o/N] "

M_un_purged_de="Einstellungen und Protokoll gelöscht."
M_un_purged_en="Settings and log deleted."
M_un_purged_es="Ajustes y registro borrados."
M_un_purged_fr="Réglages et journal supprimés."

M_un_kept_de="Einstellungen bleiben in %s (bei Neuinstallation weiter nutzbar)."
M_un_kept_en="Settings kept in %s (reused on reinstall)."
M_un_kept_es="Los ajustes se conservan en %s (se reutilizan al reinstalar)."
M_un_kept_fr="Réglages conservés dans %s (réutilisés lors d’une réinstallation)."

M_un_logout_q_de="Bei Proton abmelden? [j/N] "
M_un_logout_q_en="Sign out of Proton? [y/N] "
M_un_logout_q_es="¿Cerrar sesión en Proton? [s/N] "
M_un_logout_q_fr="Se déconnecter de Proton ? [o/N] "

M_un_logout_de="Abgemeldet."
M_un_logout_en="Signed out."
M_un_logout_es="Sesión cerrada."
M_un_logout_fr="Déconnecté."

M_un_cli_q_de="Auch die Proton Drive CLI (%s) entfernen? [j/N] "
M_un_cli_q_en="Also remove the Proton Drive CLI (%s)? [y/N] "
M_un_cli_q_es="¿Quitar también la CLI de Proton Drive (%s)? [s/N] "
M_un_cli_q_fr="Supprimer aussi la CLI Proton Drive (%s) ? [o/N] "

M_un_cli_removed_de="Proton Drive CLI entfernt."
M_un_cli_removed_en="Proton Drive CLI removed."
M_un_cli_removed_es="CLI de Proton Drive eliminada."
M_un_cli_removed_fr="CLI Proton Drive supprimée."

M_un_done_de="Fertig. Fragen und Rückmeldungen: %s"
M_un_done_en="Done. Questions and feedback: %s"
M_un_done_es="Listo. Preguntas y comentarios: %s"
M_un_done_fr="Terminé. Questions et retours : %s"
