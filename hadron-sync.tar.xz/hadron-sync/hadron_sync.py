#!/usr/bin/env python3
"""Hadron Sync - Zweiwege-Abgleich beliebig vieler lokaler Ordner mit Ordnern in Proton Drive.

Autor: Dennis Peteranderl <hadron.unfreeze611@passmail.net>

HINWEIS: Hadron Sync ist ein inoffizielles, privates und nicht-kommerzielles Projekt. Es steht in keiner
Verbindung zu Proton AG und wird von Proton weder unterstuetzt noch geprueft. Die Software wurde mithilfe der
KI-Assistenten Claude (Anthropic) und Mistral AI erstellt. Installation und Nutzung erfolgen auf eigenes
Risiko und ohne Gewaehr. Vor der Nutzung Sicherungskopien der Daten anlegen.

Baut auf der offiziellen `proton-drive` CLI auf (getestet gegen cli-drive 0.7.0).
  * Tray-Icon (Zorin OS / GNOME mit AppIndicator-Unterstuetzung), Icon zeigt den Status.
  * Lokale Aenderungen werden ueberwacht und nach kurzer Verzoegerung synchronisiert (optional).
  * Regelmaessiger Vollabgleich im Intervall (erkennt auch Aenderungen in Proton Drive).
  * Neuere Aenderung gewinnt; Loeschungen gehen in den Papierkorb (Proton bzw. lokal), nie endgueltig.
  * Optional: automatischer Start im Hintergrund beim Anmelden.
Start:   python3 hadron_sync.py                (Tray + Einstellungsfenster)
         python3 hadron_sync.py --background   (nur Tray, so startet der Autostart)
         python3 hadron_sync.py --headless [--dry-run] [--mode quick|full] [--yes]   (alle gespeicherten Paare)
         python3 hadron_sync.py --headless --local ORDNER --remote /my-files/ZIEL   (ein einzelnes Paar)
"""

import argparse
import concurrent.futures
import fcntl
import fnmatch
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import NamedTuple, Optional

APP_ID = "local.hadronsync.App"
APP_NAME = "Hadron Sync"
APP_AUTHOR = "Dennis Peteranderl"
APP_VERSION = "1.9.2"
APP_DATE = "2026-09-23"
APP_CONTACT = "hadron.unfreeze611@passmail.net"
REMOTE_ROOT = "/my-files"
CHANGELOG_ROOT = REMOTE_ROOT + "/" + ".hadron-sync"
CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "hadron-sync"
CONFIG_FILE = CONFIG_DIR / "config.json"
CHANGELOG_FILE = CONFIG_DIR / "changelog.json"    # eigener Zwischenspeicher: unsere Eintraege, Lesezeichen, Stand
CHANGELOG_REL = ".hadron-sync"                    # liegt immer im Proton-Stammverzeichnis, unabhaengig vom Ordnerpaar
CHANGELOG_TTL_DAYS = 7
CHANGELOG_POLL_S = 60
STATE_DIR = Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state")) / "hadron-sync"
LOG_FILE = STATE_DIR / "sync.log"
TOLERANCE = 2.0    # Sekunden: Zeitstempel innerhalb dieser Toleranz gelten als gleich
PARALLEL_DEFAULT = 4   # gleichzeitige Abfragen an Proton Drive beim Einlesen
RETRY_PAUSES = (1, 3)  # Wartezeiten (Sekunden) vor erneuten Versuchen nach voruebergehenden Fehlern
BATCH = 40         # Dateien pro CLI-Aufruf
PROGRESS_S = 15     # Sekunden zwischen Fortschrittsmeldungen
DEBOUNCE_S = 8     # Ruhezeit nach der letzten lokalen Aenderung, bevor synchronisiert wird
TMP_DIR_NAME = ".hadron-sync-tmp"  # Zwischenablage fuer Downloads im lokalen Ordner
DEFAULT_EXCLUDES = ".DS_Store, Thumbs.db, *.tmp, *.part, .~lock.*, ~$*, .Trash-*"

# Neue Namen (Version im Namen), damit die Shell nicht das zwischengespeicherte alte Icon anzeigt.
# --------------------------------------------------------------------------- Sprachen

LANGUAGES = {"auto": None, "de": "Deutsch", "en": "English", "es": "Español", "fr": "Français"}
# (Deutsch = Schluessel, English, Español, Français)
CATALOG = [
    ('Ordnerüberwachung nicht vollständig möglich (inotify-Grenze erreicht) – restliche Ordner werden nur über das Intervall abgeglichen. Grenze erhöhen: sudo sysctl fs.inotify.max_user_watches=524288', 'Folder monitoring not fully possible (inotify limit reached) – remaining folders are only synced via the interval. Raise the limit: sudo sysctl fs.inotify.max_user_watches=524288', 'No se puede supervisar completamente (límite de inotify alcanzado); el resto de carpetas solo se sincroniza por el intervalo. Aumenta el límite: sudo sysctl fs.inotify.max_user_watches=524288', 'Surveillance des dossiers incomplète (limite inotify atteinte) – les dossiers restants ne sont synchronisés que via l’intervalle. Augmentez la limite : sudo sysctl fs.inotify.max_user_watches=524288'),
    ('Vergleicht Dateien …', 'Comparing files …', 'Comparando archivos …', 'Comparaison des fichiers …'),
    ('Fertig – Synchronisierung abgeschlossen.', 'Done – sync completed.', 'Listo – sincronización completada.', 'Terminé – synchronisation effectuée.'),
    ('Änderung auf einem anderen Gerät erkannt – gleiche {n} Datei(en) gezielt ab.', 'Change detected on another device – syncing {n} file(s) directly.', 'Cambio detectado en otro dispositivo: sincronizando {n} archivo(s) directamente.', 'Modification détectée sur un autre appareil – synchronisation ciblée de {n} fichier(s).'),
    ('Gezielter Abgleich fertig: {ok} Aktionen erfolgreich, {err} Fehler.', 'Targeted sync done: {ok} actions succeeded, {err} errors.', 'Sincronización dirigida lista: {ok} acciones correctas, {err} errores.', 'Synchronisation ciblée terminée : {ok} actions réussies, {err} erreurs.'),
    ('Änderungsprotokoll: {path} konnte nicht hochgeladen werden ({msg})', 'Change log: could not upload {path} ({msg})', 'Registro de cambios: no se pudo subir {path} ({msg})', 'Journal des modifications : échec de l’envoi de {path} ({msg})'),
    ('Einstellungen …', 'Settings …', 'Ajustes …', 'Réglages …'),
    ('Einstellungen – {app}', 'Settings – {app}', 'Ajustes – {app}', 'Réglages – {app}'),
    ('Schließen', 'Close', 'Cerrar', 'Fermer'),
    ('Es läuft gerade ein Abgleich. Soll er mit den neuen Einstellungen neu gestartet werden?', 'A sync is currently running. Restart it with the new settings?', 'Hay una sincronización en curso. ¿Reiniciarla con los nuevos ajustes?', 'Une synchronisation est en cours. La relancer avec les nouveaux réglages ?'),
    ('Einstellungen übernommen.', 'Settings applied.', 'Ajustes aplicados.', 'Réglages appliqués.'),
    ('Einstellungen übernommen – laufender Abgleich wird neu gestartet.', 'Settings applied – the running sync is being restarted.', 'Ajustes aplicados: se reinicia la sincronización en curso.', 'Réglages appliqués – la synchronisation en cours redémarre.'),
    ('Einstellungen übernommen – der laufende Abgleich nutzt sie ab dem nächsten Ordnerpaar.', 'Settings applied – the running sync will use them from the next folder pair on.', 'Ajustes aplicados: la sincronización en curso los usará a partir del siguiente par.', 'Réglages appliqués – la synchronisation en cours les utilisera dès la paire suivante.'),
    ('Lese Proton Drive: {done} von etwa {total} Ordnern', 'Reading Proton Drive: {done} of about {total} folders', 'Leyendo Proton Drive: {done} de unas {total} carpetas', 'Lecture de Proton Drive : {done} sur environ {total} dossiers'),
    ('Lade hoch: {done} von {total} Dateien', 'Uploading: {done} of {total} files', 'Subiendo: {done} de {total} archivos', 'Envoi : {done} sur {total} fichiers'),
    ('Lade herunter: {done} von {total} Dateien', 'Downloading: {done} of {total} files', 'Descargando: {done} de {total} archivos', 'Téléchargement : {done} sur {total} fichiers'),
    ('noch etwa {time}', 'about {time} left', 'quedan unos {time}', 'environ {time} restant'),
    ('Restzeit wird geschätzt …', 'Estimating time remaining …', 'Calculando el tiempo restante …', 'Estimation du temps restant …'),
    ('{h} Std. {m} Min.', '{h} h {m} min', '{h} h {m} min', '{h} h {m} min'),
    ('{m} Min.', '{m} min', '{m} min', '{m} min'),
    ('{s} Sek.', '{s} s', '{s} s', '{s} s'),
    ('Einrichtung von {app}', 'Setting up {app}', 'Configuración de {app}', 'Configuration de {app}'),
    ('Willkommen', 'Welcome', 'Bienvenido', 'Bienvenue'),
    ('Dieser Assistent richtet {app} in wenigen Schritten ein.', 'This assistant sets up {app} in a few steps.', 'Este asistente configura {app} en unos pocos pasos.', 'Cet assistant configure {app} en quelques étapes.'),
    ('Frühere Einrichtung gefunden', 'Earlier setup found', 'Se encontró una configuración anterior', 'Configuration antérieure trouvée'),
    ('Es wurden Einstellungen einer früheren Installation gefunden ({n} Ordnerpaar(e), Stand vom {date}).', 'Settings from an earlier installation were found ({n} folder pair(s), from {date}).', 'Se encontraron ajustes de una instalación anterior ({n} par(es) de carpetas, del {date}).', 'Des réglages d’une installation antérieure ont été trouvés ({n} paire(s) de dossiers, du {date}).'),
    ('Frühere Einstellungen übernehmen (empfohlen)', 'Keep the earlier settings (recommended)', 'Conservar los ajustes anteriores (recomendado)', 'Conserver les réglages antérieurs (recommandé)'),
    ('Komplett neu einrichten (bisherige Ordnerpaare und Sync-Stand verwerfen)', 'Set up from scratch (discard previous folder pairs and sync state)', 'Configurar desde cero (descartar pares de carpetas y estado anterior)', 'Tout reconfigurer (abandonner les paires et l’état précédents)'),
    ('Beim Neueinrichten bleiben deine Dateien erhalten; nur die Einstellungen und der Sync-Stand werden verworfen. Der nächste Abgleich beginnt dann wieder von vorn.', 'Setting up from scratch keeps your files; only settings and sync state are discarded. The next sync then starts over.', 'Al configurar desde cero se conservan tus archivos; solo se descartan los ajustes y el estado. La próxima sincronización empezará de nuevo.', 'Une reconfiguration conserve vos fichiers ; seuls les réglages et l’état sont abandonnés. La prochaine synchronisation repartira de zéro.'),
    ('Anmeldung bei Proton', 'Sign in to Proton', 'Inicio de sesión en Proton', 'Connexion à Proton'),
    ('Angemeldet – weiter mit dem nächsten Schritt.', 'Signed in – continue to the next step.', 'Sesión iniciada: continúa con el siguiente paso.', 'Connecté – passez à l’étape suivante.'),
    ('Nicht angemeldet. Klicke auf „Anmelden“, der Browser öffnet sich.', "Not signed in. Click 'Sign in' and your browser will open.", 'Sin sesión. Pulsa «Iniciar sesión» y se abrirá el navegador.', 'Non connecté. Cliquez sur « Se connecter » et le navigateur s’ouvrira.'),
    ('Anmeldung wird geprüft …', 'Checking sign-in …', 'Comprobando el inicio de sesión …', 'Vérification de la connexion …'),
    ('Erstes Ordnerpaar', 'First folder pair', 'Primer par de carpetas', 'Première paire de dossiers'),
    ('Wähle einen lokalen Ordner und den Ordner in Proton Drive, der damit abgeglichen werden soll.', 'Choose a local folder and the folder in Proton Drive it should be synced with.', 'Elige una carpeta local y la carpeta de Proton Drive con la que se sincronizará.', 'Choisissez un dossier local et le dossier Proton Drive à synchroniser avec lui.'),
    ('Einstellungen', 'Settings', 'Ajustes', 'Réglages'),
    ('Fertig', 'Done', 'Listo', 'Terminé'),
    ('Die Einrichtung ist abgeschlossen. Starte am besten mit einem Trockenlauf: Er zeigt im Protokoll, was passieren würde, ohne etwas zu verändern.', 'Setup is complete. It is best to start with a dry run: it shows in the log what would happen, without changing anything.', 'La configuración ha terminado. Empieza con una simulación: muestra en el registro lo que pasaría sin cambiar nada.', 'La configuration est terminée. Commencez par une simulation : elle montre dans le journal ce qui se passerait, sans rien modifier.'),
    ('Weitere Ordnerpaare kannst du später im Fenster hinzufügen.', 'You can add more folder pairs later in the window.', 'Puedes añadir más pares de carpetas más tarde en la ventana.', 'Vous pourrez ajouter d’autres paires plus tard dans la fenêtre.'),
    ('Kontakt', 'Contact', 'Contacto', 'Contact'),
    ('Von der Proton-CLI umbenannt, Name wird zurückgesetzt: {path}', 'Renamed by the Proton CLI, restoring the original name: {path}', 'Renombrado por la CLI de Proton, se restaura el nombre original: {path}', 'Renommé par la CLI Proton, nom d’origine rétabli : {path}'),
    ('FEHLER: {path} konnte lokal nicht angelegt werden ({msg})', 'ERROR: {path} could not be created locally ({msg})', 'ERROR: no se pudo crear {path} localmente ({msg})', 'ERREUR : impossible de créer {path} localement ({msg})'),
    ('Gleichzeitige Abfragen an Proton Drive', 'Parallel requests to Proton Drive', 'Consultas simultáneas a Proton Drive', 'Requêtes simultanées vers Proton Drive'),
    ('(beschleunigt das Einlesen; bei Problemen auf 1 stellen)', '(speeds up reading; set to 1 if there are problems)', '(acelera la lectura; ponlo en 1 si hay problemas)', '(accélère la lecture ; mettez 1 en cas de problème)'),
    ('Ordner erneut gelesen (einzeln): {path}', 'Folder read again (one by one): {path}', 'Carpeta leída de nuevo (una a una): {path}', 'Dossier relu (un par un) : {path}'),
    ('Ohne Vorschaubild hochgeladen: {path}', 'Uploaded without thumbnail: {path}', 'Subido sin miniatura: {path}', 'Envoyé sans miniature : {path}'),
    ('Vorschaubilder in Proton Drive erzeugen (langsamer)', 'Generate thumbnails in Proton Drive (slower)', 'Generar miniaturas en Proton Drive (más lento)', 'Générer des miniatures dans Proton Drive (plus lent)'),
    ('Die installierte Proton-CLI versteht einen Befehl von Hadron Sync nicht – bitte Hadron Sync aktualisieren. Meldung der CLI: {msg}', 'The installed Proton CLI does not understand a Hadron Sync command – please update Hadron Sync. CLI message: {msg}', 'La CLI de Proton instalada no entiende un comando de Hadron Sync; actualiza Hadron Sync. Mensaje de la CLI: {msg}', 'La CLI Proton installée ne comprend pas une commande de Hadron Sync – veuillez mettre à jour Hadron Sync. Message de la CLI : {msg}'),
    ('Hadron Sync: Fehler', 'Hadron Sync: error', 'Hadron Sync: error', 'Hadron Sync : erreur'),
    ('Hadron Sync ist ein inoffizielles, privates und nicht-kommerzielles Projekt von {author}. Es steht in keiner Verbindung zu Proton AG und wird von Proton weder unterstützt noch geprüft. Die Software wurde mithilfe der KI-Assistenten Claude (Anthropic) und Mistral AI erstellt. Installation und Nutzung erfolgen auf eigenes Risiko und ohne Gewähr. Lege vor der Nutzung Sicherungskopien deiner Daten an.', 'Hadron Sync is an unofficial, private and non-commercial project by {author}. It is not affiliated with Proton AG and is neither supported nor reviewed by Proton. The software was created with the help of the AI assistants Claude (Anthropic) and Mistral AI. You install and use it at your own risk and without any warranty. Back up your data before using it.', 'Hadron Sync es un proyecto no oficial, privado y sin fines comerciales de {author}. No tiene relación con Proton AG y Proton no lo respalda ni lo revisa. El software se creó con ayuda de los asistentes de IA Claude (Anthropic) y Mistral AI. La instalación y el uso son bajo tu propia responsabilidad y sin garantía. Haz copias de seguridad de tus datos antes de usarlo.', 'Hadron Sync est un projet non officiel, privé et non commercial de {author}. Il n’est pas affilié à Proton AG et n’est ni soutenu ni vérifié par Proton. Le logiciel a été créé avec l’aide des assistants IA Claude (Anthropic) et Mistral AI. L’installation et l’utilisation se font à vos propres risques et sans garantie. Sauvegardez vos données avant de l’utiliser.'),
    ('Inoffizielles, privates, nicht-kommerzielles Projekt – Nutzung auf eigenes Risiko.', 'Unofficial, private, non-commercial project – use at your own risk.', 'Proyecto no oficial, privado y sin fines comerciales: úsalo bajo tu propia responsabilidad.', 'Projet non officiel, privé et non commercial – utilisation à vos propres risques.'),
    ('Über {app} …', 'About {app} …', 'Acerca de {app} …', 'À propos de {app} …'),
    ('Proton Drive: {n} von etwa {total} Ordnern gelesen …', 'Proton Drive: {n} of about {total} folders read …', 'Proton Drive: {n} de unas {total} carpetas leídas …', 'Proton Drive : {n} dossiers lus sur environ {total} …'),
    ('Vergleiche Dateiinhalte: {n} von {total} …', 'Comparing file contents: {n} of {total} …', 'Comparando contenidos: {n} de {total} …', 'Comparaison des contenus : {n} sur {total} …'),
    ('Fortschritt: {done} von {total} Dateien hochgeladen ({size} von {total_size})', 'Progress: {done} of {total} files uploaded ({size} of {total_size})', 'Progreso: {done} de {total} archivos subidos ({size} de {total_size})', 'Progression : {done} fichiers envoyés sur {total} ({size} sur {total_size})'),
    ('Fortschritt: {done} von {total} Dateien heruntergeladen ({size} von {total_size})', 'Progress: {done} of {total} files downloaded ({size} of {total_size})', 'Progreso: {done} de {total} archivos descargados ({size} de {total_size})', 'Progression : {done} fichiers téléchargés sur {total} ({size} sur {total_size})'),
    ('Setze unterbrochenen Abgleich fort: {n} Dateien sind bereits abgeglichen.', 'Resuming interrupted sync: {n} files are already in sync.', 'Se reanuda la sincronización interrumpida: {n} archivos ya están sincronizados.', 'Reprise de la synchronisation interrompue : {n} fichiers sont déjà synchronisés.'),
    ('Unterbrochener Abgleich – führe vollen Abgleich aus.', 'Interrupted sync – running a full sync.', 'Sincronización interrumpida: se realiza una sincronización completa.', 'Synchronisation interrompue – synchronisation complète.'),
    ('Übersprungen (unzulässiger Name): {path}', 'Skipped (invalid name): {path}', 'Omitido (nombre no válido): {path}', 'Ignoré (nom non valide) : {path}'),
    ('Übersprungen (Ordnername beginnt mit „-“): {path}', "Skipped (folder name starts with '-'): {path}", 'Omitido (el nombre de la carpeta empieza por «-»): {path}', 'Ignoré (le nom du dossier commence par « - ») : {path}'),
    ('Ungültiger Proton-Pfad: {path}', 'Invalid Proton path: {path}', 'Ruta de Proton no válida: {path}', 'Chemin Proton non valide : {path}'),
    ('Einrichtung abgeschlossen: Menüeintrag und Symbole installiert.', 'Setup complete: menu entry and icons installed.', 'Configuración completada: entrada de menú e iconos instalados.', 'Configuration terminée : entrée de menu et icônes installées.'),
    ('Keine Ordnerpaare gespeichert – --local angeben oder in der GUI einrichten.', 'No folder pairs saved – pass --local or set them up in the GUI.', 'No hay pares de carpetas guardados: indica --local o configúralos en la interfaz.', 'Aucune paire de dossiers enregistrée – indiquez --local ou configurez-les dans l’interface.'),
    ('proton-drive nicht gefunden: {path}', 'proton-drive not found: {path}', 'No se encontró proton-drive: {path}', 'proton-drive introuvable : {path}'),
    ('Zeitüberschreitung bei: {cmd}', 'Timeout during: {cmd}', 'Tiempo de espera agotado en: {cmd}', 'Délai dépassé pour : {cmd}'),
    ('{cmd} fehlgeschlagen: {msg}', '{cmd} failed: {msg}', '{cmd} falló: {msg}', 'Échec de {cmd} : {msg}'),
    ('Auflisten von {path} fehlgeschlagen: {msg}', 'Listing {path} failed: {msg}', 'No se pudo listar {path}: {msg}', 'Impossible de lister {path} : {msg}'),
    ('Unerwartete Ausgabe von „filesystem list --json“', "Unexpected output from 'filesystem list --json'", 'Salida inesperada de «filesystem list --json»', 'Sortie inattendue de « filesystem list --json »'),
    ('Unerwartetes JSON-Format von „filesystem list --json“', "Unexpected JSON format from 'filesystem list --json'", 'Formato JSON inesperado de «filesystem list --json»', 'Format JSON inattendu de « filesystem list --json »'),
    ('Übersprungen (Backslash im Namen): {path}', 'Skipped (backslash in name): {path}', 'Omitido (barra invertida en el nombre): {path}', 'Ignoré (barre oblique inverse dans le nom) : {path}'),
    ('Übersprungen (Name nicht entschlüsselbar) in {path}', 'Skipped (name could not be decrypted) in {path}', 'Omitido (no se pudo descifrar el nombre) en {path}', 'Ignoré (nom non déchiffrable) dans {path}'),
    ('Übersprungen (Sonderzeichen im Namen): {path}', 'Skipped (special character in name): {path}', 'Omitido (carácter especial en el nombre): {path}', 'Ignoré (caractère spécial dans le nom) : {path}'),
    ('Übersprungen (Proton Doc/Sheet): {path}', 'Skipped (Proton Doc/Sheet): {path}', 'Omitido (Proton Doc/Sheet): {path}', 'Ignoré (Proton Doc/Sheet) : {path}'),
    ('Übersprungen (Metadaten unvollständig): {path}', 'Skipped (incomplete metadata): {path}', 'Omitido (metadatos incompletos): {path}', 'Ignoré (métadonnées incomplètes) : {path}'),
    ('beidseitig geändert, lokal neuer – Remote-Version wird Konfliktkopie', 'changed on both sides, local is newer – remote version becomes a conflict copy', 'modificado en ambos lados, el local es más reciente – la versión remota pasa a ser una copia en conflicto', 'modifié des deux côtés, la version locale est plus récente – la version distante devient une copie de conflit'),
    ('beidseitig geändert, remote neuer – lokale Version wird Konfliktkopie', 'changed on both sides, remote is newer – local version becomes a conflict copy', 'modificado en ambos lados, el remoto es más reciente – la versión local pasa a ser una copia en conflicto', 'modifié des deux côtés, la version distante est plus récente – la version locale devient une copie de conflit'),
    ('remote gelöscht', 'deleted remotely', 'eliminado en remoto', 'supprimé à distance'),
    ('remote gelöscht, lokal aber geändert', 'deleted remotely but changed locally', 'eliminado en remoto, pero modificado localmente', 'supprimé à distance mais modifié localement'),
    ('lokal gelöscht', 'deleted locally', 'eliminado localmente', 'supprimé localement'),
    ('lokal gelöscht, remote aber geändert', 'deleted locally but changed remotely', 'eliminado localmente, pero modificado en remoto', 'supprimé localement mais modifié à distance'),
    ('Remote-Pfad nicht anlegbar: {path}', 'Cannot create remote path: {path}', 'No se puede crear la ruta remota: {path}', 'Impossible de créer le chemin distant : {path}'),
    ('Upload', 'Upload', 'Subida', 'Envoi'),
    ('Download', 'Download', 'Descarga', 'Téléchargement'),
    ('Papierkorb', 'Trash', 'Papelera', 'Corbeille'),
    ('Ordner-Papierkorb', 'Folder to trash', 'Carpeta a la papelera', 'Dossier vers la corbeille'),
    ('{what}: Sammelaufruf fehlgeschlagen, versuche einzeln …', '{what}: batch call failed, retrying one by one …', '{what}: la llamada por lotes falló, se reintenta uno por uno …', '{what} : l’appel groupé a échoué, nouvel essai un par un …'),
    ('FEHLER {what} {path}: {msg}', 'ERROR {what} {path}: {msg}', 'ERROR {what} {path}: {msg}', 'ERREUR {what} {path} : {msg}'),
    ('FEHLER: „gio“ nicht gefunden – lokaler Papierkorb nicht verfügbar.', "ERROR: 'gio' not found – local trash not available.", 'ERROR: no se encontró «gio»; la papelera local no está disponible.', 'ERREUR : « gio » introuvable – corbeille locale indisponible.'),
    ('FEHLER lokal in Papierkorb {path}: {msg}', 'ERROR moving to local trash {path}: {msg}', 'ERROR al mover a la papelera local {path}: {msg}', 'ERREUR lors du déplacement vers la corbeille locale {path} : {msg}'),
    ('FEHLER Zielordner {path}: {msg}', 'ERROR target folder {path}: {msg}', 'ERROR en la carpeta de destino {path}: {msg}', 'ERREUR dossier cible {path} : {msg}'),
    ('FEHLER: {path} unvollständig heruntergeladen – wird verworfen', 'ERROR: {path} downloaded incompletely – discarded', 'ERROR: {path} se descargó de forma incompleta; se descarta', 'ERREUR : {path} téléchargé de façon incomplète – ignoré'),
    ('Konflikt {path}: Remote-Version nicht gesichert – Datei wird ausgelassen', 'Conflict {path}: remote version could not be saved – file skipped', 'Conflicto {path}: no se pudo guardar la versión remota; se omite el archivo', 'Conflit {path} : version distante non sauvegardée – fichier ignoré'),
    ('Konfliktkopie: {path}', 'Conflict copy: {path}', 'Copia en conflicto: {path}', 'Copie de conflit : {path}'),
    ('FEHLER Konflikt {path}: lokale Version nicht umbenannt ({msg})', 'ERROR conflict {path}: local version not renamed ({msg})', 'ERROR de conflicto {path}: no se renombró la versión local ({msg})', 'ERREUR conflit {path} : version locale non renommée ({msg})'),
    ('Konflikt', 'Conflict', 'Conflicto', 'Conflit'),
    ('Ein anderer Sync für diesen Ordner läuft bereits.', 'Another sync for this folder is already running.', 'Ya hay otra sincronización en curso para esta carpeta.', 'Une autre synchronisation de ce dossier est déjà en cours.'),
    ('Lokaler Ordner existiert nicht: {path}', 'Local folder does not exist: {path}', 'La carpeta local no existe: {path}', 'Le dossier local n’existe pas : {path}'),
    ('Lokaler Ordner ist zu breit gewählt (Wurzel bzw. Home). Bitte einen Unterordner wählen.', 'Local folder is too broad (root or home). Please choose a subfolder.', 'La carpeta local es demasiado amplia (raíz o home). Elige una subcarpeta.', 'Le dossier local est trop large (racine ou dossier personnel). Choisissez un sous-dossier.'),
    ('Proton-Pfad muss mit {root} beginnen.', 'Proton path must start with {root}.', 'La ruta de Proton debe empezar por {root}.', 'Le chemin Proton doit commencer par {root}.'),
    ('Hochladen', 'Upload', 'Subir', 'Envoyer'),
    ('Herunterladen', 'Download', 'Descargar', 'Télécharger'),
    ('Remote in Papierkorb', 'Remote to trash', 'Remoto a la papelera', 'Distant vers la corbeille'),
    ('Lokal in Papierkorb', 'Local to trash', 'Local a la papelera', 'Local vers la corbeille'),
    ('KONFLIKT (beide behalten)', 'CONFLICT (keeping both)', 'CONFLICTO (se conservan ambos)', 'CONFLIT (les deux sont conservés)'),
    ('… und {n} weitere ({label})', '… and {n} more ({label})', '… y {n} más ({label})', '… et {n} de plus ({label})'),
    ('Es sollen {n} Dateien gelöscht werden (von {total} bekannten). Das sieht ungewöhnlich aus. Fortfahren?', '{n} files are about to be deleted (out of {total} known). This looks unusual. Continue?', 'Se van a eliminar {n} archivos (de {total} conocidos). Parece inusual. ¿Continuar?', '{n} fichiers vont être supprimés (sur {total} connus). Cela semble inhabituel. Continuer ?'),
    ('Abgebrochen: viele Löschungen wurden nicht bestätigt.', 'Cancelled: large number of deletions was not confirmed.', 'Cancelado: no se confirmaron las numerosas eliminaciones.', 'Annulé : les nombreuses suppressions n’ont pas été confirmées.'),
    ('Kein gespeicherter Stand – führe vollen Abgleich aus.', 'No saved state – running a full sync.', 'No hay estado guardado; se realiza una sincronización completa.', 'Aucun état enregistré – synchronisation complète.'),
    ('Lokal:  {path}', 'Local:  {path}', 'Local:  {path}', 'Local :  {path}'),
    ('Remote: {path}', 'Remote: {path}', 'Remoto: {path}', 'Distant : {path}'),
    ('Erste Synchronisation (kein gespeicherter Stand): es wird nichts gelöscht.', 'First synchronisation (no saved state): nothing will be deleted.', 'Primera sincronización (sin estado guardado): no se eliminará nada.', 'Première synchronisation (aucun état enregistré) : rien ne sera supprimé.'),
    ('Letzter Stand: {n} Dateien bekannt.', 'Last state: {n} files known.', 'Último estado: {n} archivos conocidos.', 'Dernier état : {n} fichiers connus.'),
    ('Lese lokalen Ordner …', 'Reading local folder …', 'Leyendo la carpeta local …', 'Lecture du dossier local …'),
    ('{files} Dateien, {dirs} Ordner', '{files} files, {dirs} folders', '{files} archivos, {dirs} carpetas', '{files} fichiers, {dirs} dossiers'),
    ('Lese Proton Drive (kann bei vielen Ordnern dauern) …', 'Reading Proton Drive (may take a while with many folders) …', 'Leyendo Proton Drive (puede tardar con muchas carpetas) …', 'Lecture de Proton Drive (peut prendre du temps avec beaucoup de dossiers) …'),
    ('Plan: {up} hochladen, {down} herunterladen, {tr} remote in Papierkorb, {tl} lokal in Papierkorb, {c} Konflikte', 'Plan: {up} upload, {down} download, {tr} remote to trash, {tl} local to trash, {c} conflicts', 'Plan: {up} subir, {down} descargar, {tr} remotos a la papelera, {tl} locales a la papelera, {c} conflictos', 'Plan : {up} à envoyer, {down} à télécharger, {tr} distants vers la corbeille, {tl} locaux vers la corbeille, {c} conflits'),
    ('Trockenlauf – es wurde nichts verändert. (Download {down}, Upload {up})', 'Dry run – nothing was changed. (Download {down}, upload {up})', 'Simulación: no se ha modificado nada. (Descarga {down}, subida {up})', 'Simulation – rien n’a été modifié. (Téléchargement {down}, envoi {up})'),
    ('Nicht genug Speicherplatz: Download {down}, frei {free}.', 'Not enough disk space: download {down}, free {free}.', 'No hay suficiente espacio: descarga {down}, libre {free}.', 'Espace disque insuffisant : téléchargement {down}, libre {free}.'),
    ('Erster Abgleich für\n{pair}\n\n{down_n} Dateien ({down}) werden heruntergeladen,\n{up_n} Dateien ({up}) werden hochgeladen.\n\nFortfahren?', 'First sync for\n{pair}\n\n{down_n} files ({down}) will be downloaded,\n{up_n} files ({up}) will be uploaded.\n\nContinue?', 'Primera sincronización de\n{pair}\n\nSe descargarán {down_n} archivos ({down}),\nse subirán {up_n} archivos ({up}).\n\n¿Continuar?', 'Première synchronisation de\n{pair}\n\n{down_n} fichiers ({down}) seront téléchargés,\n{up_n} fichiers ({up}) seront envoyés.\n\nContinuer ?'),
    ('Abgebrochen: erster Abgleich nicht bestätigt.', 'Cancelled: first sync not confirmed.', 'Cancelado: no se confirmó la primera sincronización.', 'Annulé : première synchronisation non confirmée.'),
    ('Führe aus …', 'Running …', 'Ejecutando …', 'Exécution …'),
    ('Prüfe Ergebnis …', 'Checking result …', 'Comprobando el resultado …', 'Vérification du résultat …'),
    ('Ordner remote angelegt: {path}', 'Folder created remotely: {path}', 'Carpeta creada en remoto: {path}', 'Dossier créé à distance : {path}'),
    ('FEHLER Ordner {path}: {msg}', 'ERROR folder {path}: {msg}', 'ERROR en la carpeta {path}: {msg}', 'ERREUR dossier {path} : {msg}'),
    ('Ordner lokal angelegt: {path}', 'Folder created locally: {path}', 'Carpeta creada localmente: {path}', 'Dossier créé localement : {path}'),
    ('Ordner lokal in Papierkorb: {path}', 'Local folder moved to trash: {path}', 'Carpeta local movida a la papelera: {path}', 'Dossier local placé dans la corbeille : {path}'),
    ('Ordner remote in Papierkorb: {path}', 'Remote folder moved to trash: {path}', 'Carpeta remota movida a la papelera: {path}', 'Dossier distant placé dans la corbeille : {path}'),
    ('Fertig: {ok} Aktionen erfolgreich, {err} Fehler, {copies} Konfliktkopien.', 'Done: {ok} actions succeeded, {err} errors, {copies} conflict copies.', 'Listo: {ok} acciones correctas, {err} errores, {copies} copias en conflicto.', 'Terminé : {ok} actions réussies, {err} erreurs, {copies} copies de conflit.'),
    ('Änderung in Proton Drive erkannt ({path}) – wechsle zum vollen Abgleich.', 'Change detected in Proton Drive ({path}) – switching to a full sync.', 'Cambio detectado en Proton Drive ({path}); se pasa a sincronización completa.', 'Modification détectée dans Proton Drive ({path}) – passage à une synchronisation complète.'),
    ('Schnellabgleich: {up} hochladen, {tr} remote in Papierkorb', 'Quick sync: {up} upload, {tr} remote to trash', 'Sincronización rápida: {up} subir, {tr} remotos a la papelera', 'Synchronisation rapide : {up} à envoyer, {tr} distants vers la corbeille'),
    ('Schnellabgleich fertig: {ok} Aktionen erfolgreich, {err} Fehler.', 'Quick sync done: {ok} actions succeeded, {err} errors.', 'Sincronización rápida lista: {ok} acciones correctas, {err} errores.', 'Synchronisation rapide terminée : {ok} actions réussies, {err} erreurs.'),
    ('Es ist kein Ordnerpaar eingerichtet.', 'No folder pair is set up.', 'No hay ningún par de carpetas configurado.', 'Aucune paire de dossiers n’est configurée.'),
    ('Lokale Ordner überschneiden sich: {a} und {b}', 'Local folders overlap: {a} and {b}', 'Las carpetas locales se solapan: {a} y {b}', 'Les dossiers locaux se chevauchent : {a} et {b}'),
    ('Proton-Ordner überschneiden sich: {a} und {b}', 'Proton folders overlap: {a} and {b}', 'Las carpetas de Proton se solapan: {a} y {b}', 'Les dossiers Proton se chevauchent : {a} et {b}'),
    ('Bereit', 'Ready', 'Listo', 'Prêt'),
    ('Jetzt synchronisieren', 'Sync now', 'Sincronizar ahora', 'Synchroniser maintenant'),
    ('Einstellungen öffnen', 'Open settings', 'Abrir ajustes', 'Ouvrir les paramètres'),
    ('Beenden', 'Quit', 'Salir', 'Quitter'),
    ('Synchronisiere …', 'Syncing …', 'Sincronizando …', 'Synchronisation …'),
    ('Fehler: {msg}', 'Error: {msg}', 'Error: {msg}', 'Erreur : {msg}'),
    ('Aktuell – letzter Abgleich {time}', 'Up to date – last sync {time}', 'Al día – última sincronización {time}', 'À jour – dernière synchronisation {time}'),
    ('(+{n} weitere)', '(+{n} more)', '(+{n} más)', '(+{n} de plus)'),
    ('Ordner fehlt, keine Überwachung: {path}', 'Folder missing, not monitored: {path}', 'Falta la carpeta, sin supervisión: {path}', 'Dossier manquant, non surveillé : {path}'),
    ('Ordnerüberwachung nicht möglich (inotify-Limit?) – es gilt nur das Intervall.', 'Folder monitoring not possible (inotify limit?) – only the interval applies.', 'No es posible supervisar las carpetas (¿límite de inotify?); solo se aplica el intervalo.', 'Surveillance des dossiers impossible (limite inotify ?) – seul l’intervalle s’applique.'),
    ('Überwache {dirs} Ordner in {pairs} Ordnerpaar(en).', 'Monitoring {dirs} folders in {pairs} folder pair(s).', 'Supervisando {dirs} carpetas en {pairs} par(es) de carpetas.', 'Surveillance de {dirs} dossiers dans {pairs} paire(s) de dossiers.'),
    ('Trockenlauf nicht möglich, während ein Sync läuft.', 'Dry run not possible while a sync is running.', 'No se puede simular mientras hay una sincronización en curso.', 'Simulation impossible pendant une synchronisation.'),
    ('Neuer Versuch in einer Minute.', 'Retrying in one minute.', 'Nuevo intento en un minuto.', 'Nouvel essai dans une minute.'),
    ('FEHLER: {msg}', 'ERROR: {msg}', 'ERROR: {msg}', 'ERREUR : {msg}'),
    ('UNERWARTETER FEHLER: {msg}', 'UNEXPECTED ERROR: {msg}', 'ERROR INESPERADO: {msg}', 'ERREUR INATTENDUE : {msg}'),
    ('{n} Fehler – siehe Protokoll', '{n} errors – see log', '{n} errores – ver el registro', '{n} erreurs – voir le journal'),
    ('{n} Konfliktkopien angelegt: {names}', '{n} conflict copies created: {names}', '{n} copias en conflicto creadas: {names}', '{n} copies de conflit créées : {names}'),
    ('Bestätigung erforderlich', 'Confirmation required', 'Se requiere confirmación', 'Confirmation requise'),
    ('Ordnerpaare (lokaler Ordner ↔ Ordner in Proton Drive)', 'Folder pairs (local folder ↔ folder in Proton Drive)', 'Pares de carpetas (carpeta local ↔ carpeta en Proton Drive)', 'Paires de dossiers (dossier local ↔ dossier dans Proton Drive)'),
    ('Lokal', 'Local', 'Local', 'Local'),
    ('Hinzufügen …', 'Add …', 'Añadir …', 'Ajouter …'),
    ('Bearbeiten …', 'Edit …', 'Editar …', 'Modifier …'),
    ('Entfernen', 'Remove', 'Quitar', 'Supprimer'),
    ('Ausschlüsse', 'Exclusions', 'Exclusiones', 'Exclusions'),
    ('Sprache', 'Language', 'Idioma', 'Langue'),
    ('Automatisch (Systemsprache)', 'Automatic (system language)', 'Automático (idioma del sistema)', 'Automatique (langue du système)'),
    ('Beim Anmelden automatisch im Hintergrund starten', 'Start automatically in the background at login', 'Iniciar automáticamente en segundo plano al iniciar sesión', 'Démarrer automatiquement en arrière-plan à la connexion'),
    ('Lokale Änderungen sofort synchronisieren', 'Sync local changes immediately', 'Sincronizar los cambios locales al instante', 'Synchroniser immédiatement les modifications locales'),
    ('Vollabgleich alle', 'Full sync every', 'Sincronización completa cada', 'Synchronisation complète toutes les'),
    ('Minuten (0 = aus). Nur der Vollabgleich erkennt Änderungen in Proton Drive.', 'minutes (0 = off). Only the full sync detects changes in Proton Drive.', 'minutos (0 = desactivado). Solo la sincronización completa detecta cambios en Proton Drive.', 'minutes (0 = désactivé). Seule la synchronisation complète détecte les modifications dans Proton Drive.'),
    ('Speichern & anwenden', 'Save & apply', 'Guardar y aplicar', 'Enregistrer et appliquer'),
    ('Trockenlauf', 'Dry run', 'Simulación', 'Simulation'),
    ('Anmelden', 'Sign in', 'Iniciar sesión', 'Se connecter'),
    ('Sync abbrechen', 'Cancel sync', 'Cancelar sincronización', 'Annuler la synchronisation'),
    ('Hinweis: Tray-Icon nicht verfügbar. Installiere gir1.2-ayatanaappindicator3-0.1 und aktiviere die AppIndicator-Erweiterung.', 'Note: tray icon not available. Install gir1.2-ayatanaappindicator3-0.1 and enable the AppIndicator extension.', 'Nota: el icono de la bandeja no está disponible. Instala gir1.2-ayatanaappindicator3-0.1 y activa la extensión AppIndicator.', 'Remarque : icône de la zone de notification indisponible. Installez gir1.2-ayatanaappindicator3-0.1 et activez l’extension AppIndicator.'),
    ('Ordnerpaar hinzugefügt – mit „Speichern & anwenden“ übernehmen.', 'Folder pair added – apply with “Save & apply”.', 'Par de carpetas añadido: aplícalo con «Guardar y aplicar».', 'Paire de dossiers ajoutée – appliquez avec « Enregistrer et appliquer ».'),
    ('Bitte zuerst ein Ordnerpaar auswählen.', 'Please select a folder pair first.', 'Selecciona primero un par de carpetas.', 'Veuillez d’abord sélectionner une paire de dossiers.'),
    ('Ordnerpaar geändert – mit „Speichern & anwenden“ übernehmen. Ein geändertes Paar wird wie ein neues behandelt (erster Abgleich).', 'Folder pair changed – apply with “Save & apply”. A changed pair is treated like a new one (first sync).', 'Par de carpetas modificado: aplícalo con «Guardar y aplicar». Un par modificado se trata como uno nuevo (primera sincronización).', 'Paire de dossiers modifiée – appliquez avec « Enregistrer et appliquer ». Une paire modifiée est traitée comme une nouvelle (première synchronisation).'),
    ('Ordnerpaar entfernt – mit „Speichern & anwenden“ übernehmen. Dateien bleiben auf beiden Seiten erhalten.', 'Folder pair removed – apply with “Save & apply”. Files are kept on both sides.', 'Par de carpetas quitado: aplícalo con «Guardar y aplicar». Los archivos se conservan en ambos lados.', 'Paire de dossiers supprimée – appliquez avec « Enregistrer et appliquer ». Les fichiers sont conservés des deux côtés.'),
    ('Ordnerpaar', 'Folder pair', 'Par de carpetas', 'Paire de dossiers'),
    ('Abbrechen', 'Cancel', 'Cancelar', 'Annuler'),
    ('Lokaler Ordner', 'Local folder', 'Carpeta local', 'Dossier local'),
    ('Wählen …', 'Choose …', 'Elegir …', 'Choisir …'),
    ('Ordner in Proton Drive', 'Folder in Proton Drive', 'Carpeta en Proton Drive', 'Dossier dans Proton Drive'),
    ('Durchsuchen …', 'Browse …', 'Examinar …', 'Parcourir …'),
    ('Ein noch nicht vorhandener Proton-Ordner wird beim ersten Abgleich angelegt.', 'A Proton folder that does not exist yet will be created during the first sync.', 'Una carpeta de Proton que aún no exista se creará en la primera sincronización.', 'Un dossier Proton qui n’existe pas encore sera créé lors de la première synchronisation.'),
    ('Lokalen Ordner wählen', 'Choose local folder', 'Elegir carpeta local', 'Choisir le dossier local'),
    ('Wählen', 'Choose', 'Elegir', 'Choisir'),
    ('Ordner in Proton Drive wählen', 'Choose folder in Proton Drive', 'Elegir carpeta en Proton Drive', 'Choisir un dossier dans Proton Drive'),
    ('Diesen Ordner wählen', 'Choose this folder', 'Elegir esta carpeta', 'Choisir ce dossier'),
    ('↑ Übergeordneter Ordner', '↑ Parent folder', '↑ Carpeta superior', '↑ Dossier parent'),
    ('Unterordner (Doppelklick öffnet)', 'Subfolders (double-click to open)', 'Subcarpetas (doble clic para abrir)', 'Sous-dossiers (double-clic pour ouvrir)'),
    ('Lade {path} …', 'Loading {path} …', 'Cargando {path} …', 'Chargement de {path} …'),
    ('Nicht gespeichert: {msg}', 'Not saved: {msg}', 'No guardado: {msg}', 'Non enregistré : {msg}'),
    ('Autostart konnte nicht gesetzt werden: {msg}', 'Could not set autostart: {msg}', 'No se pudo configurar el inicio automático: {msg}', 'Impossible de configurer le démarrage automatique : {msg}'),
    ('Gespeichert.', 'Saved.', 'Guardado.', 'Enregistré.'),
    ('Bitte Änderungen an den Ordnerpaaren zuerst speichern.', 'Please save changes to the folder pairs first.', 'Guarda primero los cambios en los pares de carpetas.', 'Veuillez d’abord enregistrer les modifications des paires de dossiers.'),
    ('Anmeldung gestartet – bitte im Browser bestätigen …', 'Sign-in started – please confirm in your browser …', 'Inicio de sesión en curso: confírmalo en el navegador …', 'Connexion lancée – veuillez confirmer dans le navigateur …'),
    ('Anmeldung erfolgreich.', 'Sign-in successful.', 'Inicio de sesión correcto.', 'Connexion réussie.'),
    ('Anmeldung fehlgeschlagen.', 'Sign-in failed.', 'Error al iniciar sesión.', 'Échec de la connexion.'),
    ('GTK nicht verfügbar ({msg}).\nInstalliere: {cmd}', 'GTK not available ({msg}).\nInstall: {cmd}', 'GTK no disponible ({msg}).\nInstala: {cmd}', 'GTK indisponible ({msg}).\nInstallez : {cmd}'),
]
MESSAGES = {code: {row[0]: row[i] for row in CATALOG} for i, code in enumerate(("de", "en", "es", "fr"))}
_LANG = "de"  # wird unten auf die Systemsprache gesetzt


DISCLAIMER = ("Hadron Sync ist ein inoffizielles, privates und nicht-kommerzielles Projekt von {author}. Es steht in "
              "keiner Verbindung zu Proton AG und wird von Proton weder unterstützt noch geprüft. Die Software wurde "
              "mithilfe der KI-Assistenten Claude (Anthropic) und Mistral AI erstellt. Installation und Nutzung erfolgen "
              "auf eigenes Risiko und ohne Gewähr. Lege vor der Nutzung Sicherungskopien deiner Daten an.")


def about_text():
    return (f"{APP_NAME} {APP_VERSION} ({APP_DATE})\n{APP_AUTHOR} <{APP_CONTACT}>\n\n{disclaimer()}")


def disclaimer():
    return T(DISCLAIMER, author=APP_AUTHOR)


def detect_language():
    for var in ("LANGUAGE", "LC_ALL", "LC_MESSAGES", "LANG"):
        for part in os.environ.get(var, "").split(":"):
            code = part[:2].lower()
            if code in MESSAGES:
                return code
    return "en"


def set_language(code):
    global _LANG
    _LANG = code if code in MESSAGES else detect_language()
    return _LANG


def T(key, **kw):
    text = MESSAGES.get(_LANG, {}).get(key, key)
    return text.format(**kw) if kw else text


set_language("auto")


ICON_APP, ICON_IDLE, ICON_SCAN, ICON_BUSY, ICON_ERROR = (
    "hadron-sync", "hadron-sync-tray-idle", "hadron-sync-tray-scan",
    "hadron-sync-tray-busy", "hadron-sync-tray-error")
ICON_MARK_PREFIX = "<!--hadron-sync-icon-"
ICON_MARKER = "<!--hadron-sync-icon-v2-->"
_CLOUD = ('<g fill="{c}"><circle cx="32" cy="30" r="24"/><circle cx="16" cy="42" r="16"/>'
          '<circle cx="48" cy="42" r="16"/><rect x="16" y="42" width="32" height="16"/></g>')
_SVG = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 4 64 56" width="64" height="56">'
        + ICON_MARKER + '{}</svg>\n')
SVG_IDLE = _SVG.format(_CLOUD.format(c="#6d4aff") + '<path d="M20 40 29 49 45 31" fill="none" stroke="#fff" '
                       'stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>')
SVG_SCAN = _SVG.format(_CLOUD.format(c="#f5a623") +
                       '<g fill="#fff"><circle cx="21" cy="42" r="4.4"/><circle cx="32" cy="42" r="4.4"/>'
                       '<circle cx="43" cy="42" r="4.4"/></g>')
SVG_BUSY = _SVG.format(_CLOUD.format(c="#2f80ed") +
                       '<g fill="none" stroke="#fff" stroke-width="5.6"><path d="M18.84 35.21A14 14 0 0 1 45.16 35.21"/>'
                       '<path d="M45.16 44.79A14 14 0 0 1 18.84 44.79"/></g><g fill="#fff">'
                       '<path d="M47.26 40.98 51.08 33.05 39.25 37.36z"/><path d="M16.74 39.02 12.92 46.95 24.75 42.64z"/></g>')
SVG_ERROR = _SVG.format(_CLOUD.format(c="#e5484d") + '<rect x="29" y="24" width="6" height="18" rx="3" fill="#fff"/>'
                        '<circle cx="32" cy="48" r="3.6" fill="#fff"/>')
ICONS = {ICON_APP: SVG_IDLE, ICON_IDLE: SVG_IDLE, ICON_SCAN: SVG_SCAN, ICON_BUSY: SVG_BUSY, ICON_ERROR: SVG_ERROR}


# Login-Links (mit Einmal-Daten) nie in Dateien schreiben
_REDACT = re.compile(r"https?://\S*(?:payload|token|code|login)\S*", re.IGNORECASE)


def redact(text):
    return _REDACT.sub("[…]", str(text))


def private_dir(path):
    """Ordner nur fuer den eigenen Benutzer (700)."""
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path, 0o700)
    except OSError:
        pass
    return path


def write_private(path, text):
    """Schreibt eine Datei atomar mit Rechten 600."""
    path = Path(path)
    private_dir(path.parent)
    tmp = path.with_name(path.name + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def secure_existing():
    """Korrigiert Rechte von Dateien aus frueheren Versionen."""
    for d in (CONFIG_DIR, STATE_DIR):
        if d.is_dir():
            try:
                os.chmod(d, 0o700)
                for f in d.iterdir():
                    if f.is_file():
                        os.chmod(f, 0o600)
            except OSError:
                pass


def file_log(msg):
    try:
        private_dir(STATE_DIR)
        if LOG_FILE.exists() and LOG_FILE.stat().st_size > 1_000_000:
            LOG_FILE.replace(LOG_FILE.with_suffix(".log.1"))
        fd = os.open(LOG_FILE, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
        with os.fdopen(fd, "a", encoding="utf-8") as fh:
            fh.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} {redact(msg)}\n")
    except OSError:
        pass


def human_time(seconds):
    seconds = int(max(0, seconds))
    if seconds >= 3600:
        return T("{h} Std. {m} Min.", h=seconds // 3600, m=(seconds % 3600) // 60)
    if seconds >= 60:
        return T("{m} Min.", m=seconds // 60)
    return T("{s} Sek.", s=seconds)


def human(n):
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if n < 1024 or unit == "TiB":
            return f"{n} B" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024


class SyncError(Exception):
    pass


class NotFound(SyncError):
    pass


class Busy(SyncError):
    pass


class Cancelled(Exception):
    pass


class Priority(Exception):
    """Ein Aenderungsprotokoll-Fund hat Vorrang: der laufende Abgleich bricht sauber ab und wird spaeter fortgesetzt."""
    pass


class CancelToken:
    def __init__(self):
        self._ev = threading.Event()
        self._prio = threading.Event()

    def set(self):
        self._ev.set()

    def request_priority(self):
        self._prio.set()

    def check(self):
        if self._ev.is_set():
            raise Cancelled()
        if self._prio.is_set():
            raise Priority()


class Sig(NamedTuple):
    mtime: float
    size: int
    sha1: Optional[str] = None


def same(a: Sig, b: Sig) -> bool:
    return a.size == b.size and abs(a.mtime - b.mtime) <= TOLERANCE


def sha1_file(path) -> str:
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def excluded(name, patterns) -> bool:
    if name == TMP_DIR_NAME:
        return True
    return any(fnmatch.fnmatch(name, p) for p in patterns)


def parse_excludes(text):
    return [p.strip() for p in text.split(",") if p.strip()]


# --------------------------------------------------------------------------- CLI

class Cli:
    def __init__(self, binary):
        self.binary = binary

    def run(self, *args, timeout=None):
        try:
            p = subprocess.run([self.binary, *args], capture_output=True, text=True, timeout=timeout,
                               stdin=subprocess.DEVNULL)  # CLI-Rueckfragen koennen nie haengen bleiben
        except FileNotFoundError:
            raise SyncError(T("proton-drive nicht gefunden: {path}", path=self.binary))
        except subprocess.TimeoutExpired:
            raise SyncError(T("Zeitüberschreitung bei: {cmd}", cmd=" ".join(args[:3])))
        return p.returncode, p.stdout, p.stderr

    @staticmethod
    def message(out, err):
        """Die CLI verteilt ihre Meldungen auf beide Ausgaben - immer beide ansehen."""
        return "\n".join(part.strip() for part in (err, out) if part and part.strip())

    def check(self, *args):
        rc, out, err = self.run(*args)
        if rc != 0:
            raise SyncError(T("{cmd} fehlgeschlagen: {msg}", cmd=" ".join(args[:2]), msg=self.message(out, err)[:300]))
        return out

    def list_dir(self, remote_path):
        rc, out, err = self.run("filesystem", "list", remote_path, "--json", timeout=300)
        if rc != 0:
            msg = self.message(out, err)
            if "not found" in msg.lower():
                raise NotFound(msg)
            raise SyncError(T("Auflisten von {path} fehlgeschlagen: {msg}", path=remote_path, msg=msg[:300]))
        return parse_json_list(out)


_USAGE_ERROR = re.compile(r"Unknown option|Unknown argument|Unexpected argument|Command not found|"
                          r"Invalid value for|Missing required", re.IGNORECASE)


def check_usage_error(msg):
    """Die CLI versteht einen Befehl nicht (z. B. nach einem CLI-Update): sofort abbrechen, statt je Datei zu scheitern."""
    if msg and _USAGE_ERROR.search(msg):
        raise SyncError(T("Die installierte Proton-CLI versteht einen Befehl von Hadron Sync nicht – bitte Hadron Sync "
                          "aktualisieren. Meldung der CLI: {msg}", msg=msg.strip()[:300]))


def parse_json_list(out):
    out = out.strip()
    if not out:
        return []
    try:
        data = json.loads(out)
    except json.JSONDecodeError:
        a, b = out.find("["), out.rfind("]")
        if a < 0 or b < a:
            raise SyncError(T("Unerwartete Ausgabe von „filesystem list --json“"))
        data = json.loads(out[a:b + 1])
    if not isinstance(data, list):
        raise SyncError(T("Unerwartetes JSON-Format von „filesystem list --json“"))
    return data


def iso_to_epoch(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()


def node_name(node):
    n = node.get("name")
    if isinstance(n, dict):
        return n.get("value") if n.get("ok") else None
    return n


# --------------------------------------------------------------------------- Scans

def name_problem(name, is_dir):
    """Liefert den Grund, warum ein Name nicht synchronisiert wird, sonst None (lokal und remote gleich)."""
    if "\\" in name:
        return "Übersprungen (Backslash im Namen): {path}"
    if "/" in name:
        return "Übersprungen (Sonderzeichen im Namen): {path}"
    if name in ("", ".", ".."):
        return "Übersprungen (unzulässiger Name): {path}"
    if is_dir and name.startswith("-"):  # wuerde von der CLI als Option gelesen (create-folder)
        return "Übersprungen (Ordnername beginnt mit „-“): {path}"
    return None


def scan_local(root, excludes, log):
    files, dirs = {}, set()
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = os.path.relpath(dirpath, root)
        rel_dir = "" if rel_dir == "." else rel_dir
        keep = []
        for d in dirnames:
            full = os.path.join(dirpath, d)
            if excluded(d, excludes) or os.path.islink(full):
                continue
            problem = name_problem(d, True)
            if problem:
                log("  " + T(problem, path=os.path.join(rel_dir, d)))
                continue
            keep.append(d)
            dirs.add(os.path.join(rel_dir, d) if rel_dir else d)
        dirnames[:] = keep
        for f in filenames:
            full = os.path.join(dirpath, f)
            if excluded(f, excludes) or os.path.islink(full) or not os.path.isfile(full):
                continue
            rel = os.path.join(rel_dir, f) if rel_dir else f
            problem = name_problem(f, False)
            if problem:
                log("  " + T(problem, path=rel))
                continue
            st = os.stat(full)
            files[rel] = Sig(st.st_mtime, st.st_size)
    return files, dirs


def list_many(cli, remotes, workers, cancel, log, missing_ok=()):
    """Liest mehrere Proton-Ordner, bei workers > 1 gleichzeitig. Einzelne Fehlschlaege werden seriell wiederholt
    (die CLI kann sich bei gleichzeitigen Aufrufen an ihrem Zwischenspeicher verschlucken)."""
    out, missing, retry = {}, set(), []

    def take(remote, nodes_or_exc):
        if isinstance(nodes_or_exc, NotFound):
            if remote in missing_ok:
                missing.add(remote)
                return
            raise nodes_or_exc
        if isinstance(nodes_or_exc, BaseException):
            retry.append(remote)
            return
        out[remote] = nodes_or_exc

    if workers <= 1 or len(remotes) == 1:
        for remote in remotes:
            cancel.check()
            try:
                take(remote, cli.list_dir(remote))
            except NotFound as e:
                take(remote, e)
            except SyncError as e:
                take(remote, e)   # vorübergehender Fehler: unten noch einmal versuchen
    else:
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
            futures = {ex.submit(cli.list_dir, r): r for r in remotes}
            try:
                for fut in concurrent.futures.as_completed(futures):
                    cancel.check()
                    try:
                        take(futures[fut], fut.result())
                    except NotFound as e:
                        take(futures[fut], e)
                    except SyncError as e:
                        take(futures[fut], e)
            except BaseException:
                ex.shutdown(wait=False, cancel_futures=True)
                raise
    for remote in retry:  # weitere Versuche, einzeln und mit kurzer Wartezeit
        for attempt, pause in enumerate(RETRY_PAUSES, 1):
            cancel.check()
            log("  " + T("Ordner erneut gelesen (einzeln): {path}", path=remote))
            try:
                out[remote] = cli.list_dir(remote)
                break
            except NotFound as e:
                take(remote, e)
                break
            except SyncError:
                if attempt == len(RETRY_PAUSES):
                    raise
                time.sleep(pause)
    return out, missing


def scan_remote(cli, root, excludes, log, cancel, root_missing_ok=False, estimate=None, workers=PARALLEL_DEFAULT,
                progress=None):
    files, dirs = {}, set()
    pending = [""]
    done, last = 0, time.monotonic()
    while pending:
        cancel.check()
        if time.monotonic() - last >= PROGRESS_S:
            last = time.monotonic()
            log("  " + T("Proton Drive: {n} von etwa {total} Ordnern gelesen …", n=done,
                         total=max(estimate or 0, done + len(pending))))
        if progress:
            progress("scan", done, max(estimate or 0, done + len(pending)))
        batch, pending = pending[:max(workers, 1) * 4], pending[max(workers, 1) * 4:]
        remotes = {root + ("/" + rel if rel else ""): rel for rel in batch}
        listed, missing = list_many(cli, list(remotes), workers, cancel, log,
                                    missing_ok={root} if root_missing_ok else ())
        if root_missing_ok and root in missing:
            return files, dirs
        done += len(batch)
        for remote, nodes in listed.items():
            rel = remotes[remote]
            for node in nodes:
                name = node_name(node)
                if name is None:
                    log("  " + T("Übersprungen (Name nicht entschlüsselbar) in {path}", path=remote))
                    continue
                if excluded(name, excludes):
                    continue
                kind = node.get("type")
                problem = name_problem(name, kind == "folder")
                if problem:
                    log("  " + T(problem, path=f"{remote}/{name}"))
                    continue
                crel = f"{rel}/{name}" if rel else name
                if kind == "folder":
                    dirs.add(crel)
                    pending.append(crel)
                elif kind == "file":
                    sig = file_sig(node, crel, log)
                    if sig is not None:
                        files[crel] = sig
    return files, dirs


def file_sig(node, crel, log):
    media = node.get("mediaType") or ""
    if "vnd.proton" in media:  # Proton Docs/Sheets: nicht herunterladbar (Annahme, nicht verifiziert)
        log("  " + T("Übersprungen (Proton Doc/Sheet): {path}", path=crel))
        return None
    rev = node.get("activeRevision") or {}
    ts = rev.get("claimedModificationTime") or node.get("modificationTime")
    size = rev.get("claimedSize")
    if ts is None or size is None:
        log("  " + T("Übersprungen (Metadaten unvollständig): {path}", path=crel))
        return None
    sha = (rev.get("claimedDigests") or {}).get("sha1")
    return Sig(iso_to_epoch(ts), int(size), sha.lower() if sha else None)


def refresh_remote_dirs(cli, rroot, parents, rf, excludes, log, cancel=None, workers=PARALLEL_DEFAULT):
    """Liest nur die angegebenen Remote-Ordner neu ein und aktualisiert das bekannte Remote-Abbild."""
    rf2 = dict(rf)
    missing = set()
    remotes = {rroot + ("/" + p if p else ""): p for p in sorted(parents)}
    listed, gone = list_many(cli, list(remotes), workers, cancel or CancelToken(), log, missing_ok=set(remotes))
    missing = {remotes[r] for r in gone}
    for remote, parent in remotes.items():
        nodes = listed.get(remote, [])
        present = set()
        for node in nodes:
            name = node_name(node)
            if (name is None or node.get("type") != "file" or excluded(name, excludes)
                    or name_problem(name, False)):
                continue
            crel = f"{parent}/{name}" if parent else name
            sig = file_sig(node, crel, log)
            if sig is not None:
                rf2[crel] = sig
                present.add(crel)
        if remote in listed or remote in gone:
            for p in [p for p in rf2 if p.rpartition("/")[0] == parent and p not in present]:
                del rf2[p]
    return rf2, missing


# --------------------------------------------------------------------------- Plan

@dataclass
class Plan:
    upload: list = field(default_factory=list)
    download: list = field(default_factory=list)
    trash_local: list = field(default_factory=list)
    trash_remote: list = field(default_factory=list)
    conflicts: list = field(default_factory=list)   # beidseitig geaendert -> beide Versionen behalten
    winner: dict = field(default_factory=dict)      # Konfliktpfad -> 'local' | 'remote' (behaelt den Namen)
    conflict_copies: list = field(default_factory=list)
    notes: dict = field(default_factory=dict)
    errors: int = 0
    dirs_created: int = 0
    full: bool = False

    def deletions(self):
        return len(self.trash_local) + len(self.trash_remote)

    def total(self):
        return (len(self.upload) + len(self.download) + self.deletions() + len(self.conflicts))


def decide(lf, rf, base, lroot, log=None):
    plan = Plan()
    paths = sorted(set(lf) | set(rf) | set(base))
    last = time.monotonic()
    for i, p in enumerate(paths):
        if log and time.monotonic() - last >= PROGRESS_S:
            last = time.monotonic()
            log("  " + T("Vergleiche Dateiinhalte: {n} von {total} …", n=i, total=len(paths)))
        l, r, b = lf.get(p), rf.get(p), base.get(p)
        if l and r:
            if b and same(l, b[0]) and same(r, b[1]):
                continue
            if l.size == r.size:
                if r.sha1:  # Hash vorhanden: er entscheidet (Zeitstempel koennen bei Aenderungen gleich bleiben)
                    identical = sha1_file(os.path.join(lroot, p)) == r.sha1
                else:
                    identical = abs(l.mtime - r.mtime) <= TOLERANCE
                if identical:
                    continue  # gleicher Inhalt
            lc = not b or not same(l, b[0])
            rc = not b or not same(r, b[1])
            if lc and not rc:
                plan.upload.append(p)
            elif rc and not lc:
                plan.download.append(p)
            else:
                plan.conflicts.append(p)
                if l.mtime > r.mtime + TOLERANCE:
                    plan.winner[p] = "local"
                    plan.notes[p] = T("beidseitig geändert, lokal neuer – Remote-Version wird Konfliktkopie")
                else:
                    plan.winner[p] = "remote"
                    plan.notes[p] = T("beidseitig geändert, remote neuer – lokale Version wird Konfliktkopie")
        elif l and not r:
            if b and same(l, b[0]):
                plan.trash_local.append(p)
                plan.notes[p] = T("remote gelöscht")
            else:
                plan.upload.append(p)
                if b:
                    plan.notes[p] = T("remote gelöscht, lokal aber geändert")
        elif r and not l:
            if b and same(r, b[1]):
                plan.trash_remote.append(p)
                plan.notes[p] = T("lokal gelöscht")
            else:
                plan.download.append(p)
                if b:
                    plan.notes[p] = T("lokal gelöscht, remote aber geändert")
    return plan


# --------------------------------------------------------------------------- Zustand

def state_path(local, remote):
    key = hashlib.sha1(f"{os.path.abspath(local)}|{remote}".encode()).hexdigest()[:12]
    return CONFIG_DIR / f"state-{key}.json"


def load_state(path):
    if not path.exists():
        return {}, set()
    d = json.loads(path.read_text())
    files = {p: (Sig(*v["l"]), Sig(*v["r"])) for p, v in d.get("files", {}).items()}
    return files, set(d.get("dirs", []))


def state_complete(path):
    """False, wenn der Stand von einem unterbrochenen Abgleich stammt (Zwischenstand)."""
    try:
        return bool(json.loads(path.read_text()).get("complete", True))
    except (OSError, ValueError):
        return True


def save_state(path, files, dirs, complete=True):
    data = {
        "version": 1,
        "complete": complete,
        "files": {p: {"l": [l.mtime, l.size], "r": [r.mtime, r.size]} for p, (l, r) in files.items()},
        "dirs": sorted(dirs),
    }
    write_private(path, json.dumps(data))


# --------------------------------------------------------------------------- Ausfuehrung

def chunks(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def group_by_parent(paths):
    groups = {}
    for p in paths:
        groups.setdefault(p.rpartition("/")[0], []).append(p)
    return groups


def is_empty(d, files, dirs):
    prefix = d + "/"
    return not any(p.startswith(prefix) for p in files) and not any(x.startswith(prefix) for x in dirs)


class Syncer:
    def __init__(self, cli, lroot, rroot, log, cancel, thumbnails=True):
        self.cli, self.lroot, self.rroot, self.log, self.cancel = cli, lroot, rroot, log, cancel
        self.rdirs = set()
        self.thumbnails = thumbnails
        self.workers = PARALLEL_DEFAULT

    def rpath(self, rel):
        return self.rroot + ("/" + rel if rel else "")

    def lpath(self, rel):
        return os.path.join(self.lroot, rel) if rel else self.lroot

    def lglob(self, rel):
        """Lokaler Pfad fuer die CLI: sie liest [ ] * ? als Suchmuster, deshalb maskieren."""
        return re.sub(r"([\[\]*?])", r"\\\1", self.lpath(rel))

    def ensure_remote_root(self, root=None):
        root = root or self.rroot
        try:
            self.cli.list_dir(root)
            return
        except NotFound:
            pass
        parent, _, name = root.rstrip("/").rpartition("/")
        if not parent:
            raise SyncError(T("Remote-Pfad nicht anlegbar: {path}", path=root))
        self.ensure_remote_root(parent)
        self.cli.check("filesystem", "create-folder", parent, name)

    def ensure_remote_dir(self, rel):
        if not rel or rel in self.rdirs:
            return
        parent, _, name = rel.rpartition("/")
        self.ensure_remote_dir(parent)
        try:
            self.cli.check("filesystem", "create-folder", self.rpath(parent), name)
        except SyncError as e:
            try:
                self.cli.list_dir(self.rpath(rel))  # Ordner existiert evtl. schon
            except SyncError:
                raise e
        self.rdirs.add(rel)

    def _upload_call(self, items, parent, skip_thumbs=None):
        args = ["filesystem", "upload", "--file-conflict-strategy", "replace"]
        skip = (not self.thumbnails) if skip_thumbs is None else skip_thumbs
        if skip:
            args.append("--skip-thumbnails")
        rc, out, err = self.cli.run(*args, *[self.lglob(i) for i in items], self.rpath(parent))
        if rc != 0 and skip_thumbs is None and self.thumbnails and len(items) == 1 \
                and "thumbnail" in Cli.message(out, err).lower():
            # Datei ist kein gueltiges Bild o. Ae.: erneut ohne Vorschaubild versuchen
            rc2, out2, err2 = self._upload_call(items, parent, skip_thumbs=True)
            if rc2 == 0:
                self.log("  " + T("Ohne Vorschaubild hochgeladen: {path}", path=items[0]))
            return rc2, out2, err2
        return rc, out, err

    def _batch(self, items, run, failed, what):
        rc, out, err = run(items)
        if rc == 0:
            return
        check_usage_error(Cli.message(out, err))
        if len(items) > 1:
            self.log("  " + T("{what}: Sammelaufruf fehlgeschlagen, versuche einzeln …", what=T(what)))
            for it in items:
                self.cancel.check()
                rc, out, err = run([it])
                if rc != 0:
                    check_usage_error(Cli.message(out, err))
                    failed.add(it)
                    self.log("  " + T("FEHLER {what} {path}: {msg}", what=T(what), path=it,
                                      msg=Cli.message(out, err)[:300]))
        else:
            failed.add(items[0])
            self.log("  " + T("FEHLER {what} {path}: {msg}", what=T(what), path=items[0], msg=Cli.message(out, err)[:300]))

    def local_trash(self, rels):
        failed = set()
        if not rels:
            return failed
        if not shutil.which("gio"):
            self.log("  " + T("FEHLER: „gio“ nicht gefunden – lokaler Papierkorb nicht verfügbar."))
            return set(rels)
        for r in rels:
            p = subprocess.run(["gio", "trash", "--", self.lpath(r)], capture_output=True, text=True)
            if p.returncode != 0:
                failed.add(r)
                self.log("  " + T("FEHLER lokal in Papierkorb {path}: {msg}", path=r, msg=p.stderr.strip()[:300]))
        return failed

    def uploads(self, paths, failed, done=None):
        for parent, group in group_by_parent(paths).items():
            self.cancel.check()
            try:
                self.ensure_remote_dir(parent)
            except SyncError as e:
                failed.update(group)
                self.log("  " + T("FEHLER Zielordner {path}: {msg}", path=parent or "/", msg=e))
                continue
            for chunk in chunks(group, BATCH):
                self.cancel.check()
                for p in chunk:
                    self.log(f"  ↑ {p}")
                self._batch(chunk, lambda items, par=parent: self._upload_call(items, par), failed, "Upload")
                if done:
                    done("up", [p for p in chunk if p not in failed])

    def tmp_root(self):
        return os.path.join(self.lroot, TMP_DIR_NAME)

    @staticmethod
    def _sanitized(name):
        """Die CLI ersetzt beim Herunterladen Zeichen, die nicht auf allen Systemen erlaubt sind (z. B. " -> _)."""
        return re.sub(r'["*/:<>?\\|]', "_", name)

    def _restore_name(self, tmp, p, rf):
        """Findet die heruntergeladene Datei, auch wenn die CLI ihren Namen veraendert hat, und stellt ihn her."""
        want = os.path.join(tmp, os.path.basename(p))
        if os.path.isfile(want):
            return want
        wanted_clean = self._sanitized(os.path.basename(p))
        for name in sorted(os.listdir(tmp)):
            cand = os.path.join(tmp, name)
            if not os.path.isfile(cand) or self._sanitized(name) != wanted_clean:
                continue
            if os.path.getsize(cand) != rf[p].size:
                continue
            try:
                os.replace(cand, want)   # Originalnamen wiederherstellen
            except OSError as e:
                self.log("  " + T("FEHLER: {path} konnte lokal nicht angelegt werden ({msg})", path=p, msg=e))
                return None
            self.log("  " + T("Von der Proton-CLI umbenannt, Name wird zurückgesetzt: {path}", path=p))
            return want
        return None

    def _fetch(self, paths, rf, failed):
        """Laedt Dateien in einen Zwischenordner. Liefert {pfad: temp_datei} fuer vollstaendige Downloads."""
        got = {}
        for parent, group in group_by_parent(paths).items():
            for chunk in chunks(group, BATCH):
                self.cancel.check()
                private_dir(self.tmp_root())
                tmp = str(private_dir(os.path.join(self.tmp_root(), uuid.uuid4().hex)))
                sub_failed = set()
                self._batch(chunk, lambda items, t=tmp: self.cli.run(
                    "filesystem", "download",  # Ziel ist ein leerer Zwischenordner: keine Konflikte moeglich
                    *[self.rpath(i) for i in items], t), sub_failed, "Download")
                for p in chunk:
                    tf = None if p in sub_failed else self._restore_name(tmp, p, rf)
                    if p in sub_failed:
                        failed.add(p)
                    elif tf is None or os.path.getsize(tf) != rf[p].size:
                        failed.add(p)
                        self.log("  " + T("FEHLER: {path} unvollständig heruntergeladen – wird verworfen", path=p))
                    else:
                        os.utime(tf, (rf[p].mtime, rf[p].mtime))  # Originalzeit uebernehmen
                        got[p] = tf
        return got

    def downloads(self, paths, rf, failed, done=None):
        """Download blockweise erst in den Zwischenordner; die lokale Datei wird nur bei Erfolg ersetzt.
        Die bisherige lokale Version wandert vorher in den Papierkorb."""
        try:
            for parent, group in group_by_parent(paths).items():
                for chunk in chunks(group, BATCH):
                    self.cancel.check()
                    for p in chunk:
                        self.log(f"  ↓ {p}")
                    got = self._fetch(chunk, rf, failed)
                    ok = []
                    for p, tf in got.items():
                        target = self.lpath(p)
                        if os.path.lexists(target) and self.local_trash([p]):
                            failed.add(p)
                            continue
                        os.makedirs(os.path.dirname(target), exist_ok=True)
                        os.replace(tf, target)
                        ok.append(p)
                    self.clean_tmp()
                    if done:
                        done("down", ok)
        finally:
            self.clean_tmp()

    def clean_tmp(self):
        shutil.rmtree(self.tmp_root(), ignore_errors=True)

    def resolve_conflicts(self, plan, lf, rf, failed):
        """Beide Versionen behalten. Die neuere behaelt den Namen, die aeltere wird Konfliktkopie."""
        stamp = datetime.now().strftime("%Y-%m-%d %H%M%S")
        word = T("Konflikt")
        taken = set(lf) | set(rf)

        def copy_name(p):
            head, _, name = p.rpartition("/")
            stem, ext = os.path.splitext(name)
            n = 0
            while True:
                suffix = f" ({word} {stamp})" if n == 0 else f" ({word} {stamp} {n})"
                cand = (head + "/" if head else "") + stem + suffix + ext
                if cand not in taken and not os.path.lexists(self.lpath(cand)):
                    taken.add(cand)
                    return cand
                n += 1

        remote_copies = [p for p in plan.conflicts if plan.winner[p] == "local"]
        got = {}
        if remote_copies:  # Remote-Version sichern, bevor die lokale sie ersetzt
            try:
                got = self._fetch(remote_copies, rf, failed)
                for p in remote_copies:
                    if p not in got:
                        self.log("  " + T("Konflikt {path}: Remote-Version nicht gesichert – Datei wird ausgelassen", path=p))
                        continue
                    c = copy_name(p)
                    os.replace(got[p], self.lpath(c))
                    self.log("  " + T("Konfliktkopie: {path}", path=c))
                    plan.conflict_copies.append(c)
                    plan.upload += [p, c]
            finally:
                self.clean_tmp()
        for p in plan.conflicts:
            if plan.winner[p] != "remote":
                continue
            c = copy_name(p)
            try:
                os.rename(self.lpath(p), self.lpath(c))
            except OSError as e:
                failed.add(p)
                self.log("  " + T("FEHLER Konflikt {path}: lokale Version nicht umbenannt ({msg})", path=p, msg=e))
                continue
            self.log("  " + T("Konfliktkopie: {path}", path=c))
            plan.conflict_copies.append(c)
            plan.upload.append(c)
            plan.download.append(p)

    def remote_trash(self, paths, failed, what="Papierkorb", done=None):
        for chunk in chunks(paths, BATCH):
            self.cancel.check()
            self._batch(chunk, lambda items: self.cli.run(
                "filesystem", "trash", *[self.rpath(i) for i in items]), failed, what)
            if done:
                done("trash_remote", [p for p in chunk if p not in failed])


# --------------------------------------------------------------------------- Sperre

class FolderLock:
    """Verhindert parallele Syncs desselben Ordners (GUI, Autostart, Headless)."""

    def __init__(self, sp):
        self.path = sp.with_suffix(".lock")
        self.fd = None

    def __enter__(self):
        private_dir(self.path.parent)
        self.fd = os.open(self.path, os.O_RDWR | os.O_CREAT, 0o600)
        try:
            fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            os.close(self.fd)
            self.fd = None
            raise Busy(T("Ein anderer Sync für diesen Ordner läuft bereits."))
        return self

    def __exit__(self, *exc):
        if self.fd is not None:
            fcntl.flock(self.fd, fcntl.LOCK_UN)
            os.close(self.fd)
        return False


# --------------------------------------------------------------------------- Hauptlauf

def depth(d):
    return d.count("/")


def _validate(cfg):
    lroot = os.path.abspath(os.path.expanduser(cfg["local"]))
    rroot = (cfg.get("remote") or REMOTE_ROOT).strip().rstrip("/") or REMOTE_ROOT
    if not os.path.isdir(lroot):
        raise SyncError(T("Lokaler Ordner existiert nicht: {path}", path=lroot))
    if lroot in ("/", str(Path.home())):
        raise SyncError(T("Lokaler Ordner ist zu breit gewählt (Wurzel bzw. Home). Bitte einen Unterordner wählen."))
    if not (rroot == REMOTE_ROOT or rroot.startswith(REMOTE_ROOT + "/")):
        raise SyncError(T("Proton-Pfad muss mit {root} beginnen.", root=REMOTE_ROOT))
    for seg in rroot[len(REMOTE_ROOT):].split("/")[1:]:
        if not seg or name_problem(seg, True):
            raise SyncError(T("Ungültiger Proton-Pfad: {path}", path=rroot))
    return lroot, rroot


def _list_plan(plan, log):
    for label, items in ((T("Hochladen"), plan.upload), (T("Herunterladen"), plan.download),
                         (T("Remote in Papierkorb"), plan.trash_remote),
                         (T("Lokal in Papierkorb"), plan.trash_local), (T("KONFLIKT (beide behalten)"), plan.conflicts)):
        for p in items[:200]:
            note = f"  [{plan.notes[p]}]" if p in plan.notes else ""
            log(f"  {label}: {p}{note}")
        if len(items) > 200:
            log("  " + T("… und {n} weitere ({label})", n=len(items) - 200, label=label))


def _guard_deletions(plan, n_base, confirm, label=""):
    dels = plan.deletions()
    if dels >= 10 and dels > 0.3 * max(1, n_base):
        msg = ((f"{label}:\n" if label else "")
               + T("Es sollen {n} Dateien gelöscht werden (von {total} bekannten). Das sieht ungewöhnlich aus. "
                   "Fortfahren?", n=dels, total=n_base))
        if not (confirm and confirm(msg)):
            raise SyncError(T("Abgebrochen: viele Löschungen wurden nicht bestätigt."))


def run_sync(cfg, log, cancel, dry_run=False, confirm=None, mode="full", progress=None):
    """mode='full': liest beide Seiten komplett ein. mode='quick': nur lokale Aenderungen (Remote = letzter Stand)."""
    if mode != "quick" or dry_run:
        return _sync(cfg, log, cancel, dry_run, confirm, "full", progress)
    buf = []
    try:
        plan = _sync(cfg, buf.append, cancel, False, confirm, "quick", progress)
    except Exception:
        for m in buf:
            log(m)
        raise
    if plan.total() or plan.errors or plan.dirs_created or plan.full:
        for m in buf:
            log(m)
    return plan


def _sync(cfg, log, cancel, dry_run, confirm, mode, progress=None):
    lroot, rroot = _validate(cfg)
    sp = state_path(lroot, rroot)
    if dry_run:
        return _sync_locked(cfg, log, cancel, dry_run, confirm, mode, lroot, rroot, sp, progress)
    with FolderLock(sp):
        return _sync_locked(cfg, log, cancel, dry_run, confirm, mode, lroot, rroot, sp, progress)


def _sync_locked(cfg, log, cancel, dry_run, confirm, mode, lroot, rroot, sp, progress=None):
    excludes = parse_excludes(cfg.get("excludes", DEFAULT_EXCLUDES))
    cli = Cli(cfg.get("cli") or "proton-drive")
    workers = max(1, min(8, int(cfg.get("parallel", PARALLEL_DEFAULT))))
    sy = Syncer(cli, lroot, rroot, log, cancel, thumbnails=bool(cfg.get("thumbnails", True)))
    sy.workers = workers
    base_files, base_dirs = load_state(sp)
    first_run = not base_files and not base_dirs
    complete = state_complete(sp)
    if not dry_run:
        sy.clean_tmp()  # Reste eines abgebrochenen Laufs

    if mode == "quick" and first_run:
        log(T("Kein gespeicherter Stand – führe vollen Abgleich aus."))
        mode = "full"
    elif mode == "quick" and not complete:
        log(T("Unterbrochener Abgleich – führe vollen Abgleich aus."))
        mode = "full"
    if mode == "quick":
        plan = _quick(sy, cli, lroot, rroot, excludes, base_files, base_dirs, sp, log, cancel, confirm, progress)
        if plan is not None:
            return plan
        base_files, base_dirs = load_state(sp)

    log(T("Lokal:  {path}", path=lroot))
    log(T("Remote: {path}", path=rroot))
    if first_run:
        log(T("Erste Synchronisation (kein gespeicherter Stand): es wird nichts gelöscht."))
    elif not complete:
        log(T("Setze unterbrochenen Abgleich fort: {n} Dateien sind bereits abgeglichen.", n=len(base_files)))
    else:
        log(T("Letzter Stand: {n} Dateien bekannt.", n=len(base_files)))
    if not dry_run:
        sy.ensure_remote_root()

    log(T("Lese lokalen Ordner …"))
    lf, ld = scan_local(lroot, excludes, log)
    log("  " + T("{files} Dateien, {dirs} Ordner", files=len(lf), dirs=len(ld)))
    log(T("Lese Proton Drive (kann bei vielen Ordnern dauern) …"))
    rf, rd = scan_remote(cli, rroot, excludes, log, cancel, root_missing_ok=dry_run, estimate=len(ld) + 1,
                         workers=workers, progress=progress)
    log("  " + T("{files} Dateien, {dirs} Ordner", files=len(rf), dirs=len(rd)))

    plan = decide(lf, rf, base_files, lroot, log)
    plan.full = True
    log("")
    log(T("Plan: {up} hochladen, {down} herunterladen, {tr} remote in Papierkorb, {tl} lokal in Papierkorb, "
          "{c} Konflikte", up=len(plan.upload), down=len(plan.download), tr=len(plan.trash_remote),
          tl=len(plan.trash_local), c=len(plan.conflicts)))
    _list_plan(plan, log)

    dl_bytes = sum(rf[p].size for p in plan.download)
    ul_bytes = sum(lf[p].size for p in plan.upload)
    if dry_run:
        log("\n" + T("Trockenlauf – es wurde nichts verändert. (Download {down}, Upload {up})", down=human(dl_bytes), up=human(ul_bytes)))
        return plan

    free = shutil.disk_usage(lroot).free
    if dl_bytes + (1 << 30) > free:
        raise SyncError(T("Nicht genug Speicherplatz: Download {down}, frei {free}.", down=human(dl_bytes), free=human(free)))
    if first_run and (plan.download or plan.upload):
        msg = T("Erster Abgleich für\n{pair}\n\n{down_n} Dateien ({down}) werden heruntergeladen,\n"
                "{up_n} Dateien ({up}) werden hochgeladen.\n\nFortfahren?", pair=f"{lroot}  ↔  {rroot}",
                down_n=len(plan.download), down=human(dl_bytes), up_n=len(plan.upload), up=human(ul_bytes))
        if not (confirm and confirm(msg)):
            raise SyncError(T("Abgebrochen: erster Abgleich nicht bestätigt."))
    _guard_deletions(plan, len(base_files), confirm, f"{lroot}  ↔  {rroot}")

    failed = set()
    log("\n" + T("Führe aus …"))
    sy.rdirs = set(rd)
    if plan.conflicts:
        sy.resolve_conflicts(plan, lf, rf, failed)
    touched = set(plan.upload) | set(plan.download) | set(plan.trash_remote) | set(plan.trash_local) | set(plan.conflicts)
    # Dateien, die zu Beginn schon abgeglichen waren: Stand vom Anfang des Laufs (nicht vom Ende!),
    # damit Aenderungen waehrend eines langen Laufs beim naechsten Mal erkannt werden.
    in_sync = {p: (lf[p], rf[p]) for p in set(lf) & set(rf) if p not in touched}
    ckpt = {p: v for p, v in base_files.items() if p in touched}
    ckpt.update(in_sync)
    prog = {"up": [0, 0], "down": [0, 0], "t_save": time.monotonic(), "t_log": time.monotonic()}
    up_total = (len(plan.upload), sum(os.path.getsize(sy.lpath(p)) for p in plan.upload if os.path.isfile(sy.lpath(p))))
    down_total = (len(plan.download), sum(rf[p].size for p in plan.download if p in rf))

    def local_sig(p):
        st = os.stat(sy.lpath(p))
        return Sig(st.st_mtime, st.st_size)

    def checkpoint(force=False):
        if force or time.monotonic() - prog["t_save"] >= 30:
            prog["t_save"] = time.monotonic()
            save_state(sp, ckpt, base_dirs, complete=False)

    def done(kind, paths):
        for p in paths:
            try:
                if kind == "up":
                    ls = local_sig(p)
                    ckpt[p] = (ls, Sig(ls.mtime, ls.size))  # Proton uebernimmt Zeit und Groesse der Datei
                    prog["up"][0] += 1
                    prog["up"][1] += ls.size
                elif kind == "down":
                    ckpt[p] = (local_sig(p), rf[p])
                    prog["down"][0] += 1
                    prog["down"][1] += rf[p].size
                else:
                    ckpt.pop(p, None)
            except OSError:
                pass
        checkpoint()
        last_chunk = (kind == "up" and prog["up"][0] == up_total[0]) or (kind == "down" and prog["down"][0] == down_total[0])
        if progress and kind in ("up", "down"):
            n, b = prog[kind]
            tot = up_total if kind == "up" else down_total
            progress(kind, n, tot[0], b, tot[1])
        if kind in ("up", "down") and (last_chunk or time.monotonic() - prog["t_log"] >= PROGRESS_S):
            prog["t_log"] = time.monotonic()
            n, b = prog[kind]
            tot = up_total if kind == "up" else down_total
            key = ("Fortschritt: {done} von {total} Dateien hochgeladen ({size} von {total_size})" if kind == "up"
                   else "Fortschritt: {done} von {total} Dateien heruntergeladen ({size} von {total_size})")
            log("  " + T(key, done=n, total=tot[0], size=human(b), total_size=human(tot[1])))

    try:
        if plan.trash_remote:
            sy.remote_trash(plan.trash_remote, failed, done=done)
        if plan.trash_local:
            bad = sy.local_trash(plan.trash_local)
            failed |= bad
            done("trash_local", [p for p in plan.trash_local if p not in bad])
        if plan.upload:
            sy.uploads(plan.upload, failed, done=done)
        if plan.download:
            sy.downloads(plan.download, rf, failed, done=done)
    finally:
        if touched:
            checkpoint(force=True)  # auch bei Abbruch: Erledigtes bleibt erhalten

    if progress:
        progress("scan", 0, 0)   # Uebertragung fertig - Icon zeigt nicht mehr "busy" waehrend der Pruefung
    log(T("Prüfe Ergebnis …"))
    lf2, ld2 = scan_local(lroot, excludes, lambda m: None)
    # Nur die Proton-Ordner neu lesen, in denen sich etwas geaendert hat
    parents = {p.rpartition("/")[0] for p in plan.upload + plan.trash_remote}
    rf2, _ = refresh_remote_dirs(cli, rroot, parents, rf, excludes, lambda m: None, cancel, workers)
    rd2 = set(sy.rdirs)
    for p in plan.upload:
        if p not in rf2 or (p in lf2 and rf2[p].size != lf2[p].size):
            failed.add(p)
    for p in plan.download:
        if p not in lf2 or (p in rf and lf2[p].size != rf[p].size):
            failed.add(p)
    for p in plan.trash_remote:
        if p in rf2:
            failed.add(p)
    for p in plan.trash_local:
        if p in lf2:
            failed.add(p)

    ld_w, rd_w = set(ld2), set(rd2)
    sy.rdirs = rd_w
    for d in sorted((ld2 - rd2) - base_dirs, key=depth):
        cancel.check()
        try:
            sy.ensure_remote_dir(d)
            plan.dirs_created += 1
            log("  " + T("Ordner remote angelegt: {path}", path=d))
        except SyncError as e:
            log("  " + T("FEHLER Ordner {path}: {msg}", path=d, msg=e))
    for d in sorted((rd2 - ld2) - base_dirs, key=depth):
        os.makedirs(sy.lpath(d), exist_ok=True)
        ld_w.add(d)
        plan.dirs_created += 1
        log("  " + T("Ordner lokal angelegt: {path}", path=d))
    for d in sorted((ld2 - rd2) & base_dirs, key=depth, reverse=True):
        if is_empty(d, lf2, ld_w) and not sy.local_trash([d]):
            ld_w.discard(d)
            log("  " + T("Ordner lokal in Papierkorb: {path}", path=d))
    for d in sorted((rd2 - ld2) & base_dirs, key=depth, reverse=True):
        if is_empty(d, rf2, rd_w):
            f_dir = set()
            sy.remote_trash([d], f_dir, "Ordner-Papierkorb")
            if not f_dir:
                rd_w.discard(d)
                log("  " + T("Ordner remote in Papierkorb: {path}", path=d))

    new_files = {p: v for p, v in in_sync.items() if p in lf2 and p in rf2}
    for p in touched | set(plan.conflict_copies):
        if p in failed:
            if p in base_files:
                new_files[p] = base_files[p]
        elif p in lf2 and p in rf2:
            new_files[p] = (lf2[p], rf2[p])
    new_dirs = (ld_w & rd_w) | {d for d in base_dirs if (d in ld_w) != (d in rd_w)}
    save_state(sp, new_files, new_dirs)
    record_changes(rroot, plan)

    plan.errors = len(failed)
    n_actions = len(plan.upload) + len(plan.download) + plan.deletions()
    log("\n" + T("Fertig: {ok} Aktionen erfolgreich, {err} Fehler, {copies} Konfliktkopien.",
                 ok=max(0, n_actions - plan.errors), err=plan.errors, copies=len(plan.conflict_copies)))
    return plan


def _quick(sy, cli, lroot, rroot, excludes, base_files, base_dirs, sp, log, cancel, confirm, progress=None):
    """Nur lokale Aenderungen: Remote wird als unveraendert seit dem letzten Abgleich angenommen.
    Aenderungen in Proton Drive erkennt erst der naechste Vollabgleich."""
    lf, ld = scan_local(lroot, excludes, log)
    rf = {p: r for p, (l, r) in base_files.items()}
    plan = decide(lf, rf, base_files, lroot)
    new_dirs_local = sorted(ld - base_dirs, key=depth)
    if not plan.total() and not new_dirs_local:
        return plan
    # Vorpruefung: haben sich die betroffenen Dateien in Proton Drive seit dem letzten Abgleich veraendert?
    parents = {p.rpartition("/")[0] for p in plan.upload + plan.trash_remote}
    rf_now, missing = refresh_remote_dirs(cli, rroot, parents, rf, excludes, lambda m: None, cancel, sy.workers)
    known_missing = {d for d in missing if d == "" or d in base_dirs}
    changed = [p for p in plan.upload + plan.trash_remote
               if (p in rf) != (p in rf_now) or (p in rf and not same(rf[p], rf_now[p]))]
    if changed or known_missing:
        log(T("Änderung in Proton Drive erkannt ({path}) – wechsle zum vollen Abgleich.",
              path=(changed or sorted(known_missing))[0] or "/"))
        return None
    log(T("Schnellabgleich: {up} hochladen, {tr} remote in Papierkorb", up=len(plan.upload), tr=len(plan.trash_remote)))
    _list_plan(plan, log)
    _guard_deletions(plan, len(base_files), confirm, f"{lroot}  ↔  {rroot}")

    failed = set()
    sy.rdirs = set(base_dirs)
    if plan.trash_remote:
        sy.remote_trash(plan.trash_remote, failed)
    if plan.upload:
        if progress:
            progress("up", 0, len(plan.upload))
        sy.uploads(plan.upload, failed)
        if progress:
            progress("scan", 0, 0)   # Icon zeigt "busy" nur waehrend der eigentlichen Uebertragung
    created = set()
    for d in new_dirs_local:
        cancel.check()
        try:
            sy.ensure_remote_dir(d)
            created.add(d)
        except SyncError as e:
            log("  " + T("FEHLER Ordner {path}: {msg}", path=d, msg=e))

    rf2, _ = refresh_remote_dirs(cli, rroot, parents, rf, excludes, lambda m: None, cancel, sy.workers)
    new_files = dict(base_files)
    for p in plan.upload:
        if p not in failed and p in rf2 and p in lf and rf2[p].size == lf[p].size:
            new_files[p] = (lf[p], rf2[p])
        else:
            failed.add(p)
    for p in plan.trash_remote:
        if p not in failed and p not in rf2:
            new_files.pop(p, None)
        else:
            failed.add(p)
    save_state(sp, new_files, set(base_dirs) | created)
    record_changes(rroot, plan)
    plan.errors = len(failed)
    plan.dirs_created = len(created)
    log(T("Schnellabgleich fertig: {ok} Aktionen erfolgreich, {err} Fehler.", ok=plan.total() - plan.errors, err=plan.errors))
    return plan


# --------------------------------------------------------------------------- Aenderungsprotokoll
#
# Beschleunigt die Erkennung von Aenderungen, die auf einem anderen Geraet vorgenommen wurden: jedes Geraet
# schreibt seine eigenen Uploads/Loeschungen in eine eigene Datei unter /my-files/.hadron-sync/<Geraet>.jsonl
# (immer im Proton-Stammverzeichnis, unabhaengig davon, welchen Unterordner das Ordnerpaar synchronisiert).
# Andere Geraete lesen diese Dateien im 60-Sekunden-Takt und gleichen nur die genannten Pfade ab, statt den
# gesamten Baum neu einzulesen. Jedes Geraet merkt sich pro fremder Datei ein Lesezeichen (letzter verarbeiteter
# Zeitstempel) - es wird nichts in der gemeinsamen Datei markiert, das koennte bei mehreren Geraeten kollidieren.
# Der normale Voll-/Schnellabgleich bleibt das Sicherheitsnetz fuer alles, was am Protokoll vorbeigeht.

def device_id():
    """Zufaellige, dauerhafte Kennung dieser Installation, mit dem Rechnernamen zur besseren Lesbarkeit."""
    cfg = load_config()
    did = cfg.get("device_id")
    if did:
        return did
    import socket
    host = re.sub(r"[^A-Za-z0-9_-]+", "-", socket.gethostname() or "geraet").strip("-")[:24] or "geraet"
    did = f"{host}-{uuid.uuid4().hex[:8]}"
    cfg["device_id"] = did
    try:
        save_config(cfg)
    except OSError:
        pass
    return did


def load_changelog_cache():
    try:
        d = json.loads(CHANGELOG_FILE.read_text())
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_changelog_cache(data):
    try:
        write_private(CHANGELOG_FILE, json.dumps(data))
    except OSError:
        pass


def record_changes(rroot, plan):
    """Traegt die Uploads und Remote-Loeschungen dieses Laufs in den eigenen Änderungsprotokoll-Zwischenspeicher ein."""
    if not plan.upload and not plan.trash_remote:
        return
    cache = load_changelog_cache()
    entries = cache.get("entries", [])
    now = datetime.now(timezone.utc).isoformat()   # mit Mikrosekunden: mehrere Aenderungen pro Sekunde bleiben unterscheidbar
    for p in plan.upload:
        entries.append({"t": now, "remote": rroot + "/" + p, "action": "upload"})
    for p in plan.trash_remote:
        entries.append({"t": now, "remote": rroot + "/" + p, "action": "trash"})
    cutoff = (datetime.now(timezone.utc) - timedelta(days=CHANGELOG_TTL_DAYS)).isoformat(timespec="seconds")
    cache["entries"] = [e for e in entries if e.get("t", "") >= cutoff]
    save_changelog_cache(cache)


def publish_own_log(cli, log):
    """Laedt die eigenen, noch gueltigen Eintraege als <Geraet>.jsonl ins Proton-Stammverzeichnis hoch."""
    cache = load_changelog_cache()
    entries = cache.get("entries", [])
    if not entries:
        return
    did = device_id()
    local = CONFIG_DIR / f"{did}.jsonl"
    try:
        write_private(local, "\n".join(json.dumps(e, ensure_ascii=False) for e in entries) + "\n")
        try:
            cli.list_dir(CHANGELOG_ROOT)
        except NotFound:
            try:
                cli.check("filesystem", "create-folder", REMOTE_ROOT, CHANGELOG_REL)
            except SyncError:
                pass  # evtl. von einem anderen Geraet inzwischen angelegt
        rc, out, err = cli.run("filesystem", "upload", "--file-conflict-strategy", "replace",
                               "--skip-thumbnails", str(local), CHANGELOG_ROOT)
        if rc != 0:
            log("  " + T("Änderungsprotokoll: {path} konnte nicht hochgeladen werden ({msg})",
                         path=f"{did}.jsonl", msg=Cli.message(out, err)[:200]))
    finally:
        try:
            local.unlink()
        except OSError:
            pass


def check_changelog(cli, pairs, excludes, cancel, log):
    """Liest neue Eintraege anderer Geraete und liefert {Ordnerpaar-Schluessel: {betroffene relative Pfade}}."""
    targets = {key: set() for key in pairs}
    try:
        nodes = cli.list_dir(CHANGELOG_ROOT)
    except NotFound:
        return {}
    my_file = f"{device_id()}.jsonl"
    cache = load_changelog_cache()
    bookmarks = cache.setdefault("bookmarks", {})
    seen = cache.setdefault("seen", {})
    changed = False
    for node in nodes:
        name = node_name(node)
        if not name or node.get("type") != "file" or not name.endswith(".jsonl") or name == my_file:
            continue
        rev = node.get("activeRevision") or {}
        mtime = rev.get("claimedModificationTime") or node.get("modificationTime")
        if not mtime or seen.get(name) == mtime:
            continue  # seit dem letzten Mal unveraendert - kein erneuter Download noetig
        cancel.check()
        local = CONFIG_DIR / f"peek-{name}"
        try:
            rc, out, err = cli.run("filesystem", "download", CHANGELOG_ROOT + "/" + name, str(CONFIG_DIR))
            changed = True
            seen[name] = mtime
            if rc != 0:
                continue
            actual = local
            if not actual.exists():  # die CLI kann Namen leicht veraendern (siehe Syncer._sanitized)
                cand = [f for f in CONFIG_DIR.glob("*.jsonl") if f.name not in (my_file,) and f != local
                        and Syncer._sanitized(f.name) == Syncer._sanitized(name)]
                actual = cand[0] if cand else None
            if not actual:
                continue
            try:
                lines = actual.read_text(encoding="utf-8", errors="replace").splitlines()
            finally:
                try:
                    actual.unlink()
                except OSError:
                    pass
        except SyncError:
            continue
        bookmark = bookmarks.get(name, "")
        newest = bookmark
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except ValueError:
                continue
            t, remote = entry.get("t") or "", entry.get("remote") or ""
            if not t or not remote or t <= bookmark:
                continue
            newest = max(newest, t)
            for key, p in pairs.items():
                rroot = norm_remote(p["remote"])
                if remote == rroot or remote.startswith(rroot + "/"):
                    rel = remote[len(rroot):].lstrip("/")
                    base = rel.rpartition("/")[2] or rel
                    if rel and not excluded(base, excludes) and not name_problem(base, False):
                        targets[key].add(rel)
        bookmarks[name] = newest
    if changed:
        save_changelog_cache(cache)
    return {k: v for k, v in targets.items() if v}


def run_targeted_sync(cfg, targets, log, cancel, confirm=None):
    """Gleicht nur die genannten Pfade ab (aus dem Aenderungsprotokoll eines anderen Geraets) - kein Volleinlesen."""
    lroot, rroot = _validate(cfg)
    excludes = parse_excludes(cfg.get("excludes", DEFAULT_EXCLUDES))
    cli = Cli(cfg.get("cli") or "proton-drive")
    workers = max(1, min(8, int(cfg.get("parallel", PARALLEL_DEFAULT))))
    sy = Syncer(cli, lroot, rroot, log, cancel, thumbnails=bool(cfg.get("thumbnails", True)))
    sy.workers = workers
    sp = state_path(lroot, rroot)
    with FolderLock(sp):
        base_files, base_dirs = load_state(sp)
        wanted = sorted({t for t in targets
                        if not excluded(t.rpartition("/")[2] or t, excludes) and not name_problem(t.rpartition("/")[2] or t, False)})
        if not wanted:
            return Plan()
        lf = {}
        for t in wanted:
            cancel.check()
            fp = os.path.join(lroot, t)
            if os.path.isfile(fp) and not os.path.islink(fp):
                st = os.stat(fp)
                lf[t] = Sig(st.st_mtime, st.st_size)
        parents = {t.rpartition("/")[0] for t in wanted}
        rf_all, _ = refresh_remote_dirs(cli, rroot, parents, {}, excludes, log, cancel, workers)
        rf = {t: rf_all[t] for t in wanted if t in rf_all}
        base = {t: base_files[t] for t in wanted if t in base_files}
        plan = decide(lf, rf, base, lroot)
        if not plan.total():
            return plan
        log(T("Änderung auf einem anderen Gerät erkannt – gleiche {n} Datei(en) gezielt ab.", n=plan.total()))
        failed = set()
        sy.rdirs = set(base_dirs)
        if plan.conflicts:
            sy.resolve_conflicts(plan, lf, rf, failed)
        if plan.trash_remote:
            sy.remote_trash(plan.trash_remote, failed)
        if plan.trash_local:
            failed |= sy.local_trash(plan.trash_local)
        if plan.upload:
            sy.uploads(plan.upload, failed)
        if plan.download:
            sy.downloads(plan.download, rf, failed)

        touched = set(plan.upload) | set(plan.download) | set(plan.trash_remote) | set(plan.trash_local) \
            | set(plan.conflicts) | set(plan.conflict_copies)
        new_base = dict(base_files)
        for t in touched:
            if t in failed:
                continue
            fp = os.path.join(lroot, t)
            if os.path.isfile(fp):
                st = os.stat(fp)
                lsig = Sig(st.st_mtime, st.st_size)
                new_base[t] = (lsig, rf.get(t) or Sig(lsig.mtime, lsig.size))
            else:
                new_base.pop(t, None)
        save_state(sp, new_base, base_dirs, complete=state_complete(sp))
        record_changes(rroot, plan)
        plan.errors = len(failed)
        log(T("Gezielter Abgleich fertig: {ok} Aktionen erfolgreich, {err} Fehler.",
              ok=max(0, plan.total() - plan.errors - len(plan.conflicts)), err=plan.errors))
        return plan


# --------------------------------------------------------------------------- Konfiguration / Integration

def norm_remote(r):
    r = (r or REMOTE_ROOT).strip().rstrip("/")
    return r or REMOTE_ROOT


def pair_key(p):
    return f"{os.path.abspath(os.path.expanduser(p['local']))}|{norm_remote(p.get('remote'))}"


def pair_label(p):
    local = os.path.abspath(os.path.expanduser(p["local"]))
    home = str(Path.home())
    if local.startswith(home + os.sep):
        local = "~" + local[len(home):]
    return f"{local}  ↔  {norm_remote(p.get('remote'))}"


def _overlaps(a, b):
    return a == b or a.startswith(b.rstrip("/") + "/") or b.startswith(a.rstrip("/") + "/")


def validate_pairs(pairs):
    """Prueft alle Paare. Lokale bzw. Remote-Ordner duerfen weder gleich noch ineinander verschachtelt sein."""
    if not pairs:
        raise SyncError(T("Es ist kein Ordnerpaar eingerichtet."))
    seen = []
    for p in pairs:
        lroot, rroot = _validate(p)
        for l2, r2 in seen:
            if _overlaps(lroot, l2):
                raise SyncError(T("Lokale Ordner überschneiden sich: {a} und {b}", a=lroot, b=l2))
            if _overlaps(rroot, r2):
                raise SyncError(T("Proton-Ordner überschneiden sich: {a} und {b}", a=rroot, b=r2))
        seen.append((lroot, rroot))


def load_config():
    cfg = {"pairs": [], "cli": shutil.which("proton-drive") or "/usr/local/bin/proton-drive",
           "excludes": DEFAULT_EXCLUDES, "realtime": True, "interval": 15, "autostart": False, "language": "auto",
           "thumbnails": True, "parallel": PARALLEL_DEFAULT, "setup_done": False}
    try:
        data = json.loads(CONFIG_FILE.read_text())
        if not isinstance(data, dict):
            data = {}
    except (OSError, json.JSONDecodeError):
        data = {}
    if "pairs" not in data and data.get("local"):  # Uebernahme der frueheren Einzelordner-Konfiguration
        data["pairs"] = [{"local": data["local"], "remote": data.get("remote") or REMOTE_ROOT}]
    data.pop("local", None)
    data.pop("remote", None)
    cfg.update(data)
    pairs = cfg["pairs"] if isinstance(cfg["pairs"], list) else []
    cfg["pairs"] = [{"local": str(p["local"]), "remote": norm_remote(p.get("remote"))}
                    for p in pairs if isinstance(p, dict) and p.get("local")]
    try:
        iv = int(cfg["interval"])
    except (TypeError, ValueError):
        iv = 15
    cfg["interval"] = iv if 0 <= iv <= 1440 else 15
    if cfg.get("language") not in LANGUAGES:
        cfg["language"] = "auto"
    try:
        par = int(cfg.get("parallel", PARALLEL_DEFAULT))
    except (TypeError, ValueError):
        par = PARALLEL_DEFAULT
    cfg["parallel"] = par if 1 <= par <= 8 else PARALLEL_DEFAULT
    return cfg


def save_config(cfg):
    write_private(CONFIG_FILE, json.dumps(cfg, indent=2))


def _dq(s):
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"').replace("`", "\\`").replace("$", "\\$") + '"'


def _desktop_entry(extra_args="", autostart=False):
    exec_line = f"{_dq(sys.executable)} {_dq(os.path.abspath(__file__))}{extra_args}"
    lines = ["[Desktop Entry]", "Type=Application", f"Name={APP_NAME}",
             "Comment=Zweiwege-Synchronisation mit Proton Drive", f"Exec={exec_line}", f"Icon={ICON_APP}",
             "Terminal=false", "Categories=Network;FileTransfer;", f"StartupWMClass={APP_ID}"]
    if autostart:
        lines += ["X-GNOME-Autostart-enabled=true", "X-GNOME-Autostart-Delay=15"]  # Tray-Erweiterung erst starten lassen
    return "\n".join(lines) + "\n"


def ensure_integration():
    """Legt Icons und Menue-Eintrag an. Eigene Icons bleiben erhalten; nur fruehere Standard-Icons werden ersetzt."""
    icon_dir = Path.home() / ".local/share/icons/hicolor/scalable/apps"
    icon_dir.mkdir(parents=True, exist_ok=True)
    changed = False
    for name, svg in ICONS.items():
        f = icon_dir / f"{name}.svg"
        if f.exists():
            cur = f.read_text()
            ours_old = ICON_MARK_PREFIX in cur
            if ICON_MARKER in cur or not ours_old:
                continue  # aktuell oder vom Benutzer ersetzt
        f.write_text(svg)
        changed = True
    theme_root = Path.home() / ".local/share/icons/hicolor"
    if changed and (theme_root / "icon-theme.cache").exists() and shutil.which("gtk-update-icon-cache"):
        subprocess.run(["gtk-update-icon-cache", "-q", "-f", "-t", str(theme_root)], check=False)
    apps = Path.home() / ".local/share/applications"
    apps.mkdir(parents=True, exist_ok=True)
    (apps / f"{APP_ID}.desktop").write_text(_desktop_entry())


AUTOSTART_FILE = Path.home() / ".config/autostart/hadron-sync.desktop"


def set_autostart(enabled):
    f = AUTOSTART_FILE
    if enabled:
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(_desktop_entry(" --background", autostart=True))
    elif f.exists():
        f.unlink()


# --------------------------------------------------------------------------- GUI (GTK3 + AppIndicator)

Gtk = Gio = GLib = Pango = Gdk = AppIndicator = None


def gui_imports():
    global Gtk, Gio, GLib, Pango, Gdk, AppIndicator
    import importlib
    import gi
    from gi.repository import GLib as _GLib, Gio as _Gio
    _GLib.set_prgname(APP_ID)  # muss vor dem Gtk-Import stehen: bestimmt Fensterklasse bzw. app_id
    _GLib.set_application_name(APP_NAME)
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk as _Gtk, Pango as _Pango, Gdk as _Gdk
    Gtk, Gio, GLib, Pango, Gdk = _Gtk, _Gio, _GLib, _Pango, _Gdk
    AppIndicator = None
    for ns in ("AyatanaAppIndicator3", "AppIndicator3"):
        try:
            gi.require_version(ns, "0.1")
            AppIndicator = importlib.import_module(f"gi.repository.{ns}")
            break
        except (ValueError, ImportError):
            continue


class SettingsDialog:
    """Eigenes Fenster fuer alle Grundeinstellungen."""

    def __init__(self, app):
        self.app = app
        self.pairs = [dict(p) for p in app.cfg["pairs"]]
        cfg = app.cfg
        self.dlg = Gtk.Dialog(title=T("Einstellungen – {app}", app=APP_NAME),
                              transient_for=app.window if app.window is not None else None)
        self.dlg.set_default_size(720, 640)
        self.dlg.set_icon_name(ICON_APP)
        self.dlg.add_buttons(T("Schließen"), Gtk.ResponseType.CLOSE,
                             T("Speichern & anwenden"), Gtk.ResponseType.APPLY)
        box = self.dlg.get_content_area()
        box.set_spacing(8)
        box.set_border_width(12)

        box.pack_start(Gtk.Label(label=T("Ordnerpaare (lokaler Ordner ↔ Ordner in Proton Drive)"), xalign=0),
                       False, False, 0)
        self.store = Gtk.ListStore(str, str)
        self.view = Gtk.TreeView(model=self.store)
        for i, title in enumerate((T("Lokal"), "Proton Drive")):
            col = Gtk.TreeViewColumn(title, Gtk.CellRendererText(), text=i)
            col.set_resizable(True)
            col.set_expand(True)
            self.view.append_column(col)
        self.view.connect("row-activated", lambda *_: self.on_edit())
        sw = Gtk.ScrolledWindow()
        sw.set_min_content_height(140)
        sw.add(self.view)
        box.pack_start(sw, True, True, 0)
        prow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        for label, cb in ((T("Hinzufügen …"), self.on_add), (T("Bearbeiten …"), self.on_edit),
                          (T("Entfernen"), self.on_remove)):
            b = Gtk.Button(label=label)
            b.connect("clicked", lambda _b, f=cb: f())
            prow.pack_start(b, False, False, 0)
        box.pack_start(prow, False, False, 0)

        grid = Gtk.Grid(column_spacing=8, row_spacing=8)
        box.pack_start(grid, False, False, 4)
        grid.attach(Gtk.Label(label=T("Ausschlüsse"), xalign=0), 0, 0, 1, 1)
        self.e_excl = Gtk.Entry(hexpand=True)
        self.e_excl.set_text(cfg["excludes"])
        grid.attach(self.e_excl, 1, 0, 1, 1)
        grid.attach(Gtk.Label(label="proton-drive CLI", xalign=0), 0, 1, 1, 1)
        self.e_cli = Gtk.Entry(hexpand=True)
        self.e_cli.set_text(cfg["cli"])
        grid.attach(self.e_cli, 1, 1, 1, 1)
        grid.attach(Gtk.Label(label=T("Sprache"), xalign=0), 0, 2, 1, 1)
        self.c_lang = Gtk.ComboBoxText()
        for code, nm in LANGUAGES.items():
            self.c_lang.append(code, nm or T("Automatisch (Systemsprache)"))
        self.c_lang.set_active_id(cfg.get("language", "auto"))
        self.c_lang.set_halign(Gtk.Align.START)
        grid.attach(self.c_lang, 1, 2, 1, 1)

        self.c_auto = Gtk.CheckButton(label=T("Beim Anmelden automatisch im Hintergrund starten"))
        self.c_auto.set_active(bool(cfg.get("autostart")))
        self.c_rt = Gtk.CheckButton(label=T("Lokale Änderungen sofort synchronisieren"))
        self.c_rt.set_active(bool(cfg.get("realtime")))
        self.c_thumbs = Gtk.CheckButton(label=T("Vorschaubilder in Proton Drive erzeugen (langsamer)"))
        self.c_thumbs.set_active(bool(cfg.get("thumbnails", True)))
        for widget in (self.c_auto, self.c_rt, self.c_thumbs):
            box.pack_start(widget, False, False, 0)

        rows = Gtk.Grid(column_spacing=8, row_spacing=6)
        box.pack_start(rows, False, False, 0)
        rows.attach(Gtk.Label(label=T("Vollabgleich alle"), xalign=0), 0, 0, 1, 1)
        self.s_int = Gtk.SpinButton.new_with_range(0, 1440, 15)
        self.s_int.set_value(int(cfg.get("interval", 15)))
        rows.attach(self.s_int, 1, 0, 1, 1)
        rows.attach(Gtk.Label(label=T("Minuten (0 = aus). Nur der Vollabgleich erkennt Änderungen in Proton Drive."),
                              xalign=0), 2, 0, 1, 1)
        rows.attach(Gtk.Label(label=T("Gleichzeitige Abfragen an Proton Drive"), xalign=0), 0, 1, 1, 1)
        self.s_par = Gtk.SpinButton.new_with_range(1, 8, 1)
        self.s_par.set_value(int(cfg.get("parallel", PARALLEL_DEFAULT)))
        rows.attach(self.s_par, 1, 1, 1, 1)
        rows.attach(Gtk.Label(label=T("(beschleunigt das Einlesen; bei Problemen auf 1 stellen)"), xalign=0), 2, 1, 1, 1)

        self.lbl_err = Gtk.Label(label="", xalign=0)
        self.lbl_err.set_line_wrap(True)
        box.pack_start(self.lbl_err, False, False, 0)
        self.fill()
        self.dlg.show_all()
        self.dlg.connect("response", self.on_response)

    # --- Ordnerpaare
    def fill(self):
        self.store.clear()
        for p in self.pairs:
            self.store.append([pair_label(p).split("  ↔  ")[0], norm_remote(p["remote"])])

    def selected(self):
        model, it = self.view.get_selection().get_selected()
        return model.get_path(it).get_indices()[0] if it else None

    def on_add(self):
        p = self.app.pair_dialog(self.dlg, None, self.pairs)
        if p:
            self.pairs.append(p)
            self.fill()

    def on_edit(self):
        i = self.selected()
        if i is None:
            self.lbl_err.set_text(T("Bitte zuerst ein Ordnerpaar auswählen."))
            return
        p = self.app.pair_dialog(self.dlg, self.pairs[i], self.pairs, index=i)
        if p:
            self.pairs[i] = p
            self.fill()
            self.lbl_err.set_text(T("Ordnerpaar geändert – mit „Speichern & anwenden“ übernehmen. "
                                    "Ein geändertes Paar wird wie ein neues behandelt (erster Abgleich)."))

    def on_remove(self):
        i = self.selected()
        if i is None:
            self.lbl_err.set_text(T("Bitte zuerst ein Ordnerpaar auswählen."))
            return
        del self.pairs[i]
        self.fill()
        self.lbl_err.set_text(T("Ordnerpaar entfernt – mit „Speichern & anwenden“ übernehmen. "
                                "Dateien bleiben auf beiden Seiten erhalten."))

    # --- Speichern
    def read(self):
        cfg = dict(self.app.cfg)
        cfg.update(pairs=[dict(p) for p in self.pairs], excludes=self.e_excl.get_text(),
                   cli=self.e_cli.get_text().strip(), language=self.c_lang.get_active_id() or "auto",
                   autostart=self.c_auto.get_active(), realtime=self.c_rt.get_active(),
                   thumbnails=self.c_thumbs.get_active(), interval=self.s_int.get_value_as_int(),
                   parallel=self.s_par.get_value_as_int())
        return cfg

    def on_response(self, _dlg, response):
        if response == Gtk.ResponseType.APPLY:
            cfg = self.read()
            try:
                validate_pairs(cfg["pairs"])
            except SyncError as e:
                self.lbl_err.set_text(T("Nicht gespeichert: {msg}", msg=e))
                return
            self.app.apply_settings(cfg)
            self.close()
        else:
            self.close()

    def close(self):
        self.dlg.destroy()
        self.app.settings = None


class SetupWizard:
    """Führt Schritt für Schritt durch die Ersteinrichtung."""

    def __init__(self, app, previous=None):
        self.app = app
        self.previous = previous
        self.cfg = dict(app.cfg)
        self.take_over = bool(previous)
        self.dlg = Gtk.Assistant()
        self.dlg.set_title(T("Einrichtung von {app}", app=APP_NAME))
        self.dlg.set_default_size(680, 480)
        self.dlg.set_icon_name(ICON_APP)
        self.dlg.connect("cancel", lambda *_: self.finish(False))
        self.dlg.connect("close", lambda *_: self.finish(True))
        self.dlg.connect("apply", lambda *_: None)
        self.build()
        self.dlg.set_forward_page_func(self.forward, None)
        self.dlg.show_all()

    # --- Aufbau
    def page(self, title, kind=None):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_border_width(16)
        self.dlg.append_page(box)
        self.dlg.set_page_title(box, title)
        self.dlg.set_page_type(box, kind or Gtk.AssistantPageType.CONTENT)
        self.dlg.set_page_complete(box, True)
        return box

    @staticmethod
    def text(box, text, wrap=True, opacity=1.0):
        lbl = Gtk.Label(label=text, xalign=0)
        lbl.set_line_wrap(wrap)
        lbl.set_opacity(opacity)
        box.pack_start(lbl, False, False, 0)
        return lbl

    def build(self):
        # 0: Willkommen
        p = self.page(T("Willkommen"), Gtk.AssistantPageType.INTRO)
        logo = Gtk.Image.new_from_icon_name(ICON_APP, Gtk.IconSize.DIALOG)
        logo.set_halign(Gtk.Align.START)
        p.pack_start(logo, False, False, 0)
        self.text(p, T("Dieser Assistent richtet {app} in wenigen Schritten ein.", app=APP_NAME))
        self.text(p, disclaimer(), opacity=0.75)

        # 1: frühere Einrichtung
        self.page_prev = None
        if self.previous:
            p = self.page(T("Frühere Einrichtung gefunden"))
            self.page_prev = p
            self.text(p, T("Es wurden Einstellungen einer früheren Installation gefunden "
                           "({n} Ordnerpaar(e), Stand vom {date}).",
                           n=len(self.previous["pairs"]), date=self.previous["date"]))
            self.r_keep = Gtk.RadioButton(label=T("Frühere Einstellungen übernehmen (empfohlen)"))
            self.r_new = Gtk.RadioButton(label=T("Komplett neu einrichten (bisherige Ordnerpaare und Sync-Stand "
                                                "verwerfen)"), group=self.r_keep)
            p.pack_start(self.r_keep, False, False, 0)
            p.pack_start(self.r_new, False, False, 0)
            self.text(p, T("Beim Neueinrichten bleiben deine Dateien erhalten; nur die Einstellungen und der "
                           "Sync-Stand werden verworfen. Der nächste Abgleich beginnt dann wieder von vorn."),
                      opacity=0.75)
            for r in (self.r_keep, self.r_new):
                r.connect("toggled", lambda *_: setattr(self, "take_over", self.r_keep.get_active()))

        # 2: Anmeldung
        p = self.page(T("Anmeldung bei Proton"))
        self.lbl_login = self.text(p, T("Anmeldung wird geprüft …"))
        b = Gtk.Button(label=T("Anmelden"))
        b.set_halign(Gtk.Align.START)
        b.connect("clicked", lambda *_: self.login())
        p.pack_start(b, False, False, 0)
        self.check_login()

        # 3: Ordnerpaar
        p = self.page(T("Erstes Ordnerpaar"))
        self.text(p, T("Wähle einen lokalen Ordner und den Ordner in Proton Drive, der damit abgeglichen werden soll."))
        grid = Gtk.Grid(column_spacing=8, row_spacing=8)
        p.pack_start(grid, False, False, 0)
        grid.attach(Gtk.Label(label=T("Lokaler Ordner"), xalign=0), 0, 0, 1, 1)
        self.e_local = Gtk.Entry(hexpand=True)
        grid.attach(self.e_local, 1, 0, 1, 1)
        b_local = Gtk.Button(label=T("Wählen …"))
        b_local.connect("clicked", lambda *_: self.choose_local())
        grid.attach(b_local, 2, 0, 1, 1)
        grid.attach(Gtk.Label(label=T("Ordner in Proton Drive"), xalign=0), 0, 1, 1, 1)
        self.e_remote = Gtk.Entry(hexpand=True)
        self.e_remote.set_text(REMOTE_ROOT + "/")
        grid.attach(self.e_remote, 1, 1, 1, 1)
        b_remote = Gtk.Button(label=T("Durchsuchen …"))
        b_remote.connect("clicked", lambda *_: self.app.browse_remote(self.dlg, self.e_remote))
        grid.attach(b_remote, 2, 1, 1, 1)
        self.text(p, T("Ein noch nicht vorhandener Proton-Ordner wird beim ersten Abgleich angelegt."), opacity=0.75)
        self.lbl_pair_err = self.text(p, "")
        self.page_pair = p
        for e in (self.e_local, self.e_remote):
            e.connect("changed", lambda *_: self.check_pair())
        self.check_pair()

        # 4: Einstellungen
        p = self.page(T("Einstellungen"))
        self.c_auto = Gtk.CheckButton(label=T("Beim Anmelden automatisch im Hintergrund starten"))
        self.c_auto.set_active(True)
        self.c_rt = Gtk.CheckButton(label=T("Lokale Änderungen sofort synchronisieren"))
        self.c_rt.set_active(True)
        for w in (self.c_auto, self.c_rt):
            p.pack_start(w, False, False, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        row.pack_start(Gtk.Label(label=T("Vollabgleich alle")), False, False, 0)
        self.s_int = Gtk.SpinButton.new_with_range(0, 1440, 15)
        self.s_int.set_value(int(self.cfg.get("interval", 15)))
        row.pack_start(self.s_int, False, False, 0)
        row.pack_start(Gtk.Label(label=T("Minuten (0 = aus). Nur der Vollabgleich erkennt Änderungen in "
                                         "Proton Drive.")), False, False, 0)
        p.pack_start(row, False, False, 0)

        # 5: Abschluss
        p = self.page(T("Fertig"), Gtk.AssistantPageType.CONFIRM)
        self.text(p, T("Die Einrichtung ist abgeschlossen. Starte am besten mit einem Trockenlauf: Er zeigt im "
                       "Protokoll, was passieren würde, ohne etwas zu verändern."))
        self.text(p, T("Weitere Ordnerpaare kannst du später im Fenster hinzufügen."), opacity=0.75)

    # --- Ablauf
    def forward(self, page, _data):
        if self.page_prev is not None and page == self.dlg.page_num(self.page_prev) and self.take_over:
            return self.dlg.get_n_pages() - 1      # Übernahme: direkt zum Abschluss
        return page + 1

    def check_login(self):
        def work():
            rc, _, _ = Cli(self.cfg["cli"]).run("filesystem", "list", REMOTE_ROOT, timeout=120)
            GLib.idle_add(self.lbl_login.set_text, T("Angemeldet – weiter mit dem nächsten Schritt.") if rc == 0
                          else T("Nicht angemeldet. Klicke auf „Anmelden“, der Browser öffnet sich."))
        threading.Thread(target=work, daemon=True).start()

    def login(self):
        def work():
            Cli(self.cfg["cli"]).run("auth", "login", timeout=600)
            GLib.idle_add(self.check_login)
        self.lbl_login.set_text(T("Anmeldung gestartet – bitte im Browser bestätigen …"))
        threading.Thread(target=work, daemon=True).start()

    def choose_local(self):
        fc = Gtk.FileChooserDialog(title=T("Lokalen Ordner wählen"), transient_for=self.dlg,
                                   action=Gtk.FileChooserAction.SELECT_FOLDER)
        fc.add_buttons(T("Abbrechen"), Gtk.ResponseType.CANCEL, T("Wählen"), Gtk.ResponseType.OK)
        if fc.run() == Gtk.ResponseType.OK:
            self.e_local.set_text(fc.get_filename())
        fc.destroy()

    def check_pair(self):
        pair = {"local": self.e_local.get_text().strip(), "remote": norm_remote(self.e_remote.get_text())}
        try:
            validate_pairs([pair])
            self.lbl_pair_err.set_text("")
            self.dlg.set_page_complete(self.page_pair, True)
        except SyncError as e:
            self.lbl_pair_err.set_text(str(e) if pair["local"] else "")
            self.dlg.set_page_complete(self.page_pair, False)

    def finish(self, apply_it):
        if apply_it:
            cfg = dict(self.cfg)
            if self.previous and self.take_over:
                cfg = dict(self.previous["cfg"])
            else:
                if self.previous:                       # neu einrichten: alten Sync-Stand verwerfen
                    for f in CONFIG_DIR.glob("state-*.json"):
                        try:
                            f.unlink()
                        except OSError:
                            pass
                cfg["pairs"] = [{"local": self.e_local.get_text().strip(),
                                 "remote": norm_remote(self.e_remote.get_text())}]
                cfg.update(autostart=self.c_auto.get_active(), realtime=self.c_rt.get_active(),
                           interval=self.s_int.get_value_as_int())
            cfg["setup_done"] = True
            self.app.cfg = cfg
            save_config(cfg)
            try:
                set_autostart(bool(cfg.get("autostart")))
            except OSError:
                pass
            self.app.apply_config()
        self.dlg.destroy()
        self.app.wizard = None
        if apply_it:
            self.app.show_window()


class SyncApp:
    def __init__(self, background=False):
        try:
            ensure_integration()  # vor dem ersten Icon-Zugriff von GTK
        except OSError as e:
            file_log(f"Integration nicht moeglich: {e}")
        self.background = background
        secure_existing()
        self.cfg = load_config()
        set_language(self.cfg["language"])
        self.syncing = False
        self.cancel = None
        self.jobs = {}           # Paar-Schluessel -> "quick" | "full" (wartende Auftraege)
        self.targeted = {}       # Paar-Schluessel -> {Pfade} aus dem Aenderungsprotokoll (Vorrang vor jobs)
        self.pair_errors = {}    # Paar-Schluessel -> Fehlertext
        self.state = "idle"
        self.state_detail = ""
        self.last_ok = None
        self.quitting = False
        self.monitors = {}       # Ordnerpfad -> (Monitor, Paar-Schluessel)
        self.debounce = {}       # Paar-Schluessel -> Timer-ID
        self.full_timer_id = None
        self.changelog_timer_id = None
        self.window = None
        self.indicator = None
        self.tray_ok = False
        self.settings = None
        self.wizard = None
        self.prog = {}           # Fortschritt der laufenden Phase (wird im Arbeits-Thread gefuellt)
        self.prog_bar = None
        self.lbl_prog = None
        self._first_activate = True
        self.log_buf = Gtk.TextBuffer()
        self.log_buf.create_mark("end", self.log_buf.get_end_iter(), False)
        for name, props in (("error", {"foreground": "#e5484d", "weight": 700}),
                            ("warn", {"foreground": "#d08000"}),
                            ("ok", {"foreground": "#2a9d4a", "weight": 700}),
                            ("head", {"weight": 700}),
                            ("up", {"foreground": "#2f80ed"}),
                            ("down", {"foreground": "#6d4aff"}),
                            ("muted", {"foreground": "#888888", "style": Pango.Style.ITALIC if Pango else 2})):
            self.log_buf.create_tag(name, **props)
        self.gapp = Gtk.Application(application_id=APP_ID, flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.gapp.connect("startup", self.on_startup)
        self.gapp.connect("activate", self.on_activate)

    def run(self):
        return self.gapp.run([sys.argv[0]])

    def pairs_by_key(self):
        return {pair_key(p): p for p in self.cfg["pairs"]}

    def sync_settings(self):
        return {"cli": self.cfg["cli"], "excludes": self.cfg["excludes"],
                "thumbnails": self.cfg.get("thumbnails", True),
                "parallel": self.cfg.get("parallel", PARALLEL_DEFAULT)}

    # ----- Lebenszyklus
    CSS = b"""
    progressbar.hadron-progress trough { min-height: 20px; border-radius: 10px; }
    progressbar.hadron-progress progress {
        min-height: 20px; border-radius: 10px;
        background-image: linear-gradient(to right, #6d4aff, #2f80ed);
        border: none;
    }
    progressbar.hadron-progress text { font-weight: bold; }
    """

    def on_startup(self, app):
        Gtk.Window.set_default_icon_name(ICON_APP)
        try:
            provider = Gtk.CssProvider()
            provider.load_from_data(self.CSS)
            Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), provider,
                                                     Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        except Exception as e:  # noqa
            file_log(f"CSS nicht geladen: {e}")
        self.build_tray()
        self.gapp.hold()
        self.apply_config()

    def on_activate(self, app):
        first = self._first_activate
        self._first_activate = False
        if not self.cfg.get("setup_done") and not self.cfg["pairs"]:
            self.start_wizard()
            return
        if first and self.background and self.tray_ok and self.cfg["pairs"]:
            return
        self.show_window()

    def start_wizard(self):
        if getattr(self, "wizard", None):
            self.wizard.dlg.present()
            return
        self.wizard = SetupWizard(self, previous_setup())

    def quit(self, *_):
        self.quitting = True
        if self.cancel:
            self.cancel.set()
        self.stop_monitors()
        self.gapp.quit()

    # ----- Tray
    def build_menu(self):
        menu = Gtk.Menu()
        self.mi_status = Gtk.MenuItem(label=T("Bereit"))
        self.mi_status.set_sensitive(False)
        menu.append(self.mi_status)
        menu.append(Gtk.SeparatorMenuItem())
        for label, cb in ((T("Jetzt synchronisieren"), lambda *_: self.request_sync("full")),
                          (T("Einstellungen öffnen"), lambda *_: self.show_window()),
                          (T("Über {app} …", app=APP_NAME), lambda *_: self.show_about())):
            item = Gtk.MenuItem(label=label)
            item.connect("activate", cb)
            menu.append(item)
        menu.append(Gtk.SeparatorMenuItem())
        quit_item = Gtk.MenuItem(label=T("Beenden"))
        quit_item.connect("activate", self.quit)
        menu.append(quit_item)
        menu.show_all()
        return menu

    def build_tray(self):
        menu = self.build_menu()
        if AppIndicator is None:
            self.tray_ok = False
            return
        try:
            self.indicator = AppIndicator.Indicator.new(
                "hadron-sync", ICON_IDLE, AppIndicator.IndicatorCategory.APPLICATION_STATUS)
            self.indicator.set_status(AppIndicator.IndicatorStatus.ACTIVE)
            self.indicator.set_title(APP_NAME)
            self.indicator.set_menu(menu)
            self.tray_ok = True
        except Exception as e:  # noqa
            file_log(f"Tray nicht verfuegbar: {e}")
            self.tray_ok = False

    def refresh_state(self):
        if self.syncing:
            self.set_state("busy")
        elif self.pair_errors:
            msgs = list(self.pair_errors.values())
            self.set_state("error", msgs[0] + (" " + T("(+{n} weitere)", n=len(msgs) - 1) if len(msgs) > 1 else ""))
        else:
            self.set_state("idle")

    def set_state(self, state, detail=""):
        self.state, self.state_detail = state, detail
        icon = {"idle": ICON_IDLE, "scan": ICON_SCAN, "busy": ICON_BUSY, "error": ICON_ERROR}[state]
        if state == "busy":
            text = T("Synchronisiere …")
        elif state == "scan":
            text = T("Vergleicht Dateien …")
        elif state == "error":
            text = T("Fehler: {msg}", msg=detail)[:90]
        else:
            text = T("Aktuell – letzter Abgleich {time}", time=f"{self.last_ok:%H:%M}") if self.last_ok else T("Bereit")
        if self.indicator:
            self.indicator.set_icon_full(icon, text)
        self.mi_status.set_label(text)
        if getattr(self, "lbl_status", None):
            self.lbl_status.set_text(text)

    def notify(self, title, body):
        try:
            n = Gio.Notification.new(title)
            n.set_body(body)
            n.set_icon(Gio.ThemedIcon.new(ICON_APP))
            self.gapp.send_notification(None, n)
        except Exception:  # noqa
            pass

    # ----- Fortschritt (Aufruf aus dem Arbeits-Thread: muss billig bleiben)
    def on_progress(self, phase, done, total, size=0, total_size=0):
        now = time.monotonic()
        p = self.prog
        if p.get("phase") != phase:
            p = self.prog = {"phase": phase, "start": now, "shown": 0.0}
        p["done"], p["total"], p["size"], p["total_size"] = done, total, size, total_size
        if now - p.get("shown", 0) < 0.5:     # Anzeige hoechstens 2x pro Sekunde
            return
        p["shown"] = now
        GLib.idle_add(self._show_progress)

    def _show_progress(self):
        p = dict(self.prog)
        if not p.get("phase"):
            return False
        wanted_state = "busy" if p["phase"] in ("up", "down") else "scan"
        if self.syncing and self.state != wanted_state:   # Icon nur waehrend echter Uebertragung auf "busy"
            self.set_state(wanted_state)
        if not self.prog_bar:
            return False
        done, total = p.get("done", 0), p.get("total", 0) or 0
        key = {"scan": "Lese Proton Drive: {done} von etwa {total} Ordnern",
               "up": "Lade hoch: {done} von {total} Dateien",
               "down": "Lade herunter: {done} von {total} Dateien"}.get(p["phase"])
        if key:
            text = T(key, done=done, total=total)
            if p["phase"] in ("up", "down") and p.get("total_size"):
                text += f" ({human(p.get('size', 0))} / {human(p['total_size'])})"
            self.prog_bar.set_fraction(min(1.0, done / total) if total else 0.0)
            self.prog_bar.set_text(text)
            self.prog_bar.set_show_text(True)
        elapsed = time.monotonic() - p.get("start", 0)
        if done > 0 and total > done and elapsed > 5:
            self.lbl_prog.set_text(T("noch etwa {time}", time=human_time(elapsed / done * (total - done))))
        elif p["phase"] != "idle":
            self.lbl_prog.set_text(T("Restzeit wird geschätzt …"))
        return False

    def reset_progress(self):
        self.prog = {}
        if self.prog_bar:
            self.prog_bar.set_fraction(0.0)
            self.prog_bar.set_show_text(False)
            self.lbl_prog.set_text("")

    # ----- Log
    def log(self, msg):
        file_log(msg)
        GLib.idle_add(self._append_log, msg)

    def pair_logger(self, label):
        """Schreibt die Paar-Ueberschrift erst, wenn es wirklich etwas zu melden gibt."""
        started = [False]

        def log(msg):
            if not started[0]:
                started[0] = True
                self.log(f"── {label} ──")
            self.log(msg)
        return log

    @staticmethod
    def log_tag(msg):
        m = msg.lstrip()
        if m.startswith(("FEHLER", "ERROR", "ERREUR")):
            return "error"
        if m.startswith("──"):
            return "head"
        if m.startswith("↑"):
            return "up"
        if m.startswith("↓"):
            return "down"
        low = m.lower()
        if low.startswith(("fertig", "done", "listo", "terminé")):
            return "ok"
        for word in ("konflikt", "conflict", "conflicto", "conflit", "übersprungen", "skipped", "omitido", "ignoré",
                     "erneut", "again", "nuevo", "relu"):
            if word in low:
                return "warn"
        if m.startswith(("Fortschritt", "Progress", "Progreso", "Progression", "Proton Drive:", "Vergleiche",
                         "Comparing", "Comparando", "Comparaison")):
            return "muted"
        return None

    def _append_log(self, msg):
        buf = self.log_buf
        tag = self.log_tag(msg)
        if tag:
            buf.insert_with_tags_by_name(buf.get_end_iter(), msg + "\n", tag)
        else:
            buf.insert(buf.get_end_iter(), msg + "\n")
        if buf.get_line_count() > 3000:
            buf.delete(buf.get_start_iter(), buf.get_iter_at_line(600))
        if getattr(self, "log_view", None):
            self.log_view.scroll_mark_onscreen(buf.get_mark("end"))
        return False

    # ----- Einstellungen anwenden
    def watch_signature(self):
        """Nur diese Werte bestimmen, welche Ordner ueberwacht werden - aendert sich keiner davon,
        muss die (bei vielen Ordnern langsame) Ueberwachung nicht neu aufgebaut werden."""
        if not self.cfg.get("realtime"):
            return None
        roots = tuple(sorted(os.path.abspath(os.path.expanduser(p["local"])) for p in self.cfg["pairs"]))
        return roots, self.cfg.get("excludes", "")

    def apply_config(self):
        for attr in ("full_timer_id", "changelog_timer_id"):
            if getattr(self, attr):
                GLib.source_remove(getattr(self, attr))
                setattr(self, attr, None)
        keys = set(self.pairs_by_key())
        self.pair_errors = {k: v for k, v in self.pair_errors.items() if k in keys}
        self.jobs = {k: v for k, v in self.jobs.items() if k in keys}
        self.targeted = {k: v for k, v in self.targeted.items() if k in keys}
        if not keys:
            self.stop_monitors()
            self._watch_sig = None
            self.refresh_state()
            return
        sig = self.watch_signature()
        if sig != getattr(self, "_watch_sig", "unset"):
            self.stop_monitors()
            self._watch_sig = sig
            if sig is not None:
                self.start_monitors()
        if int(self.cfg.get("interval", 0)) > 0:
            self.full_timer_id = GLib.timeout_add_seconds(int(self.cfg["interval"]) * 60, self._full_tick)
        self.changelog_timer_id = GLib.timeout_add_seconds(CHANGELOG_POLL_S, self._changelog_tick)
        GLib.timeout_add_seconds(5, self._initial_sync)
        GLib.timeout_add_seconds(10, self._changelog_tick)  # erster Blick kurz nach dem Start

    def _initial_sync(self):
        self.request_sync("full")
        return False

    def _full_tick(self):
        self.request_sync("full")
        return True

    def _changelog_tick(self):
        if self.quitting or not self.pairs_by_key():
            return False
        threading.Thread(target=self._changelog_check, daemon=True).start()
        return True

    def _changelog_check(self):
        pairs = self.pairs_by_key()
        cli = Cli(self.cfg["cli"])
        excludes = parse_excludes(self.cfg.get("excludes", DEFAULT_EXCLUDES))
        try:
            publish_own_log(cli, file_log)
            found = check_changelog(cli, pairs, excludes, CancelToken(), file_log)
        except SyncError as e:
            file_log(f"Aenderungsprotokoll: {e}")
            return
        if found:
            GLib.idle_add(self._changelog_found, found)

    def _changelog_found(self, found):
        for key, paths in found.items():
            self.targeted.setdefault(key, set()).update(paths)
        if self.syncing:
            if self.cancel:
                self.cancel.request_priority()
        else:
            self._run_jobs()
        return False

    # ----- Ueberwachung lokaler Aenderungen
    def start_monitors(self):
        excl = parse_excludes(self.cfg.get("excludes", ""))
        total, limit_hit = 0, False
        for key, p in self.pairs_by_key().items():
            if limit_hit:
                break
            root = os.path.abspath(os.path.expanduser(p["local"]))
            if not os.path.isdir(root):
                self.log(T("Ordner fehlt, keine Überwachung: {path}", path=root))
                continue
            for dirpath, dirnames, _ in os.walk(root):
                dirnames[:] = [d for d in dirnames if not excluded(d, excl)
                               and not os.path.islink(os.path.join(dirpath, d))]
                if self.add_monitor(dirpath, key):
                    total += 1
                else:
                    limit_hit = True
                    self.log(T("Ordnerüberwachung nicht vollständig möglich (inotify-Grenze erreicht) – "
                                "restliche Ordner werden nur über das Intervall abgeglichen. Grenze erhöhen: "
                                "sudo sysctl fs.inotify.max_user_watches=524288"))
                    break
                if total % 50 == 0:   # bei sehr vielen Ordnern die Oberflaeche zwischendurch reagieren lassen
                    while Gtk.events_pending():
                        Gtk.main_iteration_do(False)
        if total:
            self.log(T("Überwache {dirs} Ordner in {pairs} Ordnerpaar(en).", dirs=total, pairs=len(self.cfg["pairs"])))
        elif not limit_hit:
            self.log(T("Ordnerüberwachung nicht möglich (inotify-Limit?) – es gilt nur das Intervall."))

    def add_monitor(self, path, key):
        if path in self.monitors:
            return True
        try:
            m = Gio.File.new_for_path(path).monitor_directory(Gio.FileMonitorFlags.NONE, None)
            m.connect("changed", lambda mon, f, o, ev, k=key: self.on_fs_event(mon, f, o, ev, k))
            self.monitors[path] = (m, key)
            return True
        except Exception as e:  # noqa
            file_log(f"Monitor fehlgeschlagen fuer {path}: {e}")
            return False

    def stop_monitors(self):
        for m, _ in self.monitors.values():
            try:
                m.cancel()
            except Exception:  # noqa
                pass
        self.monitors = {}
        for tid in self.debounce.values():
            GLib.source_remove(tid)
        self.debounce = {}

    def on_fs_event(self, monitor, file, other, event, key):
        E = Gio.FileMonitorEvent
        # CHANGES_DONE_HINT ist laut GIO nicht garantiert; CHANGED direkt mitzunehmen faengt reine
        # Inhaltsaenderungen (Ueberschreiben ohne Umbenennen) zuverlaessig ab. Die eigene Ruhezeit
        # (DEBOUNCE_S) fasst mehrere Ereignisse desselben Speichervorgangs ohnehin zusammen.
        if event not in (E.CHANGED, E.CHANGES_DONE_HINT, E.CREATED, E.DELETED, E.ATTRIBUTE_CHANGED):
            return
        excl = parse_excludes(self.cfg.get("excludes", ""))
        if excluded(file.get_basename() or "", excl):
            return
        path = file.get_path()
        if event == E.CREATED and path and os.path.isdir(path):
            for dp, dns, _ in os.walk(path):
                dns[:] = [d for d in dns if not excluded(d, excl)]
                self.add_monitor(dp, key)
        elif event == E.DELETED and path:
            for p in [p for p in self.monitors if p == path or p.startswith(path + os.sep)]:
                try:
                    self.monitors.pop(p)[0].cancel()
                except Exception:  # noqa
                    pass
        self.schedule_quick(key)

    def schedule_quick(self, key):
        if key in self.debounce:
            GLib.source_remove(self.debounce[key])
        self.debounce[key] = GLib.timeout_add_seconds(DEBOUNCE_S, lambda k=key: self._debounce_fire(k))

    def _debounce_fire(self, key):
        self.debounce.pop(key, None)
        self.request_sync("quick", [key])
        return False

    # ----- Sync-Steuerung (Auftraege laufen nacheinander)
    def request_sync(self, mode="full", keys=None, dry_run=False):
        pairs = self.pairs_by_key()
        keys = list(pairs) if keys is None else [k for k in keys if k in pairs]
        if not keys:
            return
        if dry_run:
            if self.syncing:
                self.log(T("Trockenlauf nicht möglich, während ein Sync läuft."))
                return
            self._start([(k, "full") for k in keys], dry_run=True)
            return
        for k in keys:
            if mode == "full" or self.jobs.get(k) == "full":
                self.jobs[k] = "full"
            else:
                self.jobs[k] = "quick"
        if not self.syncing:
            self._run_jobs()

    def _run_jobs(self):
        if self.syncing or self.quitting:
            return False
        if self.targeted:
            key = next(iter(self.targeted))          # Änderungsprotokoll hat Vorrang vor der normalen Warteschlange
            paths = self.targeted.pop(key)
            self._start([(key, ("targeted", frozenset(paths)))], dry_run=False)
            return False
        if not self.jobs:
            return False
        jobs = list(self.jobs.items())
        self.jobs.clear()
        self._start(jobs, dry_run=False)
        return False

    def _start(self, jobs, dry_run):
        self.syncing = True
        self.cancel = CancelToken()
        cancel = self.cancel
        pairs = self.pairs_by_key()
        self.set_state("scan")

        def work():
            results = []
            for i, (key, mode) in enumerate(jobs):
                p = pairs.get(key)
                if p is None:
                    continue
                label = pair_label(p)
                base = self.sync_settings()      # aktuelle Einstellungen je Ordnerpaar neu lesen
                log = self.pair_logger(label)
                plan, err = None, None
                try:
                    cancel.check()
                    if isinstance(mode, tuple) and mode[0] == "targeted":
                        plan = run_targeted_sync(dict(base, local=p["local"], remote=p["remote"]), mode[1],
                                                 log, cancel, confirm=self.confirm)
                    else:
                        plan = run_sync(dict(base, local=p["local"], remote=p["remote"]), log, cancel,
                                        dry_run=dry_run, confirm=self.confirm, mode=mode, progress=self.on_progress)
                except Priority:
                    err = "Priority"
                except Cancelled:
                    err = "Abgebrochen"
                except Busy as e:
                    err = "Busy"
                    log(str(e) + " " + T("Neuer Versuch in einer Minute."))
                except SyncError as e:
                    err = str(e)
                    log(T("FEHLER: {msg}", msg=e))
                except Exception as e:  # noqa
                    err = f"{type(e).__name__}: {e}"
                    log(T("UNERWARTETER FEHLER: {msg}", msg=err))
                results.append((key, label, plan, err, mode))
                if err in ("Abgebrochen", "Priority"):
                    if err == "Priority":  # noch nicht begonnene Auftraege dieser Runde nicht verlieren
                        results += [(k2, "", None, "Priority", m2) for k2, m2 in jobs[i + 1:]]
                    break
            GLib.idle_add(self._on_done, results, dry_run)
        threading.Thread(target=work, daemon=True).start()

    def _on_done(self, results, dry_run):
        self.syncing = False
        self.reset_progress()
        new_errors, busy, copies, cancelled, did_work = [], [], [], False, False
        for key, label, plan, err, mode in results:
            if err == "Abgebrochen":
                cancelled = True
                continue
            if err == "Priority":  # Änderungsprotokoll ging vor - Auftrag unveraendert zurueck in die Warteschlange
                if isinstance(mode, tuple) and mode[0] == "targeted":
                    self.targeted.setdefault(key, set()).update(mode[1])
                elif mode:
                    self.jobs[key] = mode
                continue
            if err == "Busy":
                busy.append(key)
                continue
            msg = err or (T("{n} Fehler – siehe Protokoll", n=plan.errors) if plan is not None and plan.errors else None)
            if msg:
                if key not in self.pair_errors:
                    new_errors.append(f"{label}: {msg}")
                self.pair_errors[key] = f"{label}: {msg}"
            elif not dry_run:
                self.pair_errors.pop(key, None)
            if plan is not None:
                copies += plan.conflict_copies
                if not msg and plan.total() > 0:
                    did_work = True
        if not dry_run and not cancelled and not self.pair_errors and results:
            self.last_ok = datetime.now()
        self.refresh_state()
        if new_errors:
            self.notify(T("Hadron Sync: Fehler"), "\n".join(new_errors[:3]))
        if copies:
            self.notify(APP_NAME, T("{n} Konfliktkopien angelegt: {names}", n=len(copies),
                                               names=", ".join(os.path.basename(c) for c in copies[:3])))
        elif did_work and not dry_run and not cancelled and not new_errors:
            self.notify(APP_NAME, T("Fertig – Synchronisierung abgeschlossen."))
        if busy and not self.quitting:
            GLib.timeout_add_seconds(60, lambda b=busy: (self.request_sync("full", b), False)[1])
        if (self.jobs or self.targeted) and not self.quitting:
            GLib.timeout_add_seconds(2, self._run_jobs)
        return False

    def confirm(self, msg):
        ev, res = threading.Event(), [False]

        def ask():
            parent = self.window if self.window is not None and self.window.get_visible() else None
            dlg = Gtk.MessageDialog(transient_for=parent, modal=True, message_type=Gtk.MessageType.WARNING,
                                    buttons=Gtk.ButtonsType.YES_NO, text=T("Bestätigung erforderlich"))
            dlg.format_secondary_text(msg)
            dlg.set_keep_above(True)      # nicht hinter anderen Fenstern verschwinden
            dlg.set_urgency_hint(True)
            dlg.present()
            res[0] = dlg.run() == Gtk.ResponseType.YES
            dlg.destroy()
            ev.set()
            return False
        self.notify(T("Bestätigung erforderlich"), msg.split("\n\n")[0].replace("\n", " "))
        GLib.idle_add(ask)
        ev.wait()
        return res[0]

    # ----- Einstellungsfenster
    def show_window(self):
        if self.window is None:
            self.build_window()
        self.window.show_all()
        self.window.present()

    def build_window(self):
        w = Gtk.Window(title=APP_NAME)
        w.set_default_size(760, 660)
        w.set_icon_name(ICON_APP)
        w.connect("delete-event", lambda win, ev: win.hide_on_delete())
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_border_width(12)
        w.add(box)

        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        head.pack_start(Gtk.Image.new_from_icon_name(ICON_APP, Gtk.IconSize.DIALOG), False, False, 0)
        titles = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        name = Gtk.Label(xalign=0)
        name.set_markup(f"<span size='x-large' weight='bold'>{APP_NAME}</span>")
        titles.pack_start(name, False, False, 0)
        sub = Gtk.Label(label=f"{APP_VERSION} ({APP_DATE}) · {APP_AUTHOR}", xalign=0)
        sub.set_opacity(0.7)
        titles.pack_start(sub, False, False, 0)
        head.pack_start(titles, False, False, 0)
        box.pack_start(head, False, False, 0)

        self.prog_bar = Gtk.ProgressBar()
        self.prog_bar.set_show_text(False)
        self.prog_bar.get_style_context().add_class("hadron-progress")   # dicker und in den Logo-Farben
        box.pack_start(self.prog_bar, False, False, 0)
        self.lbl_prog = Gtk.Label(label="", xalign=0)
        self.lbl_prog.set_opacity(0.7)
        box.pack_start(self.lbl_prog, False, False, 0)

        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        for label, cb in ((T("Jetzt synchronisieren"), self.on_sync_now), (T("Trockenlauf"), self.on_dry_run),
                          (T("Sync abbrechen"), self.on_cancel), (T("Anmelden"), self.on_login),
                          (T("Einstellungen …"), lambda *_: self.show_settings())):
            b = Gtk.Button(label=label)
            b.connect("clicked", cb)
            bar.pack_start(b, False, False, 0)
        box.pack_start(bar, False, False, 0)

        self.lbl_status = Gtk.Label(label="", xalign=0)
        self.lbl_status.set_line_wrap(True)
        box.pack_start(self.lbl_status, False, False, 0)
        if not self.tray_ok:
            box.pack_start(Gtk.Label(
                label=T("Hinweis: Tray-Icon nicht verfügbar. Installiere gir1.2-ayatanaappindicator3-0.1 und aktiviere "
                        "die AppIndicator-Erweiterung."), xalign=0, wrap=True), False, False, 0)
        sw = Gtk.ScrolledWindow()
        sw.set_vexpand(True)
        self.log_view = Gtk.TextView.new_with_buffer(self.log_buf)
        self.log_view.set_editable(False)
        self.log_view.set_monospace(True)
        sw.add(self.log_view)
        box.pack_start(sw, True, True, 0)
        foot = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        note = Gtk.Label(label=T("Inoffizielles, privates, nicht-kommerzielles Projekt – Nutzung auf eigenes Risiko."),
                         xalign=0, wrap=True)
        note.set_opacity(0.75)
        foot.pack_start(note, True, True, 0)
        b_about = Gtk.Button(label=T("Über {app} …", app=APP_NAME))
        b_about.connect("clicked", lambda *_: self.show_about())
        foot.pack_end(b_about, False, False, 0)
        box.pack_start(foot, False, False, 0)
        self.window = w
        self.refresh_state()

    def show_settings(self):
        if getattr(self, "settings", None):
            self.settings.dlg.present()
            return
        self.settings = SettingsDialog(self)

    def on_sync_now(self, *_):
        self.request_sync("full")

    def on_dry_run(self, *_):
        self.request_sync("full", dry_run=True)

    def pair_dialog(self, parent, pair, others, index=None):
        dlg = Gtk.Dialog(title=T("Ordnerpaar"), transient_for=parent, modal=True)
        dlg.add_buttons(T("Abbrechen"), Gtk.ResponseType.CANCEL, "OK", Gtk.ResponseType.OK)
        dlg.set_default_size(620, -1)
        grid = Gtk.Grid(column_spacing=8, row_spacing=8)
        grid.set_border_width(12)
        dlg.get_content_area().add(grid)
        grid.attach(Gtk.Label(label=T("Lokaler Ordner"), xalign=0), 0, 0, 1, 1)
        e_local = Gtk.Entry(hexpand=True)
        e_local.set_text(pair["local"] if pair else "")
        grid.attach(e_local, 1, 0, 1, 1)
        b_local = Gtk.Button(label=T("Wählen …"))
        grid.attach(b_local, 2, 0, 1, 1)
        grid.attach(Gtk.Label(label=T("Ordner in Proton Drive"), xalign=0), 0, 1, 1, 1)
        e_remote = Gtk.Entry(hexpand=True)
        e_remote.set_text(norm_remote(pair["remote"]) if pair else REMOTE_ROOT + "/")
        grid.attach(e_remote, 1, 1, 1, 1)
        b_remote = Gtk.Button(label=T("Durchsuchen …"))
        grid.attach(b_remote, 2, 1, 1, 1)
        grid.attach(Gtk.Label(label=T("Ein noch nicht vorhandener Proton-Ordner wird beim ersten Abgleich angelegt."),
                              xalign=0, wrap=True), 0, 2, 3, 1)
        err = Gtk.Label(label="", xalign=0, wrap=True)
        grid.attach(err, 0, 3, 3, 1)

        def choose_local(*_):
            fc = Gtk.FileChooserDialog(title=T("Lokalen Ordner wählen"), transient_for=dlg,
                                       action=Gtk.FileChooserAction.SELECT_FOLDER)
            fc.add_buttons(T("Abbrechen"), Gtk.ResponseType.CANCEL, T("Wählen"), Gtk.ResponseType.OK)
            if e_local.get_text().strip():
                fc.set_current_folder(os.path.expanduser(e_local.get_text().strip()))
            if fc.run() == Gtk.ResponseType.OK:
                e_local.set_text(fc.get_filename())
            fc.destroy()
        b_local.connect("clicked", choose_local)
        b_remote.connect("clicked", lambda *_: self.browse_remote(dlg, e_remote))
        dlg.show_all()
        result = None
        while dlg.run() == Gtk.ResponseType.OK:
            cand = {"local": e_local.get_text().strip(), "remote": norm_remote(e_remote.get_text())}
            rest = [p for j, p in enumerate(others) if j != index]
            try:
                validate_pairs(rest + [cand])
            except SyncError as e:
                err.set_markup(f"<span foreground='#e5484d'>{html.escape(str(e))}</span>")
                continue
            result = cand
            break
        dlg.destroy()
        return result

    def show_about(self):
        dlg = Gtk.AboutDialog(transient_for=self.window if self.window is not None and self.window.get_visible() else None,
                              modal=True)
        dlg.set_program_name(APP_NAME)
        dlg.set_version(f"{APP_VERSION} ({APP_DATE})")
        dlg.set_authors([APP_AUTHOR])
        dlg.set_copyright(APP_AUTHOR)
        dlg.set_comments(disclaimer() + f"\n\n{T('Kontakt')}: {APP_CONTACT}")
        dlg.set_website(f"mailto:{APP_CONTACT}")
        dlg.set_website_label(APP_CONTACT)
        dlg.set_logo_icon_name(ICON_APP)
        dlg.set_keep_above(True)
        dlg.run()
        dlg.destroy()

    def browse_remote(self, parent, entry):
        cli = Cli(self.e_cli.get_text().strip() or self.cfg["cli"])
        dlg = Gtk.Dialog(title=T("Ordner in Proton Drive wählen"), transient_for=parent, modal=True)
        dlg.add_buttons(T("Abbrechen"), Gtk.ResponseType.CANCEL, T("Diesen Ordner wählen"), Gtk.ResponseType.OK)
        dlg.set_default_size(520, 460)
        box = dlg.get_content_area()
        box.set_spacing(6)
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        b_up = Gtk.Button(label=T("↑ Übergeordneter Ordner"))
        top.pack_start(b_up, False, False, 0)
        lbl = Gtk.Label(label="", xalign=0)
        lbl.set_ellipsize(Pango.EllipsizeMode.END)
        top.pack_start(lbl, True, True, 0)
        box.pack_start(top, False, False, 6)
        store = Gtk.ListStore(str)
        tv = Gtk.TreeView(model=store)
        tv.append_column(Gtk.TreeViewColumn(T("Unterordner (Doppelklick öffnet)"), Gtk.CellRendererText(), text=0))
        sw = Gtk.ScrolledWindow()
        sw.set_vexpand(True)
        sw.add(tv)
        box.pack_start(sw, True, True, 0)
        state = {"path": REMOTE_ROOT, "seq": 0}

        def load(path):
            state["seq"] += 1
            seq = state["seq"]
            lbl.set_text(T("Lade {path} …", path=path))
            store.clear()

            def work():
                try:
                    nodes = cli.list_dir(path)
                    names = sorted({node_name(n) for n in nodes if n.get("type") == "folder"
                                    and node_name(n) and "/" not in node_name(n)
                                    and "\\" not in node_name(n)}, key=str.lower)
                    msg = None
                except SyncError as e:
                    names, msg = [], str(e)
                GLib.idle_add(done, seq, path, names, msg)
            threading.Thread(target=work, daemon=True).start()

        def done(seq, path, names, msg):
            if seq != state["seq"]:
                return False
            if msg:
                lbl.set_text(f"{path}: {msg}")
                if path != REMOTE_ROOT and "not found" in msg.lower():
                    load(path.rpartition("/")[0] or REMOTE_ROOT)  # Ordner existiert (noch) nicht
                return False
            state["path"] = path
            lbl.set_text(path)
            for n in names:
                store.append([n])
            return False

        def go_up(*_):
            if state["path"] != REMOTE_ROOT:
                load(state["path"].rpartition("/")[0] or REMOTE_ROOT)

        def open_row(view, tpath, col):
            load(state["path"] + "/" + store[tpath][0])

        b_up.connect("clicked", go_up)
        tv.connect("row-activated", open_row)
        start = norm_remote(entry.get_text())
        load(start if start == REMOTE_ROOT or start.startswith(REMOTE_ROOT + "/") else REMOTE_ROOT)
        dlg.show_all()
        if dlg.run() == Gtk.ResponseType.OK:
            model, it = tv.get_selection().get_selected()
            chosen = state["path"] + "/" + model[it][0] if it else state["path"]
            entry.set_text(chosen)
        state["seq"] += 1  # laufende Ladevorgaenge ignorieren
        dlg.destroy()

    def apply_settings(self, cfg, ask_restart=True):
        """Uebernimmt neue Einstellungen sofort. Laeuft gerade ein Abgleich, kann er neu gestartet werden."""
        old_lang = _LANG
        old = dict(self.cfg)
        self.cfg = cfg
        save_config(cfg)
        try:
            set_autostart(bool(cfg.get("autostart")))
        except OSError as e:
            self.log(T("Autostart konnte nicht gesetzt werden: {msg}", msg=e))
        lang_changed = set_language(cfg["language"]) != old_lang
        self.apply_config()
        msg = T("Einstellungen übernommen.")
        if self.syncing and self.sync_settings() != {"cli": old["cli"], "excludes": old["excludes"],
                                                     "thumbnails": old.get("thumbnails", True),
                                                     "parallel": old.get("parallel", PARALLEL_DEFAULT)}:
            if ask_restart and self.ask_yes_no(T("Es läuft gerade ein Abgleich. Soll er mit den neuen Einstellungen "
                                                 "neu gestartet werden?")):
                self.jobs = {k: "full" for k in self.pairs_by_key()}
                if self.cancel:
                    self.cancel.set()
                msg = T("Einstellungen übernommen – laufender Abgleich wird neu gestartet.")
            else:
                msg = T("Einstellungen übernommen – der laufende Abgleich nutzt sie ab dem nächsten Ordnerpaar.")
        self.set_status(msg)
        if lang_changed:
            GLib.idle_add(self.rebuild_ui)
        return True

    def ask_yes_no(self, text):
        dlg = Gtk.MessageDialog(transient_for=self.window if self.window is not None and self.window.get_visible()
                                else None, modal=True, message_type=Gtk.MessageType.QUESTION,
                                buttons=Gtk.ButtonsType.YES_NO, text=T("Bestätigung erforderlich"))
        dlg.format_secondary_text(text)
        dlg.set_keep_above(True)
        answer = dlg.run() == Gtk.ResponseType.YES
        dlg.destroy()
        return answer

    def set_status(self, text):
        if getattr(self, "lbl_status", None):
            self.lbl_status.set_text(text)

    def rebuild_ui(self):
        """Baut Tray-Menue und Fenster in der neuen Sprache neu auf."""
        menu = self.build_menu()
        if self.indicator:
            self.indicator.set_menu(menu)
        if self.window is not None:
            visible = self.window.get_visible()
            self.window.destroy()
            self.window = self.log_view = self.lbl_status = None
            self.prog_bar = self.lbl_prog = None
            if visible:
                self.show_window()
        self.refresh_state()
        if getattr(self, "lbl_status", None):
            self.lbl_status.set_text(T("Gespeichert."))
        return False

    def on_cancel(self, *_):
        self.jobs.clear()
        if self.cancel:
            self.cancel.set()

    def on_login(self, *_):
        cli = self.e_cli.get_text().strip() or self.cfg["cli"]

        def work():
            try:
                self.log(T("Anmeldung gestartet – bitte im Browser bestätigen …"))
                rc, out, err = Cli(cli).run("auth", "login")
                self.log((out + err).strip())
                self.log(T("Anmeldung erfolgreich.") if rc == 0 else T("Anmeldung fehlgeschlagen."))
            except SyncError as e:
                self.log(T("FEHLER: {msg}", msg=e))
        threading.Thread(target=work, daemon=True).start()


def previous_setup():
    """Erkennt eine frühere Einrichtung: Ordnerpaare in der Konfiguration oder gespeicherte Sync-Staende."""
    cfg = load_config()
    states = sorted(CONFIG_DIR.glob("state-*.json")) if CONFIG_DIR.is_dir() else []
    if not cfg["pairs"] and not states:
        return None
    when = ""
    stamps = [f.stat().st_mtime for f in ([CONFIG_FILE] if CONFIG_FILE.exists() else []) + states]
    if stamps:
        when = datetime.fromtimestamp(max(stamps)).strftime("%d.%m.%Y")
    return {"pairs": cfg["pairs"], "states": len(states), "date": when, "cfg": cfg}


def run_gui(background=False):
    set_language(load_config()["language"])
    try:
        gui_imports()
    except (ImportError, ValueError) as e:
        print(T("GTK nicht verfügbar ({msg}).\nInstalliere: {cmd}", msg=e,
                cmd="sudo apt install python3-gi gir1.2-gtk-3.0 gir1.2-ayatanaappindicator3-0.1 libglib2.0-bin"))
        sys.exit(1)
    SyncApp(background).run()


def main():
    set_language(load_config()["language"])
    ap = argparse.ArgumentParser(description=f"{APP_NAME} {APP_VERSION} ({APP_DATE}) – {APP_AUTHOR} <{APP_CONTACT}>",
                                 epilog=disclaimer())
    ap.add_argument("--background", action="store_true", help="nur Tray-Icon, kein Fenster (Autostart)")
    ap.add_argument("--headless", action="store_true",
                    help="ohne GUI ausfuehren (ohne --local: alle gespeicherten Ordnerpaare)")
    ap.add_argument("--local")
    ap.add_argument("--remote", default=REMOTE_ROOT)
    ap.add_argument("--cli")
    ap.add_argument("--exclude")
    ap.add_argument("--mode", choices=("full", "quick"), default="full")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--yes", action="store_true", help="Rueckfragen automatisch bestaetigen")
    ap.add_argument("--no-thumbnails", action="store_true", help="ohne Vorschaubilder hochladen (schneller)")
    ap.add_argument("--parallel", type=int, help="gleichzeitige Abfragen an Proton Drive (1-8)")
    ap.add_argument("--version", action="version", version=f"{APP_NAME} {APP_VERSION} ({APP_DATE})")
    ap.add_argument("--about", action="store_true", help="Hinweise zu Projekt und Autor anzeigen")
    ap.add_argument("--setup", action="store_true",
                    help="Menueeintrag und Symbole einrichten (vom Installer genutzt), mit --cli den CLI-Pfad speichern")
    ap.add_argument("--autostart", choices=("on", "off"), help="mit --setup: Autostart ein- oder ausschalten")
    a = ap.parse_args()
    secure_existing()
    if a.about:
        print(about_text())
        return
    if a.setup:
        cfg = load_config()
        if a.cli:
            cfg["cli"] = a.cli
        if a.autostart:
            cfg["autostart"] = a.autostart == "on"
        save_config(cfg)
        ensure_integration()
        set_autostart(bool(cfg.get("autostart")))
        set_language(cfg["language"])
        print(T("Einrichtung abgeschlossen: Menüeintrag und Symbole installiert."))
        return
    if not a.headless:
        run_gui(a.background)
        return
    stored = load_config()
    set_language(stored["language"])
    pairs = [{"local": a.local, "remote": a.remote}] if a.local else stored["pairs"]
    if not pairs:
        ap.error(T("Keine Ordnerpaare gespeichert – --local angeben oder in der GUI einrichten."))
    base = {"excludes": a.exclude if a.exclude is not None else stored["excludes"],
            "cli": a.cli or stored["cli"],
            "thumbnails": False if a.no_thumbnails else stored.get("thumbnails", True),
            "parallel": a.parallel or stored.get("parallel", PARALLEL_DEFAULT)}
    rc = 0
    for p in pairs:
        print(f"── {pair_label(p)} ──")
        try:
            run_sync(dict(base, **p), print, CancelToken(), dry_run=a.dry_run, confirm=lambda m: a.yes, mode=a.mode)
        except Busy as e:
            print(str(e))
            rc = max(rc, 2)
        except SyncError as e:
            print(T("FEHLER: {msg}", msg=e))
            rc = 1
    sys.exit(rc)


if __name__ == "__main__":
    main()
