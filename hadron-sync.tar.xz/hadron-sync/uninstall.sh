#!/usr/bin/env bash
# Hadron Sync – Deinstallation (Autor: Dennis Peteranderl <hadron.unfreeze611@passmail.net>).
# Synchronisierte Dateien werden NIE geloescht (weder lokal noch in Proton Drive).
set -euo pipefail
APP_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/hadron-sync"
CONFIG_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/hadron-sync"
STATE_DIR="${XDG_STATE_HOME:-$HOME/.local/state}/hadron-sync"
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
ICONS="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/scalable/apps"
OPT_YES=0; OPT_PURGE=0; OPT_CLI=0; OPT_LOGOUT=0
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONTACT="hadron.unfreeze611@passmail.net"
case "${LANGUAGE:-${LC_ALL:-${LC_MESSAGES:-${LANG:-}}}}" in
    de*) UI=de ;; es*) UI=es ;; fr*) UI=fr ;; *) UI=en ;;
esac
if [ -f "$SCRIPT_DIR/messages.sh" ]; then
    # shellcheck source=messages.sh
    . "$SCRIPT_DIR/messages.sh"
fi
msg()  { local key="M_${1}_${UI}" fb="M_${1}_en"; local fmt="${!key:-${!fb:-$1}}"; shift; printf "$fmt\n" "$@"; }
raw()  { local key="M_${1}_${UI}" fb="M_${1}_en"; local fmt="${!key:-${!fb:-$1}}"; shift; printf "$fmt" "$@"; }
say()  { msg "$@"; }
info() { printf '\033[1;34m==>\033[0m '; msg "$@"; }
ask()  { [ "$OPT_YES" = 1 ] && return 1     # bei --yes nur entfernen, was per Option verlangt ist
         [ -t 0 ] || return 1
         local a; read -r -p "$(raw "$@")" a
         case "${a,,}" in j|ja|y|yes|s|si|sí|o|oui) return 0 ;; *) return 1 ;; esac; }
while [ $# -gt 0 ]; do
    case "$1" in
        -y|--yes) OPT_YES=1 ;; --purge) OPT_PURGE=1 ;; --remove-cli) OPT_CLI=1 ;; --logout) OPT_LOGOUT=1 ;;
        -h|--help) say un_usage; exit 0 ;;
        *) echo "?: $1" >&2; exit 1 ;;
    esac; shift
done
[ "$(id -u)" -ne 0 ] || { say run_as_user; exit 1; }

say un_title
if pgrep -u "$(id -u)" -f 'hadron_sync\.py' >/dev/null 2>&1; then
    info un_stop
    pkill -TERM -u "$(id -u)" -f 'hadron_sync\.py' || true; sleep 1
fi
CFG="$CONFIG_DIR/config.json"
CLI="$(python3 -c "import json,sys;print(json.load(open(sys.argv[1])).get('cli',''))" "$CFG" 2>/dev/null || true)"
[ -n "$CLI" ] || CLI="$(command -v proton-drive 2>/dev/null || true)"

rm -f "$HOME/.config/autostart/hadron-sync.desktop" "$APPS/local.hadronsync.App.desktop" \
      "$HOME/.local/bin/hadron-sync"
for n in hadron-sync hadron-sync-tray-idle hadron-sync-tray-scan hadron-sync-tray-busy hadron-sync-tray-error; do
    f="$ICONS/$n.svg"
    if [ -f "$f" ] && grep -q 'hadron-sync-icon-\|6d4aff\|2f80ed\|e5484d' "$f"; then rm -f "$f"; fi   # nur eigene Symbole
done
rm -rf "$APP_DIR"
info un_removed

if [ "$OPT_PURGE" = 1 ] || ask un_purge_q; then
    rm -rf "$CONFIG_DIR" "$STATE_DIR"; info un_purged
else
    info un_kept "$CONFIG_DIR"
fi
if [ -n "$CLI" ] && [ -x "$CLI" ]; then
    if [ "$OPT_LOGOUT" = 1 ] || ask un_logout_q; then
        "$CLI" auth logout </dev/null || true; info un_logout
    fi
    if [ "$OPT_CLI" = 1 ] || ask un_cli_q "$CLI"; then
        if [ -w "$(dirname "$CLI")" ]; then rm -f "$CLI"; else sudo rm -f "$CLI"; fi
        info un_cli_removed
    fi
fi
say un_done "$CONTACT"
