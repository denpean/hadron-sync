# Einrichtungsassistent, Speicheranzeige, Fortschritt/Restzeit und Farblogik des Protokolls.
import json, os, shutil, sys, time
from unittest.mock import MagicMock
MODDIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = "/tmp/hadron-sync-test/ui"
shutil.rmtree(B, ignore_errors=True)
os.environ.update(HOME=f"{B}/home", XDG_CONFIG_HOME=f"{B}/cfg", XDG_STATE_HOME=f"{B}/state",
                  FAKE_REMOTE=f"{B}/remote", FAKE_TRASH=f"{B}/trash")
os.environ["PATH"] = "/tmp/hadron-sync-test/fakebin:" + os.environ["PATH"]
for d in ("home", "remote/my-files/U", "local"):
    os.makedirs(f"{B}/{d}")
sys.path.insert(0, MODDIR)
import hadron_sync as ps
ps.set_language("de")
FAILS = []
def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: FAILS.append(m)
L, R = f"{B}/local", f"{B}/remote/my-files/U"
CLI = "/tmp/hadron-sync-test/fakebin/proton-drive"
now = time.time()
def w(p, t, ts=now - 500):
    os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(t); os.utime(p, (ts, ts))

# --- 1) Fortschrittsmeldungen der Engine
cfg = {"local": L, "remote": "/my-files/U", "cli": CLI, "excludes": ps.DEFAULT_EXCLUDES}
for i in range(7): w(f"{L}/u{i}.txt", "x" * 1000)
w(f"{R}/ordner/r.txt", "y" * 2000)
events = []
p = ps.run_sync(cfg, [].append, ps.CancelToken(), confirm=lambda m: True, progress=lambda *a: events.append(a))
phases = {e[0] for e in events}
ok("scan" in phases and "up" in phases and "down" in phases, f"Phasen gemeldet: {sorted(phases)}")
ups = [e for e in events if e[0] == "up"]
ok(ups and ups[-1][1] == 7 and ups[-1][2] == 7, f"Upload-Fortschritt endet bei 7/7 ({ups[-1] if ups else None})")
ok(all(len(e) == 5 for e in ups) and ups[-1][3] == 7000, f"Bytes werden mitgezaehlt ({ups[-1][3] if ups else 0})")
ok(all(e[1] <= e[2] for e in events if e[2]), "Erledigt nie groesser als Gesamtzahl")
# Ohne Rueckmeldung laeuft alles genauso (keine Pflicht)
w(f"{L}/ohne.txt", "z", now + 10)
p = ps.run_sync(cfg, [].append, ps.CancelToken(), confirm=lambda m: True)
ok(p.errors == 0, "Sync funktioniert auch ohne Fortschritts-Rueckmeldung")

# --- 3) Farblogik des Protokolls
for zeile, erwartet in (("  FEHLER Upload x: kaputt", "error"), ("ERROR Upload x", "error"),
                        ("── ~/Ordner ↔ /my-files ──", "head"), ("  ↑ datei.txt", "up"), ("  ↓ datei.txt", "down"),
                        ("Fertig: 10 Aktionen erfolgreich, 0 Fehler, 0 Konfliktkopien.", "ok"),
                        ("  Konfliktkopie: a (Konflikt …).txt", "warn"),
                        ("  Ordner erneut gelesen (einzeln): /my-files/X", "warn"),
                        ("  Proton Drive: 25 von etwa 100 Ordnern gelesen …", "muted"),
                        ("  Fortschritt: 3 von 9 Dateien hochgeladen (1 KiB von 3 KiB)", "muted"),
                        ("Lese lokalen Ordner …", None)):
    ok(ps.SyncApp.log_tag(zeile) == erwartet, f"Farbe {erwartet or 'normal'}: {zeile[:42]}")
ps.set_language("en")
ok(ps.SyncApp.log_tag("ERROR Upload x: broken") == "error" and ps.SyncApp.log_tag("Done: 3 actions") == "ok",
   "Farblogik auch auf Englisch")
ps.set_language("de")

# --- 4) Anzeige bremst den Sync nicht: Meldungen werden gedrosselt
class G:
    calls = 0
    @staticmethod
    def idle_add(fn, *a): G.calls += 1; return 1
    @staticmethod
    def timeout_add_seconds(s, fn, *a): return 1
    @staticmethod
    def source_remove(i): pass
ps.Gtk = MagicMock(); ps.Gio = MagicMock(); ps.GLib = G; ps.AppIndicator = MagicMock(); ps.Pango = MagicMock()
ps.save_config({"pairs": [{"local": L, "remote": "/my-files/U"}], "cli": CLI, "language": "de", "setup_done": True})
app = ps.SyncApp(background=True); app.log_buf.get_line_count.return_value = 0
app.build_tray()
t0 = time.time()
for i in range(20000):
    app.on_progress("up", i, 20000, i * 10, 200000)
dauer = time.time() - t0
ok(G.calls <= 30, f"20.000 Meldungen loesen nur {G.calls} Anzeige-Aktualisierungen aus")
ok(dauer < 1.0, f"20.000 Meldungen kosten nur {dauer*1000:.0f} ms")
ok(app.prog["done"] == 19999 and app.prog["phase"] == "up", "Letzter Wert wird trotzdem gemerkt")

# --- 5) Restzeit-Schaetzung
ok(ps.human_time(45) == "45 Sek." and ps.human_time(300) == "5 Min." and ps.human_time(3900) == "1 Std. 5 Min.",
   f"Zeitangaben: {ps.human_time(45)}, {ps.human_time(300)}, {ps.human_time(3900)}")
app.prog_bar, app.lbl_prog = MagicMock(), MagicMock()
app.prog = {"phase": "up", "start": time.monotonic() - 10, "done": 100, "total": 200, "size": 50, "total_size": 100}
app._show_progress()
ok(abs(app.prog_bar.set_fraction.call_args.args[0] - 0.5) < 0.01, "Balken zeigt 50 %")
ok("noch etwa 10 Sek." in app.lbl_prog.set_text.call_args.args[0], f"Restzeit: {app.lbl_prog.set_text.call_args.args[0]}")
app.prog = {"phase": "scan", "start": time.monotonic() - 10, "done": 50, "total": 500}
app._show_progress()
ok("50 von etwa 500 Ordnern" in app.prog_bar.set_text.call_args.args[0], "Text beim Einlesen")
app.reset_progress()
ok(app.prog == {} and app.prog_bar.set_show_text.call_args.args[0] is False, "Fortschritt wird zurueckgesetzt")

# --- 7) Einstellungen erreichen den Sync (Vorschaubilder, gleichzeitige Abfragen)
app.cfg = dict(ps.load_config(), pairs=[{"local": L, "remote": "/my-files/U"}], thumbnails=False, parallel=2, cli=CLI)
gesehen = {}
def fake_run_sync(cfg, *a, **kw):
    gesehen.update(cfg); return ps.Plan()
orig = ps.run_sync; ps.run_sync = fake_run_sync
app.request_sync("full")
for _ in range(100):
    if gesehen: break
    time.sleep(0.02)
ps.run_sync = orig
ok(gesehen.get("thumbnails") is False and gesehen.get("parallel") == 2, f"Einstellungen werden weitergereicht: {gesehen.get('thumbnails')}, {gesehen.get('parallel')}")

# --- 8) Erkennung einer frueheren Einrichtung
shutil.rmtree(f"{B}/cfg", ignore_errors=True)
ok(ps.previous_setup() is None, "Frische Installation: nichts gefunden")
ps.save_config({"pairs": [{"local": L, "remote": "/my-files/U"}], "language": "de"})
prev = ps.previous_setup()
ok(prev and len(prev["pairs"]) == 1 and prev["date"], f"Frühere Einrichtung erkannt: {prev and prev['date']}")
ps.save_config({"pairs": [], "language": "de"})
ps.save_state(ps.state_path(L, "/my-files/U"), {}, set())
prev = ps.previous_setup()
ok(prev and prev["states"] == 1, "Auch ein übrig gebliebener Sync-Stand zählt als frühere Einrichtung")

# --- 9) Assistent: Übernehmen gegen Neueinrichten
ps.save_config({"pairs": [{"local": L, "remote": "/my-files/U"}], "language": "de", "interval": 42, "cli": CLI})
sp = ps.state_path(L, "/my-files/U"); ps.save_state(sp, {}, set())
app.cfg = ps.load_config()
prev = ps.previous_setup()
wz = ps.SetupWizard(app, prev)
ok(wz.take_over is True, "Voreinstellung: übernehmen")
wz.finish(True)
c = ps.load_config()
ok(c["pairs"] == [{"local": L, "remote": "/my-files/U"}] and c["interval"] == 42,
   "Übernehmen behält Ordnerpaare und Einstellungen")
ok(c["setup_done"] is True and sp.exists(), "Sync-Stand bleibt erhalten, Einrichtung gilt als erledigt")
# Neu einrichten
app.cfg = ps.load_config()
wz = ps.SetupWizard(app, ps.previous_setup())
wz.take_over = False
L2 = f"{B}/local2"; os.makedirs(L2, exist_ok=True)
# Gtk ist hier eine Attrappe und liefert fuer jedes Feld dasselbe Objekt - eigene Attrappen einsetzen
wz.e_local, wz.e_remote = MagicMock(), MagicMock()
wz.c_auto, wz.c_rt, wz.s_int = MagicMock(), MagicMock(), MagicMock()
wz.e_local.get_text.return_value = L2
wz.e_remote.get_text.return_value = "/my-files/Neu"
wz.c_auto.get_active.return_value = False
wz.c_rt.get_active.return_value = True
wz.s_int.get_value_as_int.return_value = 360
wz.finish(True)
c = ps.load_config()
ok(c["pairs"] == [{"local": L2, "remote": "/my-files/Neu"}], f"Neueinrichtung setzt das neue Ordnerpaar: {c['pairs']}")
ok(c["interval"] == 360 and c["autostart"] is False, "Neue Einstellungen übernommen")
ok(not sp.exists() and not list(ps.CONFIG_DIR.glob("state-*.json")), "Neueinrichtung verwirft den alten Sync-Stand")
ok(os.path.isdir(L2) and os.path.isdir(L), "Dateien und Ordner bleiben in jedem Fall erhalten")
# Abbruch ändert nichts
vorher = ps.load_config()
wz = ps.SetupWizard(app, ps.previous_setup()); wz.finish(False)
ok(ps.load_config() == vorher, "Abbruch des Assistenten ändert nichts")
# Assistent startet nur bei fehlender Einrichtung
app.cfg = dict(ps.load_config(), setup_done=False, pairs=[])
app.show_window = MagicMock(); app.start_wizard = MagicMock()
app._first_activate = True; app.on_activate(None)
ok(app.start_wizard.called and not app.show_window.called, "Ohne Einrichtung startet der Assistent")
app.cfg = dict(ps.load_config(), setup_done=True)
app.start_wizard.reset_mock(); app.on_activate(None)
ok(not app.start_wizard.called and app.show_window.called, "Mit Einrichtung öffnet sich direkt das Fenster")

# --- 10) Eigenes Einstellungsfenster
ps.save_config({"pairs": [{"local": L, "remote": "/my-files/U"}], "cli": CLI, "language": "de", "setup_done": True,
                "interval": 15, "parallel": 4, "thumbnails": True})
app.cfg = ps.load_config(); app.window = MagicMock(); app.lbl_status = MagicMock(); app.settings = None
app.show_settings()
ok(app.settings is not None, "Einstellungsfenster wird geöffnet")
dlg = app.settings
ok(dlg.pairs == [{"local": L, "remote": "/my-files/U"}], "Ordnerpaare stehen im Einstellungsfenster")
# eigene Attrappen je Feld (Gtk ist hier eine Attrappe und liefert sonst dasselbe Objekt)
for feld, wert in (("e_excl", "*.tmp"), ("e_cli", CLI)):
    setattr(dlg, feld, MagicMock()); getattr(dlg, feld).get_text.return_value = wert
for feld, wert in (("c_lang", "de"),):
    setattr(dlg, feld, MagicMock()); getattr(dlg, feld).get_active_id.return_value = wert
for feld, wert in (("c_auto", True), ("c_rt", False), ("c_thumbs", False)):
    setattr(dlg, feld, MagicMock()); getattr(dlg, feld).get_active.return_value = wert
for feld, wert in (("s_int", 360), ("s_par", 2)):
    setattr(dlg, feld, MagicMock()); getattr(dlg, feld).get_value_as_int.return_value = wert
neu = dlg.read()
ok(neu["interval"] == 360 and neu["parallel"] == 2 and neu["thumbnails"] is False
   and neu["realtime"] is False and neu["excludes"] == "*.tmp", f"Alle Einstellungen werden gelesen: {neu['interval']}")
# Speichern & anwenden
app.apply_config = MagicMock()
dlg.on_response(None, ps.Gtk.ResponseType.APPLY)
c = ps.load_config()
ok(c["interval"] == 360 and c["parallel"] == 2, "Einstellungen gespeichert")
ok(app.cfg["parallel"] == 2 and app.apply_config.called, "Sofort angewendet (Überwachung/Intervall neu gesetzt)")
ok(app.settings is None, "Fenster schließt nach dem Anwenden")
ok("übernommen" in app.lbl_status.set_text.call_args.args[0], f"Rückmeldung: {app.lbl_status.set_text.call_args.args[0]}")
# Ungültiges Paar wird abgewiesen, Fenster bleibt offen
app.show_settings(); dlg = app.settings
dlg.pairs = [{"local": "/gibt/es/nicht", "remote": "/my-files/X"}]
dlg.lbl_err = MagicMock(); dlg.on_response(None, ps.Gtk.ResponseType.APPLY)
ok(app.settings is dlg and "Nicht gespeichert" in dlg.lbl_err.set_text.call_args.args[0], "Ungültiges Paar: nicht gespeichert")
dlg.close()

# --- 11) Neue Einstellungen gelten sofort, auch bei laufendem Abgleich
app.cfg = ps.load_config(); app.apply_config = MagicMock(); app.lbl_status = MagicMock()
gesehen.clear()
app.syncing = False
app.request_sync = MagicMock()
app.syncing = True
app.ask_yes_no = MagicMock(return_value=True)
app.cancel = MagicMock()
app.apply_settings(dict(app.cfg, parallel=6), ask_restart=True)
ok(app.ask_yes_no.called and app.cancel.set.called, "Laufender Abgleich wird auf Wunsch abgebrochen")
ok(app.jobs and all(v == "full" for v in app.jobs.values()), "Danach ist ein voller Abgleich eingeplant")
ok("neu gestartet" in app.lbl_status.set_text.call_args.args[0], "Rückmeldung nennt den Neustart")
app.ask_yes_no = MagicMock(return_value=False); app.cancel = MagicMock(); app.jobs = {}
app.apply_settings(dict(app.cfg, parallel=3), ask_restart=True)
ok(not app.cancel.set.called and "nächsten Ordnerpaar" in app.lbl_status.set_text.call_args.args[0],
   "Ohne Neustart: gilt ab dem nächsten Ordnerpaar")
app.syncing = False
# Ein erneutes Anwenden derselben Sync-Einstellungen fragt nicht nach Neustart
app.syncing = True; app.ask_yes_no = MagicMock(return_value=True)
app.apply_settings(dict(app.cfg), ask_restart=True)
ok(not app.ask_yes_no.called, "Unveraenderte Sync-Einstellungen fragen nicht nach Neustart")
app.syncing = False
# Die Sync-Einstellungen werden je Auftrag frisch gelesen
app.cfg = dict(app.cfg, parallel=7, thumbnails=False)
ok(app.sync_settings()["parallel"] == 7 and app.sync_settings()["thumbnails"] is False,
   "sync_settings liefert immer den aktuellen Stand")

# --- 12) Vorrang des Aenderungsprotokolls vor der normalen Warteschlange
app.jobs = {"pairX": "full"}; app.targeted = {"pairY": {"a.txt", "b.txt"}}
app.syncing = False; app._start = MagicMock()
app._run_jobs()
called = app._start.call_args.args[0]
ok(called == [("pairY", ("targeted", frozenset({"a.txt", "b.txt"})))], f"Änderungsprotokoll-Auftrag hat Vorrang: {called}")
ok(app.targeted == {} and app.jobs == {"pairX": "full"}, "Normaler Auftrag bleibt unangetastet in der Warteschlange")
app.jobs = {}; app.targeted = {}

# --- 13) _changelog_found: waehrend eines laufenden Syncs wird priorisiert unterbrochen
app.syncing = True; app.cancel = MagicMock(); app._run_jobs = MagicMock()
app._changelog_found({"pairZ": {"c.txt"}})
ok(app.targeted.get("pairZ") == {"c.txt"} and app.cancel.request_priority.called and not app._run_jobs.called,
   "Laufender Sync wird unterbrochen, statt sofort einen zweiten zu starten")
app.syncing = False; app.cancel = None; app.targeted = {}
app._changelog_found({"pairZ": {"c.txt"}})
ok(app.targeted.get("pairZ") == {"c.txt"} and app._run_jobs.called, "Ohne laufenden Sync wird sofort gestartet")
app.targeted = {}

# --- 14) _on_done: "Priority" verwirft nichts, sondern reiht wieder ein
app.jobs = {}; app.targeted = {}
app._on_done([("pairA", "", None, "Priority", "full")], False)
ok(app.jobs.get("pairA") == "full", "Unterbrochener normaler Auftrag wird mit seinem Modus zurueckgestellt")
app._on_done([("pairB", "", None, "Priority", ("targeted", frozenset({"x.txt"})))], False)
ok(app.targeted.get("pairB") == {"x.txt"}, "Unterbrochener gezielter Auftrag bleibt vorgemerkt")
ok("pairA" not in app.pair_errors and "pairB" not in app.pair_errors, "Priority zaehlt nicht als Fehler")

# --- 15) Speicheranzeige vollstaendig entfernt
ok("quota_gb" not in ps.load_config(), "Kein Speicher-Kontingent mehr in der Konfiguration")
ok(not hasattr(ps.SyncApp, "refresh_storage"), "Keine Speicheranzeige-Methode mehr im Hauptfenster")
ok(not hasattr(ps, "load_stats") and not hasattr(ps, "save_stats"), "Keine Speicher-Statistikfunktionen mehr im Programm")

# --- 16) Symbol nur waehrend echter Uebertragung, sonst ein eigener "Vergleiche"-Status
app.prog_bar, app.lbl_prog = MagicMock(), MagicMock()
app.syncing = True; app.state = "idle"
app.prog = {"phase": "scan", "start": time.monotonic(), "done": 5, "total": 50}
app._show_progress()
ok(app.state == "scan" and app.indicator.set_icon_full.call_args.args[0] == ps.ICON_SCAN,
   "Waehrend des Einlesens/Vergleichens: eigenes Symbol, nicht das Sync-Symbol")
app.prog = {"phase": "up", "start": time.monotonic(), "done": 1, "total": 3, "size": 0, "total_size": 0}
app._show_progress()
ok(app.state == "busy" and app.indicator.set_icon_full.call_args.args[0] == ps.ICON_BUSY,
   "Waehrend eines echten Uploads: Sync-Symbol")
app.prog = {"phase": "down", "start": time.monotonic(), "done": 1, "total": 2, "size": 0, "total_size": 0}
app._show_progress()
ok(app.state == "busy", "Auch waehrend eines Downloads: Sync-Symbol")
app.prog = {"phase": "trash_remote", "start": time.monotonic(), "done": 1, "total": 2}
app._show_progress()
ok(app.state == "scan", "Papierkorb-Aktionen sind kein Upload/Download: kein Sync-Symbol")
app.syncing = False

# --- 17) Benachrichtigung bei Statuswechsel (fertig), aber nicht bei Leerlauf oder Konfliktkopien doppelt
app.notify = MagicMock()
leer = ps.Plan()
app._on_done([("k", "L", leer, None, "quick")], False)
ok(not app.notify.called, "Kein Fund, keine Aenderung: keine Benachrichtigung")
app.notify.reset_mock()
etwas = ps.Plan(); etwas.upload = ["a.txt"]
app._on_done([("k", "L", etwas, None, "full")], False)
ok(app.notify.called and "Fertig" in app.notify.call_args.args[1], f"Erfolgreicher Abgleich mit Aenderungen: Benachrichtigung ({app.notify.call_args})")
app.notify.reset_mock()
mit_kopie = ps.Plan(); mit_kopie.upload = ["a.txt", "a (Konflikt).txt"]; mit_kopie.conflict_copies = ["a (Konflikt).txt"]
app._on_done([("k", "L", mit_kopie, None, "full")], False)
ok(app.notify.call_count == 1 and "Konfliktkopien" in app.notify.call_args.args[1],
   "Bei Konfliktkopien nur diese eine Benachrichtigung, keine doppelte 'Fertig'-Meldung")
app.notify.reset_mock()
app._on_done([("k", "L", etwas, None, "full")], True)  # Trockenlauf
ok(not app.notify.called, "Trockenlauf loest keine 'Fertig'-Benachrichtigung aus")

print(f"\n{len(FAILS)} Fehlschlaege" if FAILS else "\nAlle Tests bestanden.")
sys.exit(1 if FAILS else 0)
