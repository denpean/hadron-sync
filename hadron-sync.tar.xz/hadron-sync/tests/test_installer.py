# Testet install.sh und uninstall.sh gegen einen SIMULIERTEN Proton-Download-Index (keine Internetverbindung noetig).
# Muss als normaler Benutzer laufen (der Installer verweigert root). Arbeitet nur in /tmp/hadron-sync-test/inst.
import hashlib, json, os, shutil, stat, subprocess, sys, time
HERE = os.path.dirname(os.path.abspath(__file__)); PKG = os.path.dirname(HERE)
B = "/tmp/hadron-sync-test/inst"
FAILS = []
def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: FAILS.append(m)
if os.getuid() == 0:
    print("SKIP Installer-Tests brauchen einen normalen Benutzer (nicht root).")
    sys.exit(0)
shutil.rmtree(B, ignore_errors=True)
HOME = f"{B}/home"; os.makedirs(HOME); SRV = f"{B}/srv"

def fake_cli(version, behaviour="ok"):
    body = {"ok": "", "sigill": "kill -ILL $$\n"}[behaviour]
    return f"""#!/bin/sh
{body}case "$1" in
  version) echo "Proton Drive CLI cli-drive@{version}+abc123"; echo "Proton Drive SDK js@0.20.0+abc123" ;;
  filesystem) exit 0 ;;
  auth) echo "auth $2" >> "$HOME/auth.log" ;;
esac
"""

def publish(version, platforms, bad_sha=()):
    """Schreibt Binaries und eine index.html im Stil von Protons Download-Seite."""
    rows = []
    for plat, beh in platforms.items():
        d = f"{SRV}/cli/{version}/{plat}"; os.makedirs(d, exist_ok=True)
        data = fake_cli(version, beh).encode(); open(f"{d}/proton-drive", "wb").write(data)
        sha = hashlib.sha512(data).hexdigest() if plat not in bad_sha else "0" * 128
        url = f"https://proton.me/download/drive/cli/{version}/{plat}/proton-drive"
        rows.append(f'<tr><td>{plat.replace("-", "/", 1)}</td><td><a href="{url}">{url}</a></td><td><code>{sha}</code></td></tr>')
    open(f"{SRV}/index.html", "w").write(
        f"<html><head><title>Proton Drive CLI {version}</title></head><body><h1>Proton Drive CLI {version}</h1>"
        f"<table><tr><th>Platform</th><th>URL</th><th>Checksum (SHA-512)</th></tr>{''.join(rows)}</table></body></html>")

CONTACT = "hadron.unfreeze611@passmail.net"
env = {"HOME": HOME, "PATH": f"{HOME}/.local/bin:/usr/bin:/bin", "LANG": "C.UTF-8",
       "HADRON_SYNC_INDEX_URL": f"file://{SRV}/index.html", "HADRON_SYNC_DOWNLOAD_REWRITE": f"file://{SRV}/cli/"}
def run(args=(), extra=None, script="install.sh"):
    e = dict(env); e.update(extra or {})
    return subprocess.run(["bash", os.path.join(PKG, script), *args], capture_output=True, text=True, env=e, stdin=subprocess.DEVNULL)
INST = ["--no-deps", "--yes", "--no-login", "--no-start"]
CLI = f"{HOME}/.local/bin/proton-drive"; APP = f"{HOME}/.local/share/hadron-sync"
def cli_ver(): return subprocess.run([CLI, "version"], capture_output=True, text=True).stdout.split("@")[1].split("+")[0]
def mode(p): return stat.S_IMODE(os.stat(p).st_mode)

# --- 0) Hinweis muss bestaetigt werden
publish("0.8.0", {"linux-x64": "ok", "linux-x64-baseline": "ok", "linux-arm64": "ok"})
r = run(["--no-deps", "--no-login", "--no-start"])
ok(r.returncode != 0 and "note not accepted" in r.stderr and not os.path.exists(f"{HOME}/.local/share/hadron-sync"),
   "Ohne Bestaetigung des Hinweises keine Installation")
ok("unofficial, private and non-commercial project by Dennis Peteranderl" in r.stdout and "Mistral AI" in r.stdout
   and "own risk" in r.stdout, "Installer zeigt den Hinweis")
r = run(["--no-deps", "--no-login", "--no-start"], {"LANG": "de_DE.UTF-8"})
ok("inoffizielles, privates und nicht-kommerzielles Projekt von Dennis Peteranderl" in r.stdout and "eigenes Risiko" in r.stdout,
   "Hinweis auf Deutsch")
# --- 1) Neuinstallation
r = run(INST)
ok(r.returncode == 0, f"Neuinstallation laeuft ({r.stderr[-300:]})")
ok(os.path.isfile(CLI) and mode(CLI) == 0o755 and cli_ver() == "0.8.0", "CLI 0.8.0 installiert (755)")
ok("Checksum (SHA-512) verified" in r.stdout, "Pruefsumme geprueft")
ok(os.path.isfile(f"{APP}/hadron_sync.py") and os.path.isfile(f"{APP}/uninstall.sh"), "Werkzeug installiert")
ok(os.access(f"{HOME}/.local/bin/hadron-sync", os.X_OK), "Startbefehl hadron-sync angelegt")
v = subprocess.run([f"{HOME}/.local/bin/hadron-sync", "--version"], capture_output=True, text=True, env=env).stdout.strip()
ok(v.startswith("Hadron Sync ") and v.endswith(")"), f"hadron-sync --version: {v}")
ok(os.path.isfile(f"{APP}/messages.sh"), "Sprachdatei mitinstalliert")
desk = open(f"{HOME}/.local/share/applications/local.hadronsync.App.desktop").read()
ok(f"{APP}/hadron_sync.py" in desk, "Menueeintrag zeigt auf installierte Version")
cfg = json.load(open(f"{HOME}/.config/hadron-sync/config.json"))
ok(cfg["cli"] == CLI and mode(f"{HOME}/.config/hadron-sync/config.json") == 0o600, "CLI-Pfad in Konfiguration (600)")
ok(os.path.isfile(f"{HOME}/.config/autostart/hadron-sync.desktop"), "--yes schaltet Autostart ein")
# --- 2) Erneut ausfuehren: gleiche Version -> kein Download
t0 = os.stat(CLI).st_mtime; time.sleep(1.1)
r = run(INST)
ok(r.returncode == 0 and "is up to date" in r.stdout and os.stat(CLI).st_mtime == t0, "Gleiche Version: kein erneuter Download")
# --- 3) Neue Version -> Aktualisierung, Einstellungen bleiben
cfg["pairs"] = [{"local": "/tmp/x", "remote": "/my-files/X"}]; cfg["language"] = "fr"
open(f"{HOME}/.config/hadron-sync/config.json", "w").write(json.dumps(cfg))
publish("0.9.0", {"linux-x64": "ok", "linux-x64-baseline": "ok"})
r = run(INST)
ok(r.returncode == 0 and cli_ver() == "0.9.0" and "Updating Proton Drive CLI 0.8.0 → 0.9.0" in r.stdout, "Aktualisierung 0.8.0 → 0.9.0")
c2 = json.load(open(f"{HOME}/.config/hadron-sync/config.json"))
ok(c2["pairs"] == cfg["pairs"] and c2["language"] == "fr", "Ordnerpaare und Sprache bleiben erhalten")
# --- 4) Falsche Pruefsumme -> Abbruch, alte CLI bleibt
publish("0.9.1", {"linux-x64": "ok"}, bad_sha={"linux-x64"})
r = run(INST)
ok(r.returncode != 0 and "Checksum mismatch" in r.stderr and cli_ver() == "0.9.0", "Falsche Pruefsumme: Abbruch, alte CLI bleibt")
# --- 5) CPU ohne AVX2 (Illegal instruction) -> Baseline
publish("0.9.2", {"linux-x64": "sigill", "linux-x64-baseline": "ok"})
r = run(INST)
ok(r.returncode == 0 and cli_ver() == "0.9.2" and "baseline" in r.stderr, "Illegal instruction → Baseline-Version")
# --- 6) Plattform fehlt im Index
r = run(INST, {"HADRON_SYNC_PLATFORM": "linux-arm64"})
ok(r.returncode != 0 and "No Proton Drive CLI for linux-arm64" in r.stderr, "Fehlende Plattform wird sauber gemeldet")
# --- 7) Nur HTTPS
r = run(INST, {"HADRON_SYNC_INDEX_URL": "http://proton.me/download/drive/cli/index.html"})
ok(r.returncode != 0 and "Only HTTPS" in r.stderr, "HTTP wird abgelehnt")
# --- 8) Laufende Instanz wird beendet, alter Autostart-Pfad ersetzt
open(f"{HOME}/.config/autostart/hadron-sync.desktop", "w").write("[Desktop Entry]\nExec=python3 /alter/pfad/hadron_sync.py --background\n")
dummy = subprocess.Popen(["bash", "-c", "exec -a hadron_sync.py sleep 60"])
time.sleep(0.3)
r = run(INST, {"LANG": "de_DE.UTF-8"})
time.sleep(0.2)
ok(dummy.poll() is not None, "Laufende Instanz wird vor dem Update beendet")
auto = open(f"{HOME}/.config/autostart/hadron-sync.desktop").read()
ok(f"{APP}/hadron_sync.py" in auto and "/alter/pfad" not in auto, "Autostart zeigt auf neuen Pfad")
ok("ist aktuell" in r.stdout and "Fertig." in r.stdout, "Deutsche Meldungen bei deutscher Systemsprache")
dummy.kill() if dummy.poll() is None else None
# --- 9) --skip-cli und --no-autostart
r = run(["--no-deps", "--yes", "--no-login", "--no-start", "--skip-cli", "--no-autostart"])
ok(r.returncode == 0 and not os.path.exists(f"{HOME}/.config/autostart/hadron-sync.desktop") and cli_ver() == "0.9.2", "--skip-cli / --no-autostart")
# --- 10) Anmeldung: Test-CLI meldet "angemeldet"
r = run(["--no-deps", "--yes", "--no-start", "--skip-cli"])
ok(r.returncode == 0 and "Signed in to Proton" in r.stdout, "Anmeldestatus wird erkannt")
# --- 11) Deinstallation: Einstellungen bleiben standardmaessig
sync_file = f"{HOME}/Sync/wichtig.txt"; os.makedirs(os.path.dirname(sync_file)); open(sync_file, "w").write("x")
r = run(["--yes"], script="uninstall.sh")
ok(r.returncode == 0 and not os.path.exists(APP) and not os.path.exists(f"{HOME}/.local/bin/hadron-sync")
   and not os.path.exists(f"{HOME}/.local/share/applications/local.hadronsync.App.desktop"), "Deinstallation entfernt Programm")
ok(os.path.exists(f"{HOME}/.config/hadron-sync/config.json") and os.path.exists(CLI) and os.path.exists(sync_file), "Einstellungen, CLI und Dateien bleiben")
icons = os.listdir(f"{HOME}/.local/share/icons/hicolor/scalable/apps")
ok(not any(i.startswith(("hadron-sync", "proton-sync")) for i in icons), "Symbole entfernt")
# --- 12) Neu installieren, dann komplett entfernen
run(INST)
r = run(["--yes", "--purge", "--remove-cli", "--logout"], script="uninstall.sh")
ok(r.returncode == 0 and not os.path.exists(f"{HOME}/.config/hadron-sync") and not os.path.exists(CLI), "--purge / --remove-cli")
ok("auth logout" in open(f"{HOME}/auth.log").read(), "--logout meldet ab")
ok(os.path.exists(sync_file), "Synchronisierte Dateien bleiben immer erhalten")


# --- Sprachen des Installers und der Deinstallation
print("--- Sprachen ---")
proben = {
    "de_DE.UTF-8": ("Hadron Sync – Installation", "Prüfsumme (SHA-512) bestätigt.", "Fertig.", "eigenes Risiko"),
    "en_US.UTF-8": ("Hadron Sync – installation", "Checksum (SHA-512) verified.", "Done.", "own risk"),
    "es_ES.UTF-8": ("Hadron Sync – instalación", "Suma de verificación (SHA-512) confirmada.", "Listo.", "propia responsabilidad"),
    "fr_FR.UTF-8": ("Hadron Sync – installation", "Somme de contrôle (SHA-512) vérifiée.", "Terminé.", "propres risques"),
}
for lang, frags in proben.items():
    publish("1.0.0" if lang == "de_DE.UTF-8" else f"1.0.{list(proben).index(lang)}", {"linux-x64": "ok", "linux-x64-baseline": "ok"})
    r = run(INST + ["--force"], {"LANG": lang})
    fehlt = [f for f in frags if f not in r.stdout]
    ok(r.returncode == 0 and not fehlt, f"Installer auf {lang[:5]} ({fehlt})")
    ok(CONTACT in r.stdout, f"Kontaktadresse in der Ausgabe ({lang[:5]})")
r = run(["--help"], {"LANG": "fr_FR.UTF-8"})
ok("Utilisation : ./install.sh" in r.stdout and "--user" in r.stdout, "Hilfe auf Franzoesisch")
r = run(["--help"], {"LANG": "es_ES.UTF-8"})
ok("Uso: ./install.sh" in r.stdout, "Hilfe auf Spanisch")
r = run(["--nonsens"], {"LANG": "es_ES.UTF-8"})
ok(r.returncode != 0 and "Opción desconocida: --nonsens" in r.stderr, "Fehlermeldung auf Spanisch")
r = run(["--yes"], {"LANG": "fr_FR.UTF-8"}, script="uninstall.sh")
ok(r.returncode == 0 and "Hadron Sync – désinstallation" in r.stdout and CONTACT in r.stdout, "Deinstallation auf Franzoesisch")
r = run(["--yes"], {"LANG": "es_ES.UTF-8"}, script="uninstall.sh")
ok("Hadron Sync – desinstalación" in r.stdout, "Deinstallation auf Spanisch")
# Unbekannte Systemsprache -> Englisch
r = run(["--help"], {"LANG": "it_IT.UTF-8"})
ok("Usage: ./install.sh" in r.stdout, "Unbekannte Sprache -> Englisch")
# Vollstaendigkeit der Sprachdatei
import re as _re
msgs = open(os.path.join(PKG, "messages.sh")).read()
keys = {m.group(1) for m in _re.finditer(r"^M_(\w+)_de=", msgs, _re.M)}
fehlend = []
for k in keys:
    for l in ("en", "es", "fr"):
        if not _re.search(rf"^M_{k}_{l}=", msgs, _re.M): fehlend.append(f"{k}_{l}")
ok(not fehlend and len(keys) > 40, f"{len(keys)} Meldungen in allen vier Sprachen ({fehlend[:3]})")
# Alle im Skript verwendeten Schluessel sind vorhanden
used = set()
for f in ("install.sh", "uninstall.sh"):
    src = "\n".join(l for l in open(os.path.join(PKG, f)).read().splitlines() if not l.lstrip().startswith("#"))
    used |= {m.group(2) for m in _re.finditer(r"(?:^|[;&|{(]\s*)(die|warn|info|say|ask) ([a-z][a-z0-9_]*)", src, _re.M)}
used -= {"usage"}
unbekannt = sorted(u for u in used if u not in keys)
ok(not unbekannt, f"Alle verwendeten Meldungen sind hinterlegt ({unbekannt})")
# Platzhalter stimmen ueberein
schief = []
for k in keys:
    zahl = {l: len(_re.findall(r"%s", _re.search(rf'^M_{k}_{l}="(.*?)"$', msgs, _re.M | _re.S).group(1))) for l in ("de", "en", "es", "fr")}
    if len(set(zahl.values())) > 1: schief.append((k, zahl))
ok(not schief, f"Platzhalter in allen Sprachen gleich ({schief[:2]})")

print(f"\n{len(FAILS)} Fehlschlaege" if FAILS else "\nAlle Tests bestanden.")
sys.exit(1 if FAILS else 0)
