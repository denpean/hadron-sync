# Aenderungsprotokoll: eigene Datei pro Geraet, Lesezeichen statt Abhaken, immer im Proton-Stammverzeichnis,
# automatisches Neuanlegen, Aufbewahrung 7 Tage, gezielter Abgleich ohne Volleinlesen, Vorrang vor laufendem Sync.
import json, os, shutil, sys, time
from pathlib import Path
MODDIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = "/tmp/hadron-sync-test/changelog"
shutil.rmtree(B, ignore_errors=True)
os.makedirs(f"{B}/remote/my-files/Team/Sub")
sys.path.insert(0, MODDIR)
import hadron_sync as ps
ps.set_language("de")
FAILS = []
def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: FAILS.append(m)

CLI = "/tmp/hadron-sync-test/fakebin/proton-drive"
REMOTE_FS = f"{B}/remote/my-files/.hadron-sync"  # Ordner der Test-CLI fuer /my-files/.hadron-sync
os.environ.update(FAKE_REMOTE=f"{B}/remote", FAKE_TRASH=f"{B}/trash")
os.environ["PATH"] = "/tmp/hadron-sync-test/fakebin:" + os.environ["PATH"]

def use_device(name):
    """Simuliert ein eigenstaendiges Geraet: eigener Einstellungs-/Zustandsordner."""
    base = Path(f"{B}/{name}")
    ps.CONFIG_DIR = base / "cfg"
    ps.CONFIG_FILE = ps.CONFIG_DIR / "config.json"
    ps.STATS_FILE = ps.CONFIG_DIR / "stats.json"
    ps.CHANGELOG_FILE = ps.CONFIG_DIR / "changelog.json"
    ps.STATE_DIR = base / "state"
    ps.LOG_FILE = ps.STATE_DIR / "sync.log"
    os.makedirs(base / "local", exist_ok=True)
    return str(base / "local")

def cfg_for(local):
    return {"local": local, "remote": "/my-files/Team/Sub", "cli": CLI, "excludes": ps.DEFAULT_EXCLUDES}

def w(p, t, ts=None):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "w").write(t)
    if ts:
        os.utime(p, (ts, ts))

# --- 1) CancelToken/Priority: eigenstaendige Ausnahme, nicht mit Cancelled/SyncError verwechselbar
tok = ps.CancelToken(); tok.check()  # nichts passiert
ok(issubclass(ps.Priority, Exception) and not issubclass(ps.Priority, ps.Cancelled)
   and not issubclass(ps.Priority, ps.SyncError), "Priority ist eine eigenstaendige Ausnahme")
tok.request_priority()
try:
    tok.check(); ok(False, "haette ausloesen muessen")
except ps.Priority:
    ok(True, "CancelToken loest Priority nach request_priority() aus")
tok2 = ps.CancelToken(); tok2.set()
try:
    tok2.check(); ok(False, "x")
except ps.Cancelled:
    ok(True, "echtes Abbrechen funktioniert weiterhin unabhaengig davon")

# --- 2) Geraet A: erster Abgleich, veroeffentlicht sein Protokoll
LA = use_device("A")
w(f"{LA}/erste.txt", "Inhalt 1")
p = ps.run_sync(cfg_for(LA), [].append, ps.CancelToken(), confirm=lambda m: True)
ok(p.errors == 0, "Geraet A: Erstabgleich ohne Fehler")
did_a = ps.device_id()
ok(bool(did_a) and did_a == ps.load_config()["device_id"], f"Geraet A hat eine dauerhafte Kennung: {did_a}")
ps.publish_own_log(ps.Cli(CLI), print)
ok(os.path.isdir(REMOTE_FS), "Ordner /my-files/.hadron-sync wurde angelegt")
ok(os.path.isfile(f"{REMOTE_FS}/{did_a}.jsonl"), "Geraet A hat seine eigene Protokolldatei hochgeladen")
zeilen = [json.loads(l) for l in open(f"{REMOTE_FS}/{did_a}.jsonl") if l.strip()]
ok(len(zeilen) == 1 and zeilen[0]["remote"] == "/my-files/Team/Sub/erste.txt" and zeilen[0]["action"] == "upload",
   f"Eintrag zeigt den vollen Proton-Pfad: {zeilen}")

# --- 3) Immer im Stammverzeichnis, auch wenn das Ordnerpaar einen Unterordner synchronisiert
ok(ps.CHANGELOG_ROOT == "/my-files/.hadron-sync", f"Konstante zeigt aufs Stammverzeichnis: {ps.CHANGELOG_ROOT}")
ok(not os.path.exists(f"{B}/remote/my-files/Team/Sub/.hadron-sync")
   and not os.path.exists(f"{B}/remote/my-files/Team/.hadron-sync"),
   "Kein Änderungsprotokoll-Ordner im synchronisierten Unterordner selbst")

# --- 4) Geraet B: nach Neuinstallation zuerst der normale Abgleich, danach erst das Protokoll
LB = use_device("B")
p = ps.run_sync(cfg_for(LB), [].append, ps.CancelToken(), confirm=lambda m: True)
ok(p.errors == 0 and open(f"{LB}/erste.txt").read() == "Inhalt 1", "Geraet B holt die Datei per normalem Erstabgleich")
did_b = ps.device_id()
ok(did_b != did_a, f"Geraet B hat eine andere Kennung ({did_b} != {did_a})")
# A hat "erste.txt" schon veroeffentlicht; B kennt die Datei zwar schon (per Erstabgleich), sieht sie aber
# moeglicherweise trotzdem als Ziel (das Lesezeichen ist noch leer) - das ist harmlos: der gezielte Abgleich
# stellt fest, dass sich nichts geaendert hat, und tut nichts.
ziel = ps.check_changelog(ps.Cli(CLI), {"team": cfg_for(LB)}, ps.parse_excludes(ps.DEFAULT_EXCLUDES), ps.CancelToken(), print)
plan0 = ps.run_targeted_sync(cfg_for(LB), ziel.get("team", set()), print, ps.CancelToken(), confirm=lambda m: True)
ok(plan0.total() == 0, "Bereits bekannte Datei ueber das Protokoll: gezielter Abgleich aendert nichts")

# --- 5) Geraet A laedt eine zweite Datei hoch; Geraet B findet sie ueber das Protokoll (ohne Volleinlesen)
use_device("A")
w(f"{LA}/zweite.txt", "Inhalt 2")
p = ps.run_sync(cfg_for(LA), [].append, ps.CancelToken(), confirm=lambda m: True)
ps.publish_own_log(ps.Cli(CLI), print)

use_device("B")
scans = []
orig_scan = ps.scan_remote
ps.scan_remote = lambda *a, **k: (scans.append(1), orig_scan(*a, **k))[1]
ziel = ps.check_changelog(ps.Cli(CLI), {"team": cfg_for(LB)}, ps.parse_excludes(ps.DEFAULT_EXCLUDES), ps.CancelToken(), print)
ok("team" in ziel and "zweite.txt" in ziel["team"], f"Geraet B findet die neue Datei ueber das Protokoll: {ziel}")
plan = ps.run_targeted_sync(cfg_for(LB), ziel["team"], print, ps.CancelToken(), confirm=lambda m: True)
ps.scan_remote = orig_scan
ok(scans == [], "Der gezielte Abgleich liest den Ordnerbaum nicht komplett neu ein (kein Volleinlesen)")
ok(open(f"{LB}/zweite.txt").read() == "Inhalt 2", "Datei ist bei Geraet B angekommen")
ok(not plan.errors, "Gezielter Abgleich ohne Fehler")

# --- 6) Kein erneuter Download derselben Protokolldatei, solange sie sich nicht geaendert hat
downloads = []
cli_b = ps.Cli(CLI)
orig_run = cli_b.run
def spy(*a, **k):
    if a[:2] == ("filesystem", "download") and any(f"{did_a}.jsonl" in x for x in a):
        downloads.append(a)
    return orig_run(*a, **k)
cli_b.run = spy
ziel2 = ps.check_changelog(cli_b, {"team": cfg_for(LB)}, ps.parse_excludes(ps.DEFAULT_EXCLUDES), ps.CancelToken(), print)
ok(ziel2 == {} and downloads == [], "Unveraenderte fremde Protokolldatei wird kein zweites Mal heruntergeladen")

# --- 7) Aufbewahrung: Eintraege aelter als 7 Tage werden entfernt
use_device("A")
cache = ps.load_changelog_cache()
alt = (ps.datetime.now(ps.timezone.utc) - ps.timedelta(days=9)).isoformat(timespec="seconds")
cache["entries"] = [{"t": alt, "remote": "/my-files/Team/Sub/uralt.txt", "action": "upload"}]
ps.save_changelog_cache(cache)
neu_plan = ps.Plan(); neu_plan.upload = ["dritte.txt"]
ps.record_changes("/my-files/Team/Sub", neu_plan)
entries = ps.load_changelog_cache()["entries"]
ok(all(e["remote"] != "/my-files/Team/Sub/uralt.txt" for e in entries), "Alter Eintrag (9 Tage) wurde entfernt")
ok(any(e["remote"] == "/my-files/Team/Sub/dritte.txt" for e in entries), "Neuer Eintrag bleibt erhalten")
ok(ps.CHANGELOG_TTL_DAYS == 7, "Aufbewahrung ist auf 7 Tage eingestellt")

# --- 8) Geloeschter Ordner wird automatisch neu angelegt
shutil.rmtree(REMOTE_FS)
ok(not os.path.exists(REMOTE_FS), "Ordner testweise geloescht")
ps.publish_own_log(ps.Cli(CLI), print)
ok(os.path.isdir(REMOTE_FS) and os.path.isfile(f"{REMOTE_FS}/{did_a}.jsonl"),
   "Ordner und eigene Datei wurden automatisch neu angelegt")

# --- 9) Ungueltige/gefaehrliche Pfade aus dem Protokoll werden nicht ausgefuehrt
use_device("B")
plan = ps.run_targeted_sync(cfg_for(LB), {"..", "../../ausserhalb.txt", ""}, print, ps.CancelToken(), confirm=lambda m: True)
ok(plan.total() == 0, "Unzulaessige Zielpfade werden verworfen, nicht ausgefuehrt")
ok(not os.path.exists(f"{B}/ausserhalb.txt"), "Kein Schreiben ausserhalb des Ordners")

# --- 10) Gezielter Abgleich behandelt einen echten beidseitigen Konflikt korrekt (wie der normale Abgleich)
use_device("A")
w(f"{LA}/streit.txt", "Basis", time.time() - 1000)
ps.run_sync(cfg_for(LA), [].append, ps.CancelToken(), confirm=lambda m: True)
use_device("B")
ps.run_sync(cfg_for(LB), [].append, ps.CancelToken(), confirm=lambda m: True)  # B hat denselben Basisstand
w(f"{LB}/streit.txt", "Lokal auf B geaendert", time.time() + 100)
w(f"{B}/remote/my-files/Team/Sub/streit.txt", "Remote geaendert", None); os.utime(f"{B}/remote/my-files/Team/Sub/streit.txt", (time.time() + 200,) * 2)
plan = ps.run_targeted_sync(cfg_for(LB), {"streit.txt"}, print, ps.CancelToken(), confirm=lambda m: True)
ok(len(plan.conflict_copies) == 1, f"Gezielter Abgleich erkennt den Konflikt und behaelt beide Versionen: {plan.conflict_copies}")

print(f"\n{len(FAILS)} Fehlschlaege" if FAILS else "\nAlle Tests bestanden.")
sys.exit(1 if FAILS else 0)
