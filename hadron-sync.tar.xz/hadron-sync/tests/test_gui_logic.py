# Automatische Tests gegen eine SIMULIERTE proton-drive CLI.
# Arbeitet ausschliesslich in /tmp/hadron-sync-test - dein echter Ordner, dein Home und Proton Drive bleiben unberuehrt.
import os as _os, sys as _sys
MODDIR = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
import os, sys, time, shutil, threading
from unittest.mock import MagicMock
for d in ("/tmp/hadron-sync-test/home","/tmp/hadron-sync-test/remote","/tmp/hadron-sync-test/local","/tmp/hadron-sync-test/cfg","/tmp/hadron-sync-test/state","/tmp/hadron-sync-test/trash"): shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/hadron-sync-test/home"); os.makedirs("/tmp/hadron-sync-test/remote/my-files"); os.makedirs("/tmp/hadron-sync-test/local")
os.environ.update(HOME="/tmp/hadron-sync-test/home", FAKE_REMOTE="/tmp/hadron-sync-test/remote", FAKE_TRASH="/tmp/hadron-sync-test/trash",
                  XDG_CONFIG_HOME="/tmp/hadron-sync-test/cfg", XDG_STATE_HOME="/tmp/hadron-sync-test/state")
os.environ.pop("FAKE_LOG", None)
os.environ["PATH"]="/tmp/hadron-sync-test/fakebin:"+os.environ["PATH"]
sys.path.insert(0, MODDIR)
import hadron_sync as ps
ps.set_language("de")

class FakeGLib:
    timers={}; n=0; idles=0
    @classmethod
    def idle_add(cls, fn, *a): cls.idles+=1; fn(*a); return 1
    @classmethod
    def timeout_add_seconds(cls, s, fn, *a): cls.n+=1; cls.timers[cls.n]=(s,fn); return cls.n
    @classmethod
    def source_remove(cls, i): cls.timers.pop(i, None)
class FakeEvent: CHANGES_DONE_HINT="done"; CREATED="created"; DELETED="deleted"; ATTRIBUTE_CHANGED="attr"; CHANGED="changed"
class FakeMonitor:
    def __init__(s,p): s.p=p; s.cancelled=False
    def connect(s,*a): pass
    def cancel(s): s.cancelled=True
class FakeFile:
    def __init__(s,p): s.p=p
    def monitor_directory(s,flags,c): return FakeMonitor(s.p)
    def get_basename(s): return os.path.basename(s.p)
    def get_path(s): return s.p
class FakeGio:
    FileMonitorEvent=FakeEvent; FileMonitorFlags=MagicMock(); ApplicationFlags=MagicMock(); Notification=MagicMock(); ThemedIcon=MagicMock()
    class File:
        @staticmethod
        def new_for_path(p): return FakeFile(p)
ps.Gtk=MagicMock(); ps.Gio=FakeGio; ps.GLib=FakeGLib; ps.AppIndicator=MagicMock()
FAILS=[]
def ok(c,m):
    print(("PASS " if c else "FAIL ")+m)
    if not c: FAILS.append(m)


idir=ps.Path("/tmp/hadron-sync-test/home/.local/share/icons/hicolor/scalable/apps"); idir.mkdir(parents=True)
(idir/f"{ps.ICON_ERROR}.svg").write_text("<svg>MEIN EIGENES ICON</svg>")   # vom Benutzer ersetzt
adir=ps.Path("/tmp/hadron-sync-test/home/.local/share/applications"); adir.mkdir(parents=True, exist_ok=True)

L="/tmp/hadron-sync-test/local"
os.makedirs(f"{L}/sub"); open(f"{L}/a.txt","w").write("A"); open(f"{L}/sub/b.txt","w").write("B")
cfgd=dict(pairs=[{"local":L, "remote":"/my-files/GuiTest"}], cli="/tmp/hadron-sync-test/fakebin/proton-drive", excludes=ps.DEFAULT_EXCLUDES, realtime=True, interval=15, autostart=False, language="de")
ps.save_config(cfgd)
app=ps.SyncApp(background=True)
app.confirm=lambda m: True     # Dialog nicht testbar
app.log_buf.get_line_count.return_value=0
ok(app.cfg["pairs"][0]["local"]==L and app.cfg["realtime"] is True, "Konfiguration geladen")
K=ps.pair_key(app.cfg["pairs"][0])

app.on_startup(None)
ind=app.indicator
ok(ps.Path(f"/tmp/hadron-sync-test/home/.local/share/icons/hicolor/scalable/apps/{ps.ICON_BUSY}.svg").exists(), "Icons installiert")
ok(all(ps.Path(f"/tmp/hadron-sync-test/home/.local/share/icons/hicolor/scalable/apps/{n}.svg").read_text().startswith("<svg") for n in ps.ICONS), "Alle 4 Icon-Dateien vorhanden")
dt=ps.Path(f"/tmp/hadron-sync-test/home/.local/share/applications/{ps.APP_ID}.desktop").read_text()
ok("Exec=" in dt and "hadron_sync.py" in dt and f"Icon={ps.ICON_APP}" in dt, "Menue-Eintrag geschrieben")
ok(f"StartupWMClass={ps.APP_ID}" in dt and (adir/f"{ps.APP_ID}.desktop").exists(), "Desktop-Datei heisst wie die App-ID")
ok(ps.ICON_MARKER in (idir/f"{ps.ICON_APP}.svg").read_text(), "App-Icon angelegt")
ok(ps.ICON_MARKER in (idir/f"{ps.ICON_IDLE}.svg").read_text(), "Tray-Icon angelegt")
ok((idir/f"{ps.ICON_ERROR}.svg").read_text()=="<svg>MEIN EIGENES ICON</svg>", "Eigenes Icon bleibt unangetastet")
ok(ps.ICON_MARKER in (idir/f"{ps.ICON_BUSY}.svg").read_text(), "Fehlende Icons werden neu angelegt")
ok(app.tray_ok and ind.set_menu.called, "Tray + Menue aufgebaut")
ok(set(app.monitors)=={L, f"{L}/sub"}, f"Ordner werden ueberwacht: {sorted(app.monitors)}")
ok({15*60,5,ps.CHANGELOG_POLL_S,10}.issubset({s for s,_ in FakeGLib.timers.values()}), f"Timer: Intervall, Start-Sync und Änderungsprotokoll-Takt gesetzt ({sorted({s for s,_ in FakeGLib.timers.values()})})")

# on_activate im Hintergrund -> kein Fenster
app.show_window=MagicMock(); app.on_activate(None); ok(not app.show_window.called, "Hintergrundstart zeigt kein Fenster")
app.on_activate(None); ok(app.show_window.called, "Zweiter Aufruf zeigt Fenster")

def wait():
    for _ in range(300):
        if not app.syncing: return
        time.sleep(0.05)
    raise RuntimeError("timeout")
# Start-Sync ausloesen (Timer manuell feuern)
start=[fn for s,fn in FakeGLib.timers.values() if s==5][0]; start(); wait()
icons=[c.args[0] for c in ind.set_icon_full.call_args_list]
ok(icons[0]==ps.ICON_SCAN and ps.ICON_BUSY in icons and icons[-1]==ps.ICON_IDLE, f"Icon-Wechsel scan -> busy -> idle: {icons}")
ok(app.last_ok is not None and app.state=="idle", "Status nach Sync: idle + Zeit gesetzt")
ok(os.path.exists("/tmp/hadron-sync-test/remote/my-files/GuiTest/sub/b.txt"), "Erster Sync hat hochgeladen")

# Dateisystem-Ereignis -> Debounce-Timer -> Quick-Sync
open(f"{L}/neu.txt","w").write("N")
n_before=len(FakeGLib.timers)
app.on_fs_event(None, FakeFile(f"{L}/neu.txt"), None, FakeEvent.CHANGES_DONE_HINT, K)
deb=[(s,fn) for s,fn in FakeGLib.timers.values() if s==ps.DEBOUNCE_S]
ok(len(deb)==1, "Ereignis startet Debounce-Timer")
app.on_fs_event(None, FakeFile(f"{L}/neu.txt"), None, FakeEvent.CHANGES_DONE_HINT, K)
ok(len([1 for s,_ in FakeGLib.timers.values() if s==ps.DEBOUNCE_S])==1, "Weiteres Ereignis setzt Timer zurueck (kein Doppel)")
app.on_fs_event(None, FakeFile(f"{L}/.DS_Store"), None, FakeEvent.CHANGES_DONE_HINT, K)
ok(len([1 for s,_ in FakeGLib.timers.values() if s==ps.DEBOUNCE_S])==1, "Ausgeschlossene Datei ignoriert")
[fn for s,fn in FakeGLib.timers.values() if s==ps.DEBOUNCE_S][0](); wait()
ok(os.path.exists("/tmp/hadron-sync-test/remote/my-files/GuiTest/neu.txt"), "Debounce -> Quick-Sync laedt hoch")

# neuer Unterordner -> neuer Monitor
os.makedirs(f"{L}/frisch/tief"); app.on_fs_event(None, FakeFile(f"{L}/frisch"), None, FakeEvent.CREATED, K)
ok(f"{L}/frisch" in app.monitors and f"{L}/frisch/tief" in app.monitors, "Neue Ordner werden ueberwacht")
# geloeschter Ordner -> Monitor weg
shutil.rmtree(f"{L}/frisch"); app.on_fs_event(None, FakeFile(f"{L}/frisch"), None, FakeEvent.DELETED, K)
ok(f"{L}/frisch" not in app.monitors and f"{L}/frisch/tief" not in app.monitors, "Geloeschte Ordner: Monitore entfernt")

# pending: Ereignisse waehrend eines Syncs
app.syncing=True; app.request_sync("quick",[K]); app.request_sync("full"); app.request_sync("quick",[K])
ok(app.jobs=={K:"full"}, "Waehrend Sync: 'full' hat Vorrang in der Warteschlange")
app.syncing=False; app.jobs.clear()

# Fehlerpfad + Benachrichtigung
app.cfg["cli"]="/nicht/vorhanden"; FakeGio.Notification.reset_mock()
app.request_sync("full"); wait()
ok(app.state=="error" and "nicht gefunden" in app.state_detail, f"Fehlerstatus: {app.state_detail}")
ok(ind.set_icon_full.call_args.args[0]==ps.ICON_ERROR, "Fehler-Icon gesetzt")
ok(FakeGio.Notification.new.called, "Benachrichtigung bei Fehler")
n=FakeGio.Notification.new.call_count; app.request_sync("full"); wait()
ok(FakeGio.Notification.new.call_count==n, "Keine Wiederholung derselben Fehlermeldung")
app.cfg["cli"]="/tmp/hadron-sync-test/fakebin/proton-drive"; app.request_sync("full"); wait()
ok(app.state=="idle", "Erholung: Status wieder idle")

# Sperre: anderer Prozess synct -> kein Fehler-Icon, neuer Versuch in 60 s
lk=ps.FolderLock(ps.state_path(L, "/my-files/GuiTest")); lk.__enter__()
FakeGio.Notification.reset_mock(); ind.set_icon_full.reset_mock()
app.request_sync("full"); wait()
ok(app.state=="idle" and ind.set_icon_full.call_args.args[0]==ps.ICON_IDLE, "Sperre: Status bleibt idle")
ok(not FakeGio.Notification.new.called, "Sperre: keine Fehlermeldung")
ok(any(s==60 for s,_ in FakeGLib.timers.values()), "Sperre: Wiederholung in 60 s geplant")
lk.__exit__(None,None,None)
# Konfliktkopie -> Benachrichtigung mit Dateiname
open(f"{L}/k.txt","w").write("x"); app.request_sync("full"); wait()
R2="/tmp/hadron-sync-test/remote/my-files/GuiTest"
open(f"{L}/k.txt","w").write("lokal"); os.utime(f"{L}/k.txt",(time.time()+100,)*2)
open(f"{R2}/k.txt","w").write("remote!"); os.utime(f"{R2}/k.txt",(time.time()+200,)*2)
FakeGio.Notification.reset_mock(); app.request_sync("full"); wait()
title_calls=[c.args[0] for c in FakeGio.Notification.new.call_args_list]
ok(app.state=="idle" and title_calls==["Hadron Sync"], f"Konflikt: Benachrichtigung ({title_calls})")
# ================= Mehrere Ordnerpaare =================
L2="/tmp/hadron-sync-test/local2"; R2b="/tmp/hadron-sync-test/remote/my-files/Zweites/Ziel"
os.makedirs(f"{L2}/x", exist_ok=True); open(f"{L2}/x/z.txt","w").write("Z")
p1={"local":L, "remote":"/my-files/GuiTest"}; p2={"local":L2, "remote":"/my-files/Zweites/Ziel"}
K2=ps.pair_key(p2)
app.cfg["pairs"]=[p1,p2]; ps.save_config(app.cfg); app.apply_config()
ok({k for _,k in app.monitors.values()}=={K,K2} and app.monitors[f"{L2}/x"][1]==K2, "Monitore sind dem richtigen Paar zugeordnet")
FakeGLib.timers.clear(); app.request_sync("full"); wait()
ok(open(f"{R2b}/x/z.txt").read()=="Z", "Zweites Paar: Zielordner angelegt und synchronisiert")
ok(app.state=="idle" and not app.pair_errors, "Beide Paare ohne Fehler")
# Aenderung nur in Paar 2 -> nur Paar 2 laeuft
open(f"{L2}/x/neu2.txt","w").write("N2"); open(f"{L}/nur-lokal1.txt","w").write("A")
app.on_fs_event(None, FakeFile(f"{L2}/x/neu2.txt"), None, FakeEvent.CHANGES_DONE_HINT, K2)
[fn for s,fn in list(FakeGLib.timers.values()) if s==ps.DEBOUNCE_S][0](); wait()
ok(os.path.exists(f"{R2b}/x/neu2.txt") and not os.path.exists(f"{R2}/nur-lokal1.txt"), "Ereignis in Paar 2 synchronisiert nur Paar 2")
# Fehler in einem Paar blockiert das andere nicht
shutil.rmtree(L2); FakeGio.Notification.reset_mock()
app.request_sync("full"); wait()
ok(os.path.exists(f"{R2}/nur-lokal1.txt"), "Paar 1 laeuft trotz Fehler in Paar 2")
ok(app.state=="error" and list(app.pair_errors)==[K2] and "local2" in app.state_detail, f"Fehler Paar 2 angezeigt: {app.state_detail}")
ok(FakeGio.Notification.new.call_count==1, "Genau eine Fehlermeldung")
# Quick-Erfolg in Paar 1 loescht den Fehler von Paar 2 NICHT
app.request_sync("quick",[K]); wait()
ok(app.state=="error" and K2 in app.pair_errors, "Fehler von Paar 2 bleibt bis zur Behebung sichtbar")
os.makedirs(L2); app.request_sync("full"); wait()
ok(app.state=="idle" and not app.pair_errors, "Nach Behebung wieder idle")
# Paar entfernen -> Fehler/Jobs/Monitore dieses Paars weg
app.cfg["pairs"]=[p1]; app.pair_errors[K2]="x"; app.jobs[K2]="full"; app.apply_config()
ok(K2 not in app.pair_errors and K2 not in app.jobs and all(k==K for _,k in app.monitors.values()), "Entferntes Paar raeumt auf")
# Warteschlange: Auftraege fuer mehrere Paare
app.cfg["pairs"]=[p1,p2]; app.syncing=True
app.request_sync("quick",[K2]); app.request_sync("quick",[K])
ok(app.jobs=={K2:"quick",K:"quick"}, "Mehrere Paare in der Warteschlange")
app.syncing=False; app.jobs.clear()

# ================= Pruefung der Paare =================
os.makedirs(f"{L}/unter", exist_ok=True)
def bad(pairs, frag):
    try: ps.validate_pairs(pairs); return False
    except ps.SyncError as e: return frag in str(e)
ok(bad([p1,{"local":f"{L}/unter","remote":"/my-files/Anders"}], "Lokale Ordner"), "Verschachtelte lokale Ordner abgelehnt")
ok(bad([p1,{"local":L2,"remote":"/my-files/GuiTest/Sub"}], "Proton-Ordner"), "Verschachtelte Proton-Ordner abgelehnt")
ok(bad([p1,{"local":L2,"remote":"/my-files/GuiTest/"}], "Proton-Ordner"), "Gleicher Proton-Ordner abgelehnt")
ok(bad([{"local":L2,"remote":"/my-files"},p1], "Proton-Ordner"), "Stammverzeichnis + Unterordner abgelehnt")
ok(bad([p1,{"local":L,"remote":"/my-files/X"}], "Lokale Ordner"), "Gleicher lokaler Ordner abgelehnt")
ok(bad([], "kein Ordnerpaar"), "Leere Liste abgelehnt")
ok(bad([{"local":L,"remote":"/andere"}], "/my-files"), "Proton-Pfad ausserhalb /my-files abgelehnt")
try: ps.validate_pairs([p1,p2,{"local":f"{L2}x","remote":"/my-files/GuiTest2"}]); ok(True,"Aehnliche, aber nicht verschachtelte Namen erlaubt")
except ps.SyncError as e:
    os.makedirs(f"{L2}x",exist_ok=True)
    try: ps.validate_pairs([p1,p2,{"local":f"{L2}x","remote":"/my-files/GuiTest2"}]); ok(True,"Aehnliche, aber nicht verschachtelte Namen erlaubt")
    except ps.SyncError as e2: ok(False, f"Aehnliche Namen: {e2}")

# ================= Konfiguration =================
import json as _json
ps.CONFIG_FILE.write_text(_json.dumps({"local":L,"remote":"/my-files/GuiTest","interval":-5,"realtime":False}))
c=ps.load_config()
ok(c["pairs"]==[{"local":L,"remote":"/my-files/GuiTest"}] and "local" not in c, "Alte Einzelordner-Konfiguration uebernommen")
ok(ps.pair_key(c["pairs"][0])==K, "Uebernommenes Paar behaelt seinen Sync-Stand")
ok(c["interval"]==15 and c["realtime"] is False, "Ungueltiges Intervall -> Standard")
ps.CONFIG_FILE.write_text(_json.dumps({"pairs":[{"local":L,"remote":"/my-files/GuiTest/"},{"remote":"/my-files/ohne-lokal"},"muell"],"interval":"abc"}))
c=ps.load_config(); ok(c["pairs"]==[{"local":L,"remote":"/my-files/GuiTest"}] and c["interval"]==15, "Kaputte Eintraege werden ignoriert")
ps.CONFIG_FILE.write_text("[1,2,3]"); ok(ps.load_config()["pairs"]==[], "Unbrauchbare Konfigurationsdatei -> leer")

# ================= Headless: alle gespeicherten Paare =================
import subprocess as _sp
ps.save_config(dict(ps.load_config(), pairs=[p1,p2], cli="/tmp/hadron-sync-test/fakebin/proton-drive"))
open(f"{L2}/headless.txt","w").write("H"); open(f"{L}/headless1.txt","w").write("H1")
r=_sp.run([sys.executable, os.path.join(MODDIR,"hadron_sync.py"), "--headless", "--yes"], capture_output=True, text=True, env=os.environ)
ok(r.returncode==0 and os.path.exists(f"{R2b}/headless.txt") and os.path.exists(f"{R2}/headless1.txt"), f"Headless synchronisiert alle Paare (rc={r.returncode})")
ok(r.stdout.count("── ")==2, "Headless zeigt beide Paare an")

# Autostart
ps.set_autostart(True); f=ps.Path("/tmp/hadron-sync-test/home/.config/autostart/hadron-sync.desktop")
ok(f.exists() and "--background" in f.read_text() and "X-GNOME-Autostart-Delay" in f.read_text(), "Autostart-Datei mit --background + Verzoegerung")
ps.set_autostart(False); ok(not f.exists(), "Autostart entfernt")
# GTK-Programmname (Taskleisten-Zuordnung)
import types
fake_gi=types.ModuleType("gi"); calls=[]
fake_gi.require_version=lambda *a: calls.append(("req",a))
fake_repo=types.ModuleType("gi.repository")
class _G:
    @staticmethod
    def set_prgname(n): calls.append(("prg",n))
    @staticmethod
    def set_application_name(n): calls.append(("name",n))
fake_repo.GLib=_G; fake_repo.Gio=MagicMock(); fake_repo.Gtk=MagicMock(); fake_repo.Pango=MagicMock(); fake_repo.Gdk=MagicMock()
sys.modules.update({"gi":fake_gi,"gi.repository":fake_repo})
saved=(ps.Gtk,ps.Gio,ps.GLib,ps.AppIndicator)
ps.gui_imports()
order=[c[0]+(":"+c[1][0] if c[0]=="req" else "") for c in calls]
ok(("prg",ps.APP_ID) in calls and order.index("prg")<order.index("req:Gtk"), f"set_prgname vor Gtk-Import: {order[:3]}")
ps.Gtk,ps.Gio,ps.GLib,ps.AppIndicator=saved
# Beenden
app.quit(); ok(app.quitting and app.gapp.quit.called and not app.monitors, "Beenden raeumt auf")


# ================= Eigenstaendiger Block: Ordnerueberwachung robuster =================
# (CHANGES_DONE_HINT ist laut GIO nicht garantiert; und eine erschoepfte inotify-Grenze soll nicht
# die gesamte Ueberwachung abschalten.) Frischer App-Zustand, unabhaengig vom obigen Ablauf.
B2 = "/tmp/hadron-sync-test/watch2"
shutil.rmtree(B2, ignore_errors=True)
L3 = f"{B2}/local"; os.makedirs(L3)
os.environ.update(FAKE_REMOTE=f"{B2}/remote", FAKE_TRASH=f"{B2}/trash")
os.makedirs(f"{B2}/remote/my-files")
ps.save_config({"pairs": [{"local": L3, "remote": "/my-files/W"}], "cli": "/tmp/hadron-sync-test/fakebin/proton-drive",
               "realtime": True, "language": "de"})
FakeGLib.timers.clear()
app2 = ps.SyncApp(background=True); app2.log_buf.get_line_count.return_value = 0
app2.build_tray()
app2.on_startup(None)
app2.confirm = lambda m: True
K3 = ps.pair_key(app2.cfg["pairs"][0])

# Reine Inhaltsaenderung ohne Umbenennen: CHANGED allein muss die Ruhezeit anstossen.
open(f"{L3}/ueberschrieben.txt", "w").write("x")
app2.on_fs_event(None, FakeFile(f"{L3}/ueberschrieben.txt"), None, FakeEvent.CHANGED, K3)
ok(len([1 for s, _ in FakeGLib.timers.values() if s == ps.DEBOUNCE_S]) == 1,
   "Reines CHANGED-Ereignis (ohne CHANGES_DONE_HINT) loest die Ruhezeit ebenfalls aus")
[fn for s, fn in FakeGLib.timers.values() if s == ps.DEBOUNCE_S][0]()
for _ in range(100):
    if not app2.syncing: break
    time.sleep(0.05)
ok(os.path.exists(f"{B2}/remote/my-files/W/ueberschrieben.txt"), "Per CHANGED erkannte Aenderung wird hochgeladen")

# inotify-Grenze erreicht: bereits eingerichtete Ueberwachungen bleiben erhalten, eine Meldung, kein Totalausfall.
os.makedirs(f"{L3}/a"); os.makedirs(f"{L3}/b"); os.makedirs(f"{L3}/c")
app2.monitors.clear()
calls = {"n": 0}
def flaky(path):
    calls["n"] += 1
    obj = MagicMock()
    if calls["n"] <= 2:
        obj.monitor_directory.return_value = MagicMock()
    else:
        obj.monitor_directory.side_effect = RuntimeError("no more file watches")
    return obj
ps.Gio.File.new_for_path = flaky
app2.log = MagicMock()
app2.start_monitors()
ok(len(app2.monitors) == 2, f"Bereits erfolgreiche Ueberwachungen bleiben erhalten, kein Totalausfall ({len(app2.monitors)})")
meldungen = [c.args[0] for c in app2.log.call_args_list]
ok(sum("inotify" in m for m in meldungen) == 1, f"Genau eine Meldung ueber die inotify-Grenze, kein Sturm ({meldungen})")
ok(any("Überwache 2 Ordner" in m for m in meldungen), f"Zeigt zusaetzlich, wie viele Ordner trotzdem ueberwacht werden ({meldungen})")
# Wird die Grenze gar nicht erreicht, bleibt die bisherige Erfolgsmeldung erhalten.
app2.monitors.clear(); app2.log = MagicMock()
ps.Gio.File.new_for_path = lambda path: (lambda o: (setattr(o.monitor_directory.return_value, "x", 1), o)[1])(MagicMock())
app2.start_monitors()
ok(any("Überwache" in c.args[0] for c in app2.log.call_args_list), "Ohne Grenzverletzung weiterhin die normale Erfolgsmeldung")

# ================= Eigenstaendiger Block: Ueberwachung nicht unnoetig neu aufbauen =================
# Bei vielen tausend Ordnern (real gemeldet: ~2900) blockierte apply_config() bisher spuerbar die
# Oberflaeche, weil JEDE Einstellungsaenderung die komplette Ordnerueberwachung neu aufbaute.
B3 = "/tmp/hadron-sync-test/watch3"
shutil.rmtree(B3, ignore_errors=True)
L4 = f"{B3}/local"; os.makedirs(L4)
os.environ.update(FAKE_REMOTE=f"{B3}/remote", FAKE_TRASH=f"{B3}/trash")
os.makedirs(f"{B3}/remote/my-files")
ps.save_config({"pairs": [{"local": L4, "remote": "/my-files/V"}], "cli": "/tmp/hadron-sync-test/fakebin/proton-drive",
               "realtime": True, "language": "de", "excludes": ps.DEFAULT_EXCLUDES})
app3 = ps.SyncApp(background=True); app3.log_buf.get_line_count.return_value = 0
app3.build_tray()
real_start = app3.start_monitors
calls = {"n": 0}
def counting():
    calls["n"] += 1
    return real_start()
app3.start_monitors = counting
app3.on_startup(None); app3.confirm = lambda m: True
ok(calls["n"] == 1, f"Beim Start genau einmal aufgebaut ({calls['n']})")

# Einstellung speichern, die die Ueberwachung NICHT betrifft (z. B. Vorschaubilder) -> kein Neuaufbau
app3.apply_settings(dict(app3.cfg, thumbnails=False), ask_restart=False)
ok(calls["n"] == 1, f"Unwesentliche Einstellungsaenderung baut die Ueberwachung nicht neu auf ({calls['n']})")
app3.apply_settings(dict(app3.cfg, interval=360, parallel=2, autostart=True), ask_restart=False)
ok(calls["n"] == 1, f"Auch mehrere unwesentliche Aenderungen zusammen loesen keinen Neuaufbau aus ({calls['n']})")

# Aenderung, die die Ueberwachung wirklich betrifft (Ausschluesse) -> Neuaufbau ist noetig und richtig
app3.apply_settings(dict(app3.cfg, excludes="*.tmp, *.bak"), ask_restart=False)
ok(calls["n"] == 2, f"Geaenderte Ausschluesse loesen zu Recht einen Neuaufbau aus ({calls['n']})")

# Realtime aus und wieder an -> jeweils genau ein Wechsel, kein doppelter Aufbau
app3.apply_settings(dict(app3.cfg, realtime=False), ask_restart=False)
ok(not app3.monitors, "Sofort-Sync ausgeschaltet: keine Ueberwachung mehr aktiv")
app3.apply_settings(dict(app3.cfg, realtime=True), ask_restart=False)
ok(calls["n"] == 3 and app3.monitors, f"Sofort-Sync wieder eingeschaltet: Ueberwachung erneut aufgebaut ({calls['n']})")

# Neues Ordnerpaar hinzugefuegt -> auch das ist ueberwachungsrelevant
L5 = f"{B3}/local2"; os.makedirs(L5)
app3.apply_settings(dict(app3.cfg, pairs=app3.cfg["pairs"] + [{"local": L5, "remote": "/my-files/V2"}]), ask_restart=False)
ok(calls["n"] == 4, f"Neues Ordnerpaar loest einen Neuaufbau aus ({calls['n']})")

# Waehrend eines langen Aufbaus bleibt die Oberflaeche ansprechbar (Events werden zwischendurch verarbeitet)
app3.start_monitors = real_start
for i in range(120):
    os.makedirs(f"{L4}/ordner{i}")
gepumpt = {"n": 0}
ps.Gtk.events_pending = MagicMock(return_value=True)
orig_iter = ps.Gtk.main_iteration_do
def counting_iter(block):
    gepumpt["n"] += 1
    ps.Gtk.events_pending.return_value = False   # nur einmal pumpen, sonst haengt die Attrappe endlos
ps.Gtk.main_iteration_do = counting_iter
app3.start_monitors()
ps.Gtk.main_iteration_do = orig_iter
ok(gepumpt["n"] > 0, "Bei vielen Ordnern werden zwischendurch anstehende Oberflaechen-Ereignisse verarbeitet")

print(f"\n{len(FAILS)} Fehlschlaege" if FAILS else "\nAlle Tests bestanden.")
sys.exit(1 if FAILS else 0)
