# Tests der Sicherheitsmassnahmen: Namenspruefung, Pfadpruefung, Dateirechte, geschwaerzte Logs, Einrichtung.
import json, os, shutil, stat, subprocess, sys, time
MODDIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = "/tmp/hadron-sync-test/sec"
shutil.rmtree(B, ignore_errors=True)
os.environ.update(HOME=f"{B}/home", XDG_CONFIG_HOME=f"{B}/cfg", XDG_STATE_HOME=f"{B}/state",
                  FAKE_REMOTE=f"{B}/remote", FAKE_TRASH=f"{B}/trash")
os.environ["PATH"] = "/tmp/hadron-sync-test/fakebin:" + os.environ["PATH"]
for d in ("home", "remote/my-files/S", "local"):
    os.makedirs(f"{B}/{d}")
os.umask(0o022)
sys.path.insert(0, MODDIR)
import hadron_sync as ps
ps.set_language("de")
FAILS = []
def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: FAILS.append(m)
def mode(p): return stat.S_IMODE(os.stat(p).st_mode)
L, R = f"{B}/local", f"{B}/remote/my-files/S"
cfg = {"local": L, "remote": "/my-files/S", "cli": "/tmp/hadron-sync-test/fakebin/proton-drive", "excludes": ps.DEFAULT_EXCLUDES}
now = time.time()
def w(p, t, ts=now - 500):
    os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(t); os.utime(p, (ts, ts))
logs = []
def sync(**kw):
    logs.clear(); return ps.run_sync(cfg, logs.append, ps.CancelToken(), confirm=lambda m: True, **kw)

# --- 1) Manipulierte Remote-Namen
w(f"{L}/normal.txt", "N"); w(f"{R}/r.txt", "R")
os.environ["FAKE_EXTRA_AT"] = "/my-files/S"
os.environ["FAKE_EXTRA"] = json.dumps([
    {"name": {"ok": True, "value": ".."}, "type": "folder"},
    {"name": {"ok": True, "value": "."}, "type": "folder"},
    {"name": {"ok": True, "value": ".."}, "type": "file", "activeRevision": {"claimedModificationTime": "2020-01-01T00:00:00Z", "claimedSize": 1}},
    {"name": {"ok": True, "value": "../../ausbruch.txt"}, "type": "file", "activeRevision": {"claimedModificationTime": "2020-01-01T00:00:00Z", "claimedSize": 1}},
])
p = sync()
ok(p.errors == 0 and os.path.exists(f"{L}/r.txt") and os.path.exists(f"{R}/normal.txt"), "Normale Dateien trotz manipulierter Eintraege synchronisiert")
ok(not os.path.exists(f"{B}/ausbruch.txt") and not os.path.exists(f"{B}/remote/ausbruch.txt"), "Kein Schreiben ausserhalb des Ordners")
ok(sum("unzulässiger Name" in l for l in logs) == 3 and any("Sonderzeichen" in l for l in logs), "Manipulierte Namen werden gemeldet")
ok(not any(".." in x for x in os.listdir(L)), "Keine '..'-Eintraege lokal angelegt")
os.environ.pop("FAKE_EXTRA"); os.environ.pop("FAKE_EXTRA_AT")
# --- 2) Ordner mit fuehrendem '-' (wuerde als CLI-Option gelesen) - symmetrisch uebersprungen
calls = f"{B}/calls.log"; os.environ["FAKE_LOG"] = calls
w(f"{L}/-lokal/a.txt", "A"); w(f"{R}/-remote/b.txt", "B"); w(f"{L}/-datei.txt", "D")
p = sync()
cf = [l for l in open(calls) if "create-folder" in l]
ok(not any(" -lokal" in l for l in cf), "Kein create-folder mit '-Name'")
ok(not os.path.exists(f"{R}/-lokal") and not os.path.exists(f"{L}/-remote"), "'-'-Ordner werden auf beiden Seiten ignoriert")
ok(os.path.exists(f"{R}/-datei.txt"), "Dateien mit fuehrendem '-' funktionieren (absolute Pfade)")
p = sync()
ok(p.total() == 0 and os.path.exists(f"{R}/-remote/b.txt") and os.path.exists(f"{L}/-lokal/a.txt"), "Nichts wird geloescht, Zustand stabil")
os.environ.pop("FAKE_LOG")
# --- 3) Proton-Pfad-Pruefung
for bad in ("/my-files/../x", "/my-files/a/../../b", "/my-files/./a", "/my-files/a//b", "/my-files/-x", "/my-files/a/--help"):
    try:
        ps._validate(dict(cfg, remote=bad)); ok(False, f"Abgelehnt: {bad}")
    except ps.SyncError as e:
        ok("Ungültiger Proton-Pfad" in str(e), f"Abgelehnt: {bad}")
for good in ("/my-files", "/my-files/", "/my-files/a b/c-d", "/my-files/.versteckt", "/my-files/a..b"):
    try:
        ps._validate(dict(cfg, remote=good)); ok(True, f"Erlaubt: {good}")
    except ps.SyncError as e:
        ok(False, f"Erlaubt: {good} ({e})")
# --- 4) Dateirechte
ps.save_config({"pairs": [], "language": "de"})
ok(mode(ps.CONFIG_DIR) == 0o700 and mode(ps.CONFIG_FILE) == 0o600, f"Konfiguration 700/600 ({oct(mode(ps.CONFIG_DIR))}/{oct(mode(ps.CONFIG_FILE))})")
states = [f for f in ps.CONFIG_DIR.iterdir() if f.name.startswith("state-") and f.suffix == ".json"]
ok(states and all(mode(f) == 0o600 for f in states), "Zustandsdateien 600")
locks = [f for f in ps.CONFIG_DIR.iterdir() if f.suffix == ".lock"]
ok(locks and all(mode(f) == 0o600 for f in locks), "Sperrdateien 600")
ps.file_log("Test")
ok(mode(ps.STATE_DIR) == 0o700 and mode(ps.LOG_FILE) == 0o600, "Log-Ordner 700, Log-Datei 600")
sy = ps.Syncer(ps.Cli(cfg["cli"]), L, "/my-files/S", print, ps.CancelToken())
seen = {}
_orig_run = ps.Cli.run
def spy(self, *args, **kw):
    if args[:2] == ("filesystem", "download"):
        seen["root"] = mode(sy.tmp_root()); seen["sub"] = mode(args[-1])
    return _orig_run(self, *args, **kw)
ps.Cli.run = spy
w(f"{R}/neu-fuer-tmp.txt", "T"); sync()
ps.Cli.run = _orig_run
ok(seen.get("root") == 0o700 and seen.get("sub") == 0o700, f"Zwischenordner beim Download 700 ({seen})")
# Rechte aus frueheren Versionen korrigieren
os.chmod(ps.CONFIG_DIR, 0o755); os.chmod(ps.CONFIG_FILE, 0o644); os.chmod(ps.LOG_FILE, 0o644)
ps.secure_existing()
ok(mode(ps.CONFIG_DIR) == 0o700 and mode(ps.CONFIG_FILE) == 0o600 and mode(ps.LOG_FILE) == 0o600, "Alte Rechte werden korrigiert")
ok(not any(f.name.endswith(".tmp") for f in ps.CONFIG_DIR.iterdir()), "Keine Temp-Reste beim Schreiben")
# --- 5) Login-Links nicht im Log
url = "https://account.proton.me/desktop/login?app=drive&pv=3#payload=0%3AGEHEIM%3Acli-drive"
ps.file_log("Open following URL manually: " + url)
content = open(ps.LOG_FILE, encoding="utf-8").read()
ok("GEHEIM" not in content and "payload" not in content and "Open following URL manually" in content, "Login-Link wird im Log geschwaerzt")
ok(ps.redact("Datei https://example.com/bild.png") == "Datei https://example.com/bild.png", "Normale Adressen bleiben")
# --- 6) Einrichtung ueber --setup und --version
env = dict(os.environ)
r = subprocess.run([sys.executable, os.path.join(MODDIR, "hadron_sync.py"), "--setup", "--cli", "/opt/pd/proton-drive", "--autostart", "on"],
                   capture_output=True, text=True, env=env)
home = f"{B}/home"
ok(r.returncode == 0, f"--setup laeuft ({r.stderr[-200:]})")
ok(os.path.exists(f"{home}/.local/share/applications/{ps.APP_ID}.desktop"), "Menueeintrag angelegt")
ok(os.path.exists(f"{home}/.local/share/icons/hicolor/scalable/apps/{ps.ICON_IDLE}.svg"), "Symbole angelegt")
ok(os.path.exists(f"{home}/.config/autostart/hadron-sync.desktop"), "Autostart eingeschaltet")
c = json.load(open(ps.CONFIG_FILE))
ok(c["cli"] == "/opt/pd/proton-drive" and c["autostart"] is True, "CLI-Pfad und Autostart gespeichert")
r = subprocess.run([sys.executable, os.path.join(MODDIR, "hadron_sync.py"), "--setup", "--autostart", "off"], capture_output=True, text=True, env=env)
ok(r.returncode == 0 and not os.path.exists(f"{home}/.config/autostart/hadron-sync.desktop") and json.load(open(ps.CONFIG_FILE))["cli"] == "/opt/pd/proton-drive",
   "Autostart aus, CLI-Pfad bleibt")
r = subprocess.run([sys.executable, os.path.join(MODDIR, "hadron_sync.py"), "--version"], capture_output=True, text=True, env=env)
ok(r.stdout.strip() == f"Hadron Sync {ps.APP_VERSION} ({ps.APP_DATE})", f"--version: {r.stdout.strip()}")

print(f"\n{len(FAILS)} Fehlschlaege" if FAILS else "\nAlle Tests bestanden.")
sys.exit(1 if FAILS else 0)
