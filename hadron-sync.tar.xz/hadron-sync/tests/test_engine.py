# Automatische Tests gegen eine SIMULIERTE proton-drive CLI.
# Arbeitet ausschliesslich in /tmp/hadron-sync-test - dein echter Ordner, dein Home und Proton Drive bleiben unberuehrt.
import os as _os, sys as _sys
MODDIR = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
import os, sys, shutil, time, tempfile
sys.path.insert(0, MODDIR)
os.environ["FAKE_REMOTE"]="/tmp/hadron-sync-test/remote"; os.environ["FAKE_TRASH"]="/tmp/hadron-sync-test/trash"
os.environ["PATH"]="/tmp/hadron-sync-test/fakebin:"+os.environ["PATH"]
os.environ["XDG_CONFIG_HOME"]="/tmp/hadron-sync-test/cfg"; os.environ["XDG_STATE_HOME"]="/tmp/hadron-sync-test/state"
import importlib, hadron_sync as ps
ps.set_language("de")
for d in ("/tmp/hadron-sync-test/remote","/tmp/hadron-sync-test/trash","/tmp/hadron-sync-test/cfg","/tmp/hadron-sync-test/local"): shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/hadron-sync-test/remote/my-files"); os.makedirs("/tmp/hadron-sync-test/local")
L="/tmp/hadron-sync-test/local"; R="/tmp/hadron-sync-test/remote/my-files/Sync"
def w(path, txt, t):
    os.makedirs(os.path.dirname(path), exist_ok=True); open(path,"w").write(txt); os.utime(path,(t,t))
def rd(path): return open(path).read() if os.path.exists(path) else None
now=time.time()
cfg={"local":L,"remote":"/my-files/Sync","cli":"/tmp/hadron-sync-test/fakebin/proton-drive","excludes":ps.DEFAULT_EXCLUDES}
logs=[]
def sync(dry=False, **kw):
    logs.clear(); p=ps.run_sync(cfg, logs.append, ps.CancelToken(), dry_run=dry, confirm=kw.get("confirm", lambda m: True)); return p
def show(): print("\n".join(l for l in logs if l.startswith(("Plan","Fertig","  FEHLER","Erste"))))
FAILS=[]
def ok(c,m):
    print(("PASS " if c else "FAIL ")+m)
    if not c: FAILS.append(m)

# 1 Erstsync, beide Seiten haben Dateien
w(f"{L}/a.txt","A",now-1000); w(f"{L}/sub/b.txt","B",now-1000)
os.makedirs(R); w(f"{R}/c.txt","C",now-1000); w(f"{R}/sub2/d.txt","D",now-1000)
p=sync(dry=True); ok(p.upload==["a.txt","sub/b.txt"] and p.download==["c.txt","sub2/d.txt"], "Trockenlauf-Plan Erstsync")
ok(not os.path.exists(f"{L}/c.txt"), "Trockenlauf aendert nichts")
p=sync(); show()
ok(all(rd(x) for x in (f"{L}/c.txt",f"{L}/sub2/d.txt",f"{R}/a.txt",f"{R}/sub/b.txt")), "Erstsync: alles auf beiden Seiten")
ok(abs(os.stat(f"{L}/c.txt").st_mtime-(now-1000))<1, "Download setzt Originalzeit")
# 2 kein Aenderung
p=sync(); ok(p.total()==0, "Zweiter Lauf: keine Aktionen")
# 3 Aenderungen beidseitig auf verschiedenen Dateien
w(f"{L}/a.txt","A2",now-500); w(f"{R}/c.txt","C22",now-400)
p=sync(); show(); ok(p.upload==["a.txt"] and p.download==["c.txt"], "Upload/Download nach Aenderung")
ok(rd(f"{R}/a.txt")=="A2" and rd(f"{L}/c.txt")=="C22", "Inhalt korrekt")
ok(any("c.txt" in f for f in os.listdir("/tmp/hadron-sync-test/trash")), "Alte lokale Version im Papierkorb")
p=sync(); ok(p.total()==0, "Danach stabil")
# 4 Loeschungen
os.remove(f"{L}/sub/b.txt"); os.remove(f"{R}/sub2/d.txt")
p=sync(); show(); ok(p.trash_remote==["sub/b.txt"] and p.trash_local==["sub2/d.txt"], "Loeschungen erkannt")
ok(not os.path.exists(f"{R}/sub/b.txt") and not os.path.exists(f"{L}/sub2/d.txt"), "Loeschungen ausgefuehrt")
ok(all(os.path.isdir(x) for x in (f"{R}/sub",f"{L}/sub",f"{R}/sub2",f"{L}/sub2")), "Nur Datei geloescht: leere Ordner bleiben auf beiden Seiten (korrekt)")
p=sync(); ok(p.total()==0, "Danach stabil")
# 5 beidseitig geaendert -> neuer gewinnt
w(f"{L}/a.txt","lokal",now-100); w(f"{R}/a.txt","remote",now-50)
p=sync(); ok("a.txt" in p.download and rd(f"{L}/a.txt")=="remote" and rd(f"{R}/a.txt")=="remote", "Beidseitig: remote neuer behaelt den Namen")
kc=p.conflict_copies; ok(len(kc)==1 and kc[0].startswith("a (Konflikt ") and kc[0].endswith(".txt") and rd(f"{L}/{kc[0]}")=="lokal" and rd(f"{R}/{kc[0]}")=="lokal", f"Lokale Version als Konfliktkopie: {kc}")
p=sync(); ok(p.total()==0, "Nach Konflikt stabil")
w(f"{L}/a.txt","lokal2",now-10); w(f"{R}/a.txt","remote2",now-60)
p=sync(); ok("a.txt" in p.upload and rd(f"{R}/a.txt")=="lokal2" and rd(f"{L}/a.txt")=="lokal2", "Beidseitig: lokal neuer behaelt den Namen")
kc=[c for c in p.conflict_copies]; ok(len(kc)==1 and rd(f"{L}/{kc[0]}")=="remote2" and rd(f"{R}/{kc[0]}")=="remote2", f"Remote-Version als Konfliktkopie auf beiden Seiten: {kc}")
ok(abs(os.stat(f"{L}/{kc[0]}").st_mtime-(now-60))<1, "Konfliktkopie behaelt Originalzeit")
p=sync(); ok(p.total()==0, "Nach Konflikt stabil")
# 6 remote geloescht, lokal geaendert -> bleibt/hochladen
os.remove(f"{R}/a.txt"); w(f"{L}/a.txt","lokal3",now-5)
p=sync(); ok(p.upload==["a.txt"] and rd(f"{R}/a.txt")=="lokal3", "Remote geloescht + lokal geaendert -> erhalten")
# 7 Ordner lokal geloescht komplett
w(f"{L}/x/y/z.txt","Z",now-300); sync()
shutil.rmtree(f"{L}/x")
p=sync(); ok(not os.path.exists(f"{R}/x"), "Ganzer Ordner lokal geloescht -> remote entfernt")
# 8 neuer leerer Ordner lokal/remote
os.makedirs(f"{L}/leer"); os.makedirs(f"{R}/leer2")
sync(); ok(os.path.isdir(f"{R}/leer") and os.path.isdir(f"{L}/leer2"), "Leere Ordner werden gespiegelt")
# 9 Upload-Fehler: Datei bleibt ungesynct, kein falscher Zustand
w(f"{L}/bad.txt","x",now-20); os.environ["FAKE_FAIL"]="bad.txt"
p=sync(); show(); ok(not os.path.exists(f"{R}/bad.txt"), "Fehlgeschlagener Upload nicht remote")
os.environ.pop("FAKE_FAIL"); p=sync(); ok(os.path.exists(f"{R}/bad.txt"), "Retry beim naechsten Lauf klappt")
# 10 Massenloeschschutz
for i in range(15): w(f"{L}/m/f{i}.txt",str(i),now-200)
sync(); shutil.rmtree(f"{L}/m")
try: sync(confirm=lambda m: False); ok(False,"Guard")
except ps.SyncError as e: ok("nicht bestätigt" in str(e) and os.path.exists(f"{R}/m/f0.txt"), "Massenloeschung ohne Bestaetigung blockiert")
p=sync(confirm=lambda m: True); ok(not os.path.exists(f"{R}/m"), "Mit Bestaetigung ausgefuehrt")
# 11 Erstlauf mit neuem, nicht existierendem Remote-Ziel
cfg2=dict(cfg, remote="/my-files/Neu/Ziel"); logs.clear()
ps.run_sync(cfg2, logs.append, ps.CancelToken(), confirm=lambda m: True); ok(os.path.isfile("/tmp/hadron-sync-test/remote/my-files/Neu/Ziel/a.txt"), "Remote-Ziel wird angelegt + befuellt")
# 12 gleicher Inhalt, andere Zeit -> keine Uebertragung
w(f"{L}/same.txt","gleich",now-999); w(f"{R}/same.txt","gleich",now-111)
p=sync(); ok(p.total()==0, "Gleicher Inhalt/andere Zeit: keine Uebertragung")

print("\n=== Schnellabgleich / Rueckfragen ===")
import shutil as _sh
calls="/tmp/hadron-sync-test/calls.log"; os.environ["FAKE_LOG"]=calls
def ncalls(kind):
    return sum(1 for l in open(calls) if l.startswith(kind)) if os.path.exists(calls) else 0
def reset(): open(calls,"w").close()
def qsync(**kw):
    logs.clear(); return ps.run_sync(cfg, logs.append, ps.CancelToken(), mode="quick", confirm=kw.get("confirm", lambda m: True))
sync()   # sauberer Ausgangsstand
# 13 Quick ohne Aenderung: keine Aktion, keine Log-Zeilen, kein CLI-Aufruf
reset(); p=qsync(); ok(p.total()==0 and not logs and ncalls("filesystem")==0, "Quick ohne Aenderung: still, kein CLI-Aufruf")
# 14 Quick: neue Datei in neuem verschachtelten Ordner
w(f"{L}/q1/q2/new.txt","N",now-5); reset(); p=qsync()
ok(rd(f"{R}/q1/q2/new.txt")=="N", "Quick: Datei + Ordnerkette hochgeladen")
ok(ncalls("filesystem list")<=2, f"Quick: kein Volllisting ({ncalls('filesystem list')} list-Aufrufe)")
p=sync(); ok(p.total()==0, "Danach Vollabgleich: stabil")
# 15 Quick: lokale Loeschung -> Papierkorb
os.remove(f"{L}/q1/q2/new.txt"); p=qsync()
ok(p.trash_remote==["q1/q2/new.txt"] and not os.path.exists(f"{R}/q1/q2/new.txt"), "Quick: lokale Loeschung remote in Papierkorb")
p=sync(); ok(p.total()==0, "Danach Vollabgleich: stabil")
# 16 Quick fasst Remote-Aenderungen nicht an; Vollabgleich holt sie
w(f"{R}/a.txt","remote-neu",now+50)
p=qsync(); ok(p.total()==0 and rd(f"{L}/a.txt")!="remote-neu", "Quick ignoriert Remote-Aenderung")
p=sync(); ok(rd(f"{L}/a.txt")=="remote-neu", "Vollabgleich holt Remote-Aenderung")
# 17 Quick + lokale Aenderung an anderer Datei, Remote-Datei bleibt unberuehrt
w(f"{L}/same.txt","lokal-neu",now+60); w(f"{R}/a.txt","remote-neuer",now+70)
p=qsync(); ok(rd(f"{R}/same.txt")=="lokal-neu" and rd(f"{R}/a.txt")=="remote-neuer", "Quick: nur lokale Datei hochgeladen")
p=sync(); ok(rd(f"{L}/a.txt")=="remote-neuer" and p.errors==0, "Vollabgleich danach sauber")
# 18 Quick-Upload-Fehler bleibt sichtbar und wird wiederholt
w(f"{L}/bad2.txt","x",now+80); os.environ["FAKE_FAIL"]="bad2.txt"
p=qsync(); ok(p.errors==1 and any("FEHLER" in l for l in logs), "Quick: Fehler gemeldet")
os.environ.pop("FAKE_FAIL"); p=qsync(); ok(rd(f"{R}/bad2.txt")=="x" and p.errors==0, "Quick: Wiederholung klappt")
# 19 Quick: Ordner existiert remote schon (unbekannt) -> kein Fehler
os.makedirs(f"{R}/vorhanden"); os.makedirs(f"{L}/vorhanden"); w(f"{L}/vorhanden/f.txt","F",now+90)
p=qsync(); ok(p.errors==0 and rd(f"{R}/vorhanden/f.txt")=="F", "Quick: bereits vorhandener Remote-Ordner ok")
# 20 Erster Abgleich verlangt Bestaetigung
for d in ("/tmp/hadron-sync-test/remote","/tmp/hadron-sync-test/local","/tmp/hadron-sync-test/cfg","/tmp/hadron-sync-test/state"): _sh.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/hadron-sync-test/remote/my-files/Sync"); os.makedirs(L)
w(f"{R}/r1.txt","R1",now-100); w(f"{L}/l1.txt","L1",now-100)
msgs=[]
try: sync(confirm=lambda m: (msgs.append(m), False)[1]); ok(False,"kein Abbruch")
except ps.SyncError as e: ok("nicht bestätigt" in str(e) and not os.path.exists(f"{L}/r1.txt") and "1 Dateien" in msgs[0], "Erstlauf: ohne Bestaetigung nichts passiert")
p=sync(confirm=lambda m: True); ok(rd(f"{L}/r1.txt")=="R1" and rd(f"{R}/l1.txt")=="L1", "Erstlauf: mit Bestaetigung gesynct")
# 21 Quick ohne Stand faellt auf Voll zurueck
_sh.rmtree("/tmp/hadron-sync-test/state", ignore_errors=True); _sh.rmtree("/tmp/hadron-sync-test/cfg", ignore_errors=True)
logs.clear(); p=ps.run_sync(cfg, logs.append, ps.CancelToken(), mode="quick", confirm=lambda m: True)
ok(any("vollen Abgleich" in l for l in logs) and p.errors==0, "Quick ohne Stand -> Vollabgleich")
# 22 Speicherplatz-Schutz
_sh.rmtree("/tmp/hadron-sync-test/cfg", ignore_errors=True)
w(f"{R}/gross.txt","x"*1000,now)
class U: free=100
orig=ps.shutil.disk_usage; ps.shutil.disk_usage=lambda p: U()
try: sync(confirm=lambda m: True); ok(False,"Speicherguard")
except ps.SyncError as e: ok("Speicherplatz" in str(e), "Speicherplatz-Schutz greift")
finally: ps.shutil.disk_usage=orig
# 23 Zu breite lokale Ordner werden abgelehnt
for bad in ("/", os.path.expanduser("~")):
    try: ps.run_sync(dict(cfg, local=bad), logs.append, ps.CancelToken()); ok(False,"breit")
    except ps.SyncError as e: ok("zu breit" in str(e), f"Ablehnung von {bad}")


print("\n=== Neue Schutzmechanismen ===")
for d in ("/tmp/hadron-sync-test/remote","/tmp/hadron-sync-test/local","/tmp/hadron-sync-test/cfg","/tmp/hadron-sync-test/state","/tmp/hadron-sync-test/trash"): _sh.rmtree(d, ignore_errors=True)
os.makedirs(f"{R}"); os.makedirs(L)
w(f"{L}/f.txt","basis",now-1000); w(f"{L}/d/g.txt","G",now-1000); sync()
# P1: Quick erkennt Remote-Aenderung derselben Datei und wechselt zum Vollabgleich -> Konfliktkopie statt Ueberschreiben
w(f"{R}/f.txt","remote-geaendert",now-100); w(f"{L}/f.txt","lokal-geaendert",now-50)
p=qsync(); ok(p.full and any("wechsle zum vollen Abgleich" in l for l in logs), "P1: Quick erkennt Remote-Aenderung -> Vollabgleich")
ok(rd(f"{L}/f.txt")=="lokal-geaendert" and rd(f"{R}/f.txt")=="lokal-geaendert" and len(p.conflict_copies)==1 and rd(f"{R}/{p.conflict_copies[0]}")=="remote-geaendert", "P1: Remote-Aenderung bleibt als Konfliktkopie erhalten")
# P1: remote geloescht + lokal geaendert im Quick -> Vollabgleich (Datei bleibt erhalten)
os.remove(f"{R}/d/g.txt"); w(f"{L}/d/g.txt","G2",now-10)
p=qsync(); ok(p.full and rd(f"{R}/d/g.txt")=="G2", "P1: Remote-Loeschung erkannt, lokale Aenderung bleibt")
# P1: bekannter Remote-Ordner geloescht
w(f"{L}/d/h.txt","H",now-5); sync(); _sh.rmtree(f"{R}/d"); w(f"{L}/d/h.txt","H2",now-1)
p=qsync(); ok(p.full, "P1: geloeschter Remote-Ordner -> Vollabgleich")
p=sync(); ok(p.total()==0 and p.errors==0, "Danach stabil")
# P7: abgebrochener Download -> lokale Datei unveraendert, nichts im Papierkorb, kein Rueck-Upload
_sh.rmtree("/tmp/hadron-sync-test/trash", ignore_errors=True)
w(f"{R}/f.txt","remote-neu-lang",now+100)
os.environ["FAKE_PARTIAL"]="f.txt"; p=sync()
ok(p.errors==1 and rd(f"{L}/f.txt")=="lokal-geaendert", "P7: Teil-Download ersetzt lokale Datei nicht")
ok(not os.path.exists("/tmp/hadron-sync-test/trash") or not os.listdir("/tmp/hadron-sync-test/trash"), "P7: lokale Datei nicht im Papierkorb")
ok(not os.path.exists(f"{L}/{ps.TMP_DIR_NAME}"), "P7: Zwischenordner aufgeraeumt")
ok(rd(f"{R}/f.txt")=="remote-neu-lang", "P7: Remote-Datei nicht ueberschrieben")
os.environ.pop("FAKE_PARTIAL"); p=sync()
ok(rd(f"{L}/f.txt")=="remote-neu-lang" and p.errors==0, "P7: naechster Lauf holt Datei korrekt")
ok(any("f.txt" in x for x in os.listdir("/tmp/hadron-sync-test/trash")), "P7: alte lokale Version erst jetzt im Papierkorb")
# P7: Download-Fehler (Netzwerk)
w(f"{R}/f.txt","noch-neuer",now+200); os.environ["FAKE_DLFAIL"]="f.txt"
p=sync(); ok(p.errors==1 and rd(f"{L}/f.txt")=="remote-neu-lang", "P7: Netzwerkfehler laesst lokale Datei intakt")
os.environ.pop("FAKE_DLFAIL"); p=sync(); ok(rd(f"{L}/f.txt")=="noch-neuer", "P7: Wiederholung klappt")
# P7: Reste eines abgestuerzten Laufs werden entfernt und nie hochgeladen
os.makedirs(f"{L}/{ps.TMP_DIR_NAME}/x"); w(f"{L}/{ps.TMP_DIR_NAME}/x/rest.txt","rest",now)
p=sync(); ok(not os.path.exists(f"{L}/{ps.TMP_DIR_NAME}") and not os.path.exists(f"{R}/{ps.TMP_DIR_NAME}"), "P7: Zwischenordner-Reste entfernt, nicht hochgeladen")
# P2: gleicher Zeitstempel, anderer Inhalt -> beide behalten
w(f"{L}/z.txt","eins",now-3000); sync()
w(f"{L}/z.txt","lokal-zzz",now+300); w(f"{R}/z.txt","remote-zz",now+300)
p=sync(); ok(len(p.conflict_copies)==1 and rd(f"{L}/z.txt")=="remote-zz" and rd(f"{L}/{p.conflict_copies[0]}")=="lokal-zzz", "P2: gleicher Zeitstempel -> beide behalten")
# P2: Konflikt ohne Dateiendung / in Unterordner
w(f"{L}/u/Makefile","a",now-3000); sync()
w(f"{L}/u/Makefile","lokal",now+400); w(f"{R}/u/Makefile","remote",now+500)
p=sync(); c=p.conflict_copies[0]; ok(c.startswith("u/Makefile (Konflikt ") and rd(f"{R}/{c}")=="lokal", f"P2: Unterordner/ohne Endung: {c}")
# P2: gleicher Inhalt auf beiden Seiten -> kein Konflikt
w(f"{L}/s.txt","gleich",now-3000); sync(); w(f"{L}/s.txt","neu-gleich",now+10); w(f"{R}/s.txt","neu-gleich",now+20)
p=sync(); ok(not p.conflict_copies and p.total()==0, "P2: identischer Inhalt -> kein Konflikt")
# P6: Sperre
sp=ps.state_path(L,"/my-files/Sync")
with ps.FolderLock(sp):
    try: sync(); ok(False,"lock")
    except ps.Busy: ok(True, "P6: zweiter Sync wird abgewiesen (Busy)")
    p=sync(dry=True); ok(p is not None, "P6: Trockenlauf trotz Sperre moeglich")
p=sync(); ok(p.errors==0, "P6: nach Freigabe wieder moeglich")
import subprocess as _sp
holder=_sp.Popen([sys.executable,"-c",f"import sys,time;sys.path.insert(0,{MODDIR!r});import hadron_sync as ps;l=ps.FolderLock(ps.state_path({L!r},'/my-files/Sync'));l.__enter__();print('ok',flush=True);time.sleep(5)"],stdout=_sp.PIPE,env=os.environ)
holder.stdout.readline()
try: sync(); ok(False,"lock2")
except ps.Busy: ok(True, "P6: Sperre wirkt prozessuebergreifend")
holder.kill(); holder.wait()


print(f"\n{len(FAILS)} Fehlschlaege" if FAILS else "\nAlle Tests bestanden.")
sys.exit(1 if FAILS else 0)
