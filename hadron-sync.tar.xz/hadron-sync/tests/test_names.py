# Dateinamen, die die Proton-CLI beim Herunterladen veraendert (z. B. " -> _).
import os, shutil, sys, time
MODDIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = "/tmp/hadron-sync-test/names"
shutil.rmtree(B, ignore_errors=True)
os.environ.update(HOME=f"{B}/home", XDG_CONFIG_HOME=f"{B}/cfg", XDG_STATE_HOME=f"{B}/state",
                  FAKE_REMOTE=f"{B}/remote", FAKE_TRASH=f"{B}/trash")
os.environ["PATH"] = "/tmp/hadron-sync-test/fakebin:" + os.environ["PATH"]
for d in ("home", "remote/my-files/N", "local"):
    os.makedirs(f"{B}/{d}")
sys.path.insert(0, MODDIR)
import hadron_sync as ps
ps.set_language("de")
FAILS = []
def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: FAILS.append(m)
L, R = f"{B}/local", f"{B}/remote/my-files/N"
cfg = {"local": L, "remote": "/my-files/N", "cli": "/tmp/hadron-sync-test/fakebin/proton-drive", "excludes": ps.DEFAULT_EXCLUDES}
now = time.time()
def w(p, t, ts=now - 500):
    os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(t); os.utime(p, (ts, ts))
logs = []
def sync():
    logs.clear(); return ps.run_sync(cfg, logs.append, ps.CancelToken(), confirm=lambda m: True)

NAME = 'Vortrag - Max "M." Mustermann - Entwurf.pdf'
# --- 1) Remote-Datei mit Anfuehrungszeichen wird korrekt heruntergeladen
w(f"{R}/Charaktere/{NAME}", "PDF-Inhalt")
w(f"{R}/a_b_c.txt", "andere")     # Datei, deren Name schon Unterstriche hat
p = sync()
ok(p.errors == 0, f"Kein Fehler beim Download ({p.errors})")
ok(os.path.isfile(f"{L}/Charaktere/{NAME}"), "Datei liegt lokal unter dem Originalnamen")
ok(open(f"{L}/Charaktere/{NAME}").read() == "PDF-Inhalt", "Inhalt korrekt")
ok(not os.path.exists(f"{L}/Charaktere/" + NAME.replace('"', "_")), "Keine Datei mit ersetzten Zeichen")
ok(any("Name wird zurückgesetzt" in l for l in logs), "Umbenennung wird gemeldet")
# --- 2) Kein Kreislauf: keine Dubletten in Proton Drive
p = sync()
ok(p.total() == 0, "Zweiter Lauf: nichts zu tun")
namen = sorted(os.listdir(f"{R}/Charaktere"))
ok(namen == [NAME], f"Keine Dublette in Proton Drive: {namen}")
p = sync(); ok(p.total() == 0 and sorted(os.listdir(f"{L}/Charaktere")) == [NAME], "Auch dritter Lauf stabil")
# --- 3) Weitere Sonderzeichen
for n, inhalt in (('Frage? Antwort* hier.txt', "x"), ('A:B<C>D|E.txt', "y"), ('ganz normal.txt', "z")):
    w(f"{R}/Sonder/{n}", inhalt)
p = sync()
ok(p.errors == 0 and all(os.path.isfile(f"{L}/Sonder/{n}") for n in ('Frage? Antwort* hier.txt', 'A:B<C>D|E.txt', 'ganz normal.txt')),
   "Weitere Sonderzeichen: Originalnamen wiederhergestellt")
p = sync(); ok(p.total() == 0, "Danach stabil")
# --- 4) Zwei Dateien, die auf denselben bereinigten Namen fuehren
w(f"{R}/Doppelt/a\"b.txt", "eins"); w(f"{R}/Doppelt/a_b.txt", "zwei-laenger")
p = sync()
# Die CLI schreibt beide auf denselben lokalen Namen – eine der beiden kann so nicht ankommen.
# Entscheidend: kein falscher Inhalt unter einem Namen, und der Fehlschlag wird gemeldet.
inhalte = {n: open(f"{L}/Doppelt/{n}").read() for n in os.listdir(f"{L}/Doppelt")}
ok(all(inhalte.get(n, v) == v for n, v in {'a"b.txt': "eins", "a_b.txt": "zwei-laenger"}.items()),
   f"Aehnliche Namen werden nicht verwechselt: {inhalte}")
ok(p.errors == 1 and any("unvollständig heruntergeladen" in l for l in logs), "Nicht angekommene Datei wird gemeldet")
w(f"{R}/Doppelt/a\"b.txt", "eins", now - 400)   # Konflikt aufloesen: einen der beiden Namen aendern
os.rename(f"{R}/Doppelt/a\"b.txt", f"{R}/Doppelt/a-b.txt")
p = sync()
ok(p.errors == 0 and open(f"{L}/Doppelt/a-b.txt").read() == "eins", "Nach Umbenennen in Proton Drive kommt sie an")
# --- 5) Weiterhin echter Fehler, wenn nichts ankommt
w(f"{R}/leer/kaputt.txt", "1234567890")
os.environ["FAKE_DLFAIL"] = "kaputt.txt"
p = sync()
ok(p.errors == 1 and any("unvollständig heruntergeladen" in l or "FEHLER Download" in l for l in logs), "Fehlgeschlagener Download wird weiterhin gemeldet")
os.environ.pop("FAKE_DLFAIL")
p = sync(); ok(p.errors == 0 and os.path.isfile(f"{L}/leer/kaputt.txt"), "Wiederholung klappt")
# --- 6) Hochladen von Namen mit Anfuehrungszeichen
w(f"{L}/Eigene/Mein \"Zitat\" Text.txt", "hoch", now + 10)
p = sync()
ok(p.errors == 0 and os.path.isfile(f'{R}/Eigene/Mein "Zitat" Text.txt'), "Upload mit Anfuehrungszeichen")
p = sync(); ok(p.total() == 0, "Danach stabil")

# --- 7) Namen mit [ ] * ? (die CLI liest sie als Suchmuster)
for n in ("Rechnung_0001[1234567890123456].pdf", "Bericht [Entwurf].txt", "Frage?.txt", "Stern*.txt"):
    w(f"{L}/Klammern/{n}", "inhalt " + n, now + 100)
p = sync()
ok(p.errors == 0, f"Kein Fehler beim Hochladen ({p.errors})")
for n in ("Rechnung_0001[1234567890123456].pdf", "Bericht [Entwurf].txt", "Frage?.txt", "Stern*.txt"):
    ok(os.path.isfile(f"{R}/Klammern/{n}") and open(f"{R}/Klammern/{n}").read() == "inhalt " + n, f"In Proton angekommen: {n}")
ok(not any("No paths matched" in l for l in logs), "Keine „No paths matched“-Meldung mehr")
p = sync(); ok(p.total() == 0, "Danach stabil")
# Aenderung an einer solchen Datei wird uebertragen
w(f"{L}/Klammern/Frage?.txt", "geaendert", now + 200)
p = sync()
ok(p.errors == 0 and open(f"{R}/Klammern/Frage?.txt").read() == "geaendert", "Aenderung wird hochgeladen")

print(f"\n{len(FAILS)} Fehlschlaege" if FAILS else "\nAlle Tests bestanden.")
sys.exit(1 if FAILS else 0)
