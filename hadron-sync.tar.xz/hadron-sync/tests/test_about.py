# Autor, Kontakt, Version und Hinweise.
import json, os, shutil, subprocess, sys
MODDIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = "/tmp/hadron-sync-test/about"
shutil.rmtree(B, ignore_errors=True)
HOME = f"{B}/home"; os.makedirs(HOME)
FAILS = []
def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: FAILS.append(m)
env = {"HOME": HOME, "PATH": "/tmp/hadron-sync-test/fakebin:/usr/bin:/bin", "LANG": "de_DE.UTF-8"}
def run(*args, lang=None):
    e = dict(env)
    if lang: e["LANG"] = lang
    return subprocess.run([sys.executable, os.path.join(MODDIR, "hadron_sync.py"), *args], capture_output=True, text=True, env=e)
os.environ.update(HOME=HOME, XDG_CONFIG_HOME=f"{HOME}/.config", XDG_STATE_HOME=f"{HOME}/.local/state")
sys.path.insert(0, MODDIR)
import hadron_sync as ps
ps.set_language("de")
new_cfg = f"{HOME}/.config/hadron-sync"
os.makedirs(new_cfg, exist_ok=True)
ps.save_config({"pairs": [], "language": "de"})

# --- Autor und Hinweise
r = run("--about")
t = r.stdout
ok("Hadron Sync" in t and "Dennis Peteranderl" in t and ps.APP_DATE in t, "--about nennt Programm, Autor und Datum")
for frag in ("inoffizielles, privates und nicht-kommerzielles Projekt", "Proton AG", "Claude (Anthropic)", "Mistral AI", "eigenes Risiko"):
    ok(frag in t, f"Hinweis enthaelt: {frag}")
for lang, frags in (("en", ("unofficial, private and non-commercial", "Mistral AI", "own risk")),
                    ("es", ("no oficial, privado y sin fines comerciales", "Mistral AI", "propia responsabilidad")),
                    ("fr", ("non officiel, privé et non commercial", "Mistral AI", "propres risques"))):
    c = json.load(open(f"{new_cfg}/config.json")); c["language"] = lang; json.dump(c, open(f"{new_cfg}/config.json", "w"))
    t = run("--about").stdout
    ok(all(f in t for f in frags) and "Dennis Peteranderl" in t, f"Hinweis auf {lang}")
c["language"] = "de"; json.dump(c, open(f"{new_cfg}/config.json", "w"))
h = run("--help").stdout
ok("Dennis Peteranderl" in h and "eigenes Risiko" in h, "--help zeigt Autor und Hinweis")
ok(run("--version").stdout.strip() == f"Hadron Sync {ps.APP_VERSION} ({ps.APP_DATE})", f"--version mit Datum: {run('--version').stdout.strip()}")
ok(ps.APP_CONTACT in run("--about").stdout and ps.APP_CONTACT in run("--help").stdout, "Kontaktadresse in --about und --help")
ok(ps.APP_CONTACT in open(os.path.join(MODDIR, "hadron_sync.py")).read()[:1500], "Kontaktadresse im Dateikopf")
src = open(os.path.join(MODDIR, "hadron_sync.py")).read()[:1500]
ok("Autor: Dennis Peteranderl" in src and "Mistral AI" in src and "eigenes" in src, "Hinweis im Dateikopf")

# --- Oberflaeche: Tray-Menue, Fensterfuss, Ueber-Dialog
from unittest.mock import MagicMock
class G:
    @staticmethod
    def idle_add(fn, *a): fn(*a); return 1
    @staticmethod
    def timeout_add_seconds(s, fn, *a): return 1
    @staticmethod
    def source_remove(i): pass
ps.Gtk = MagicMock(); ps.Gio = MagicMock(); ps.GLib = G; ps.AppIndicator = MagicMock()
app = ps.SyncApp(background=True); app.log_buf.get_line_count.return_value = 0
ps.set_language("de")
app.build_tray()
labels = [c.kwargs.get("label") for c in ps.Gtk.MenuItem.call_args_list]
ok("Über Hadron Sync …" in labels, f"Tray-Menue: {labels}")
app.build_window()
lbls = [c.kwargs.get("label") for c in ps.Gtk.Label.call_args_list]
ok("Inoffizielles, privates, nicht-kommerzielles Projekt – Nutzung auf eigenes Risiko." in lbls, "Hinweis im Fensterfuss")
app.show_about()
dlg = ps.Gtk.AboutDialog.return_value
ok(dlg.set_program_name.call_args.args[0] == "Hadron Sync" and dlg.set_authors.call_args.args[0] == ["Dennis Peteranderl"], "Ueber-Dialog: Name und Autor")
ok(ps.APP_DATE in dlg.set_version.call_args.args[0] and ps.APP_CONTACT in dlg.set_comments.call_args.args[0]
   and dlg.set_website.call_args.args[0] == f"mailto:{ps.APP_CONTACT}", "Ueber-Dialog: Datum und Kontakt")
ok("Mistral AI" in dlg.set_comments.call_args.args[0] and "eigenes Risiko" in dlg.set_comments.call_args.args[0], "Ueber-Dialog: Hinweis")

print(f"\n{len(FAILS)} Fehlschlaege" if FAILS else "\nAlle Tests bestanden.")
sys.exit(1 if FAILS else 0)
