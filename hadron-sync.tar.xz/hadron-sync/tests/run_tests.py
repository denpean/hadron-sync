#!/usr/bin/env python3
"""Fuehrt alle Tests aus. Nutzt eine simulierte proton-drive CLI und arbeitet nur in /tmp/hadron-sync-test."""
import os, shutil, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
BASE = "/tmp/hadron-sync-test"
shutil.rmtree(BASE, ignore_errors=True)
os.makedirs(BASE)
shutil.copytree(os.path.join(HERE, "fake_bin"), os.path.join(BASE, "fakebin"))
for f in os.listdir(os.path.join(BASE, "fakebin")):
    os.chmod(os.path.join(BASE, "fakebin", f), 0o755)
rc = 0
for name in ("test_engine.py", "test_gui_logic.py", "test_i18n.py", "test_security.py", "test_resume.py", "test_about.py", "test_cli_compat.py", "test_parallel.py", "test_names.py", "test_ui.py", "test_changelog.py", "test_installer.py"):
    print(f"=== {name} ===", flush=True)
    r = subprocess.run([sys.executable, os.path.join(HERE, name)], capture_output=True, text=True)
    lines = [l for l in r.stdout.splitlines() if l.startswith(("PASS", "FAIL"))]
    for l in r.stdout.splitlines():
        if l.startswith("SKIP"):
            print("  " + l)
    fails = [l for l in lines if l.startswith("FAIL")]
    print(f"{len(lines) - len(fails)} bestanden, {len(fails)} fehlgeschlagen")
    for l in fails:
        print("  " + l)
    if r.returncode != 0:
        rc = 1
        if not fails:
            print(r.stdout[-1500:], r.stderr[-1500:])
shutil.rmtree(BASE, ignore_errors=True)
print("\nALLES OK" if rc == 0 else "\nEs gab Fehler.")
sys.exit(rc)
