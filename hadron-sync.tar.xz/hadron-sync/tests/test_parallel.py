# Paralleles Einlesen von Proton Drive: gleiche Ergebnisse, schneller, fehlertolerant, abbrechbar.
import os, shutil, sys, time
MODDIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = "/tmp/hadron-sync-test/par"
shutil.rmtree(B, ignore_errors=True)
os.environ.update(HOME=f"{B}/home", XDG_CONFIG_HOME=f"{B}/cfg", XDG_STATE_HOME=f"{B}/state",
                  FAKE_REMOTE=f"{B}/remote", FAKE_TRASH=f"{B}/trash")
os.environ["PATH"] = "/tmp/hadron-sync-test/fakebin:" + os.environ["PATH"]
os.makedirs(f"{B}/home")
sys.path.insert(0, MODDIR)
import hadron_sync as ps
ps.set_language("de")
FAILS = []
def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: FAILS.append(m)
CLI = ps.Cli("/tmp/hadron-sync-test/fakebin/proton-drive")
EXCL = ps.parse_excludes(ps.DEFAULT_EXCLUDES)
R = f"{B}/remote/my-files/P"
# Baum mit 40 Ordnern und 80 Dateien
for i in range(8):
    for j in range(4):
        d = f"{R}/o{i}/u{j}"; os.makedirs(d)
        for k in range(2): open(f"{d}/f{k}.txt", "w").write(f"{i}{j}{k}")
n_dirs = sum(len(dd) for _, dd, _ in os.walk(R))
def scan(workers, cancel=None, log=None):
    return ps.scan_remote(CLI, "/my-files/P", EXCL, log or (lambda m: None), cancel or ps.CancelToken(), workers=workers)

# --- 1) Gleiche Ergebnisse wie seriell
f1, d1 = scan(1)
f4, d4 = scan(4)
f8, d8 = scan(8)
ok(f1 == f4 == f8 and d1 == d4 == d8, "Parallel liefert dasselbe wie seriell")
ok(len(f1) == 64 and len(d1) == n_dirs, f"Vollstaendig eingelesen: {len(f1)} Dateien, {len(d1)} Ordner")
# --- 2) Messbar schneller
os.environ["FAKE_DELAY"] = "0.15"
t0 = time.time(); scan(1); t_seriell = time.time() - t0
t0 = time.time(); scan(4); t_par = time.time() - t0
ok(t_par < t_seriell * 0.6, f"Parallel schneller: {t_seriell:.1f}s seriell vs. {t_par:.1f}s mit 4 ({t_seriell / max(t_par, 0.01):.1f}x)")
os.environ.pop("FAKE_DELAY")
# --- 3) Vorübergehende Fehler werden einzeln wiederholt
os.environ["FAKE_FLAKY"] = "3"; os.environ["FAKE_FLAKY_FILE"] = f"{B}/flaky.cnt"; ps.RETRY_PAUSES = (0.1, 0.1, 0.1)
logs = []
f, d = scan(4, log=logs.append)
ok(f == f1 and d == d1, "Nach Wiederholung vollstaendiges Ergebnis")
ok(sum("erneut gelesen" in l for l in logs) >= 3, f"Wiederholungen gemeldet ({sum(chr(101)+chr(114) in l and chr(108) in l for l in logs)})")
os.environ.pop("FAKE_FLAKY")
# --- 4) Dauerhafter Fehler wird gemeldet
os.environ["FAKE_FLAKY"] = "9999"; os.remove(f"{B}/flaky.cnt")
try:
    scan(4); ok(False, "Fehler erwartet")
except ps.SyncError as e:
    ok("fehlgeschlagen" in str(e).lower() or "database is locked" in str(e), f"Dauerhafter Fehler gemeldet: {str(e)[:60]}")
os.environ.pop("FAKE_FLAKY"); os.environ.pop("FAKE_FLAKY_FILE")
# --- 5) Abbruch wirkt auch parallel
class CancelAfter(ps.CancelToken):
    def __init__(self, n): super().__init__(); self.n = n
    def check(self):
        self.n -= 1
        if self.n < 0: raise ps.Cancelled()
os.environ["FAKE_DELAY"] = "0.05"
t0 = time.time()
try:
    scan(4, cancel=CancelAfter(3)); ok(False, "Abbruch erwartet")
except ps.Cancelled:
    ok(time.time() - t0 < 10, f"Abbruch wirkt zuegig ({time.time() - t0:.1f}s)")
os.environ.pop("FAKE_DELAY")
# --- 6) Fehlender Wurzelordner bleibt erkennbar (Trockenlauf)
f, d = ps.scan_remote(CLI, "/my-files/GibtsNicht", EXCL, lambda m: None, ps.CancelToken(), root_missing_ok=True, workers=4)
ok(f == {} and d == set(), "Fehlender Wurzelordner: leeres Ergebnis statt Fehler")
try:
    ps.scan_remote(CLI, "/my-files/GibtsNicht", EXCL, lambda m: None, ps.CancelToken(), workers=4)
    ok(False, "NotFound erwartet")
except ps.NotFound:
    ok(True, "Fehlender Wurzelordner ohne Trockenlauf: Fehler")
# --- 7) Einstellung wird geprueft und verwendet
for val, exp in ((4, 4), (1, 1), (8, 8), (0, ps.PARALLEL_DEFAULT), (99, ps.PARALLEL_DEFAULT), ("viel", ps.PARALLEL_DEFAULT)):
    ps.save_config({"pairs": [], "parallel": val})
    ok(ps.load_config()["parallel"] == exp, f"Einstellung parallel={val!r} -> {exp}")
# --- 8) Ganzer Abgleich mit parallelem Einlesen
L = f"{B}/local"; os.makedirs(L)
for i in range(5): open(f"{L}/n{i}.txt", "w").write(f"n{i}")
cfg = {"local": L, "remote": "/my-files/P", "cli": "/tmp/hadron-sync-test/fakebin/proton-drive",
       "excludes": ps.DEFAULT_EXCLUDES, "parallel": 4}
p = ps.run_sync(cfg, [].append, ps.CancelToken(), confirm=lambda m: True)
ok(p.errors == 0 and all(os.path.exists(f"{R}/n{i}.txt") for i in range(5)) and os.path.exists(f"{L}/o0/u0/f0.txt"),
   "Vollstaendiger Abgleich mit 4 gleichzeitigen Abfragen")
p = ps.run_sync(cfg, [].append, ps.CancelToken(), confirm=lambda m: True)
ok(p.total() == 0, "Danach stabil")

print(f"\n{len(FAILS)} Fehlschlaege" if FAILS else "\nAlle Tests bestanden.")
sys.exit(1 if FAILS else 0)
