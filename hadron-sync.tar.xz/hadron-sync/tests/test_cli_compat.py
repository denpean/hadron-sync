# Kompatibilitaet mit Proton-CLI 0.7.0 und 0.8.0 (0.8.0 kennt "-c" nicht mehr).
import os, shutil, subprocess, sys, time
MODDIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = "/tmp/hadron-sync-test/compat"
shutil.rmtree(B, ignore_errors=True)
os.environ.update(HOME=f"{B}/home", XDG_CONFIG_HOME=f"{B}/cfg", XDG_STATE_HOME=f"{B}/state",
                  FAKE_REMOTE=f"{B}/remote", FAKE_TRASH=f"{B}/trash")
os.environ["PATH"] = "/tmp/hadron-sync-test/fakebin:" + os.environ["PATH"]
for d in ("home", "remote/my-files/C", "local"):
    os.makedirs(f"{B}/{d}")
sys.path.insert(0, MODDIR)
import hadron_sync as ps
ps.set_language("de")
FAILS = []
def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: FAILS.append(m)
L, R = f"{B}/local", f"{B}/remote/my-files/C"
CALLS = f"{B}/calls.log"; os.environ["FAKE_LOG"] = CALLS
def reset(): open(CALLS, "w").close()
def calls(prefix): return [l for l in open(CALLS) if l.startswith(prefix)]
now = time.time()
def w(p, t, ts=now - 500):
    os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(t); os.utime(p, (ts, ts))
logs = []
def sync(local=L, remote="/my-files/C"):
    logs.clear()
    cfg = {"local": local, "remote": remote, "cli": "/tmp/hadron-sync-test/fakebin/proton-drive", "excludes": ps.DEFAULT_EXCLUDES}
    return ps.run_sync(cfg, logs.append, ps.CancelToken(), confirm=lambda m: True)

# --- 1) Verhalten wie CLI 0.8.0 (Standard der Test-CLI): "-c" wird abgelehnt
r = subprocess.run(["/tmp/hadron-sync-test/fakebin/proton-drive", "filesystem", "upload", "-c", "replace", "/x", "/my-files"], capture_output=True, text=True)
ok(r.returncode != 0 and "Unknown option '-c'" in r.stderr, "Test-CLI verhaelt sich wie 0.8.0")
for i in range(12): w(f"{L}/dir/f{i}.txt", f"{i}")
w(f"{R}/remote.txt", "R")
reset(); p = sync()
ok(p.errors == 0 and all(os.path.exists(f"{R}/dir/f{i}.txt") for i in range(12)) and os.path.exists(f"{L}/remote.txt"), "Upload und Download mit CLI 0.8.0")
ups = calls("filesystem upload")
ok(ups and all("--file-conflict-strategy replace" in l and " -c " not in l for l in ups), "Upload nutzt --file-conflict-strategy")
dls = calls("filesystem download")
ok(dls and all("conflict" not in l and " -c " not in l for l in dls), "Download ohne Konfliktstrategie (leerer Zwischenordner)")
# Aktualisierung einer vorhandenen Datei (Konfliktfall beim Upload)
w(f"{L}/dir/f0.txt", "geaendert", now); p = sync()
ok(p.errors == 0 and open(f"{R}/dir/f0.txt").read() == "geaendert", "Geaenderte Datei ersetzt Remote-Version (0.8.0)")
# --- 2) Verhalten wie CLI 0.7.0
os.environ["FAKE_CLI_STYLE"] = "0.7"
w(f"{L}/dir/f1.txt", "neu-0.7", now + 10); w(f"{R}/r07.txt", "07")
p = sync()
ok(p.errors == 0 and open(f"{R}/dir/f1.txt").read() == "neu-0.7" and os.path.exists(f"{L}/r07.txt"), "Upload und Download mit CLI 0.7.0")
os.environ.pop("FAKE_CLI_STYLE")
# --- 3) Befehlsfehler der CLI: sofortiger Abbruch statt Fehler je Datei
L2 = f"{B}/local2"
for i in range(30): w(f"{L2}/f{i}.txt", f"x{i}")
os.environ["FAKE_USAGE_ERROR"] = "1"; reset()
t0 = time.time()
try:
    sync(local=L2, remote="/my-files/C2"); ok(False, "Abbruch erwartet")
except ps.SyncError as e:
    ok("bitte Hadron Sync aktualisieren" in str(e) and "Unknown option" in str(e), f"Klare Meldung: {str(e)[:90]}")
ok(len(calls("filesystem upload")) == 1, f"Nur ein Upload-Versuch statt 30 ({len(calls('filesystem upload'))})")
ok(sum("FEHLER Upload" in l for l in logs) == 0, "Keine Fehlerflut im Protokoll")
os.environ.pop("FAKE_USAGE_ERROR")
p = sync(local=L2, remote="/my-files/C2")
ok(p.errors == 0 and len(os.listdir(f"{B}/remote/my-files/C2")) == 30, "Nach Behebung wird alles hochgeladen")
# --- 4) Rueckfragen der CLI koennen nie haengen bleiben
os.environ["FAKE_PROMPT"] = "1"
w(f"{L}/prompt.txt", "p", now + 20)
t0 = time.time()
p = sync()
ok(time.time() - t0 < 20 and p.errors >= 1 and any("Keine Antwort" in l for l in logs), "CLI-Rueckfrage fuehrt zu Fehler statt zum Haengen")
os.environ.pop("FAKE_PROMPT")

# --- 5) Datei, fuer die kein Vorschaubild erzeugt werden kann (z. B. .PNG ohne PNG-Inhalt)
w(f"{L}/bilder/kaputt.PNG", "kein echtes Bild", now + 30)
for i in range(3): w(f"{L}/bilder/ok{i}.PNG", f"bild{i}", now + 30)
os.environ["FAKE_THUMB_FAIL"] = "kaputt.PNG"
reset(); p = sync()
ok(p.errors == 0 and os.path.exists(f"{R}/bilder/kaputt.PNG"), "Datei ohne Vorschaubild wird trotzdem hochgeladen")
ok(any("Ohne Vorschaubild hochgeladen: bilder/kaputt.PNG" in l for l in logs), "Zweiter Versuch wird gemeldet")
ok(not any("1 item(s) failed" in l for l in logs), "Keine Fehlermeldung, obwohl der Grund nur in der Standardausgabe stand")
ups = calls("filesystem upload")
ok(sum("--skip-thumbnails" in l for l in ups) == 1, f"Nur der Problemfall ohne Vorschaubild ({sum('--skip-thumbnails' in l for l in ups)})")
ok(all(os.path.exists(f"{R}/bilder/ok{i}.PNG") for i in range(3)), "Andere Bilder normal hochgeladen")
p = sync(); ok(p.total() == 0, "Danach stabil, kein erneuter Versuch")
# Einstellung: Vorschaubilder ganz abschalten
w(f"{L}/bilder/neu.PNG", "n", now + 40); reset()
cfg = {"local": L, "remote": "/my-files/C", "cli": "/tmp/hadron-sync-test/fakebin/proton-drive",
       "excludes": ps.DEFAULT_EXCLUDES, "thumbnails": False}
p = ps.run_sync(cfg, logs.append, ps.CancelToken(), confirm=lambda m: True)
ups = calls("filesystem upload")
ok(p.errors == 0 and ups and all("--skip-thumbnails" in l for l in ups), "Einstellung: alle Uploads ohne Vorschaubilder")
os.environ.pop("FAKE_THUMB_FAIL")
# Kommandozeile
ps.save_config({"pairs": [{"local": L, "remote": "/my-files/C"}], "cli": "/tmp/hadron-sync-test/fakebin/proton-drive", "language": "de"})
w(f"{L}/cli-test.txt", "c", now + 50); reset()
r = subprocess.run([sys.executable, os.path.join(MODDIR, "hadron_sync.py"), "--headless", "--yes", "--no-thumbnails"],
                   capture_output=True, text=True, env=os.environ)
ok(r.returncode == 0 and all("--skip-thumbnails" in l for l in calls("filesystem upload")), "--no-thumbnails wirkt")

# Meldungen aus beiden Ausgaben werden ausgewertet
ok(ps.Cli.message("Grund steht hier", "kurze Meldung") == "kurze Meldung\nGrund steht hier", "Beide Ausgaben werden zusammengefuehrt")
ok(ps.Cli.message("nur stdout", "") == "nur stdout" and ps.Cli.message("", "nur stderr") == "nur stderr", "Einzelne Ausgabe funktioniert weiter")
os.environ["FAKE_THUMB_FAIL"] = "auch-kaputt.PNG"
w(f"{L}/bilder/auch-kaputt.PNG", "kein Bild", now + 60)
p = sync()
ok(p.errors == 0 and os.path.exists(f"{R}/bilder/auch-kaputt.PNG"), "Auch im Sammelaufruf: Datei kommt an")
os.environ.pop("FAKE_THUMB_FAIL")

print(f"\n{len(FAILS)} Fehlschlaege" if FAILS else "\nAlle Tests bestanden.")
sys.exit(1 if FAILS else 0)
