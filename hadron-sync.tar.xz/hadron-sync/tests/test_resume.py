# Unterbrochene Abgleiche fortsetzen, Aenderungen waehrend langer Laeufe, Fortschritt, sparsame Kontrolle.
import json, os, shutil, sys, time
MODDIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = "/tmp/hadron-sync-test/resume"
shutil.rmtree(B, ignore_errors=True)
os.environ.update(HOME=f"{B}/home", XDG_CONFIG_HOME=f"{B}/cfg", XDG_STATE_HOME=f"{B}/state",
                  FAKE_REMOTE=f"{B}/remote", FAKE_TRASH=f"{B}/trash")
os.environ["PATH"] = "/tmp/hadron-sync-test/fakebin:" + os.environ["PATH"]
for d in ("home", "remote/my-files/R", "local"):
    os.makedirs(f"{B}/{d}")
sys.path.insert(0, MODDIR)
import hadron_sync as ps
ps.set_language("de")
FAILS = []
def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: FAILS.append(m)
L, R = f"{B}/local", f"{B}/remote/my-files/R"
cfg = {"local": L, "remote": "/my-files/R", "cli": "/tmp/hadron-sync-test/fakebin/proton-drive", "excludes": ps.DEFAULT_EXCLUDES}
sp = ps.state_path(L, "/my-files/R")
now = time.time()
def w(p, t, ts=now - 500):
    os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(t); os.utime(p, (ts, ts))
def rd(p): return open(p).read() if os.path.exists(p) else None
CALLS = f"{B}/calls.log"; os.environ["FAKE_LOG"] = CALLS
def calls(prefix):
    return [l for l in open(CALLS)] if os.path.exists(CALLS) and not prefix else [l for l in open(CALLS) if l.startswith(prefix)] if os.path.exists(CALLS) else []
def reset(): open(CALLS, "w").close()
logs = []
def sync(mode="full", cancel=None):
    logs.clear()
    return ps.run_sync(cfg, logs.append, cancel or ps.CancelToken(), confirm=lambda m: True, mode=mode)

class CancelAfter(ps.CancelToken):
    def __init__(self, n): super().__init__(); self.n = n
    def check(self):
        self.n -= 1
        if self.n < 0: raise ps.Cancelled()

# --- 1) Erster Abgleich wird waehrend des Hochladens abgebrochen
ps.BATCH = 5
for i in range(30): w(f"{L}/viele/f{i:02}.txt", f"inhalt {i}")
w(f"{R}/nur-remote.txt", "R")
real_uploads = ps.Syncer.uploads
chunks_done = []
def counting_uploads(self, paths, failed, done=None):
    def d(kind, ps_):
        chunks_done.append(len(ps_)); done(kind, ps_)
        if len(chunks_done) == 3: raise ps.Cancelled()   # Abbruch nach 3 Bloecken (15 Dateien)
    return real_uploads(self, paths, failed, done=d)
ps.Syncer.uploads = counting_uploads
try:
    sync(); ok(False, "Abbruch")
except ps.Cancelled:
    ok(True, "Abbruch mitten im Hochladen")
ps.Syncer.uploads = real_uploads
st = json.load(open(sp))
ok(st["complete"] is False and len(st["files"]) == 15, f"Zwischenstand gespeichert: {len(st['files'])} Dateien, complete={st['complete']}")
ok(not os.path.exists(f"{L}/nur-remote.txt"), "Download war noch nicht dran")
# --- 2) Fortsetzen: nichts wird doppelt hochgeladen, nichts geloescht
reset(); p = sync()
ups = [l for l in calls("filesystem upload")]
uploaded = sum(l.count("/viele/f") for l in ups)
ok(any("Setze unterbrochenen Abgleich fort: 15 Dateien" in l for l in logs), "Meldung: Abgleich wird fortgesetzt")
ok(uploaded == 15 and len(p.upload) == 15, f"Nur die restlichen 15 Dateien hochgeladen ({uploaded})")
ok(p.deletions() == 0 and rd(f"{L}/nur-remote.txt") == "R", "Nichts geloescht, Download nachgeholt")
ok(json.load(open(sp))["complete"] is True, "Stand danach vollstaendig")
ok(all(rd(f"{R}/viele/f{i:02}.txt") == f"inhalt {i}" for i in range(30)), "Alle 30 Dateien in Proton")
p = sync(); ok(p.total() == 0, "Danach stabil")
# --- 3) Schnellabgleich auf Zwischenstand -> voller Abgleich
ps.save_state(sp, *ps.load_state(sp), complete=False)
p = sync(mode="quick")
ok(any("Unterbrochener Abgleich – führe vollen Abgleich aus." in l for l in logs) and p.full, "Quick auf Zwischenstand wird zum Vollabgleich")
# --- 4) Nach Unterbrechung lokal geloeschte, bereits abgeglichene Datei -> in Proton-Papierkorb
p = sync()
os.remove(f"{L}/viele/f00.txt"); ps.save_state(sp, *ps.load_state(sp), complete=False)
p = sync(); ok(p.trash_remote == ["viele/f00.txt"] and not os.path.exists(f"{R}/viele/f00.txt"), "Loeschung einer abgeglichenen Datei wird uebernommen")
# --- 5) Aenderungen WAEHREND eines langen Laufs gehen nicht verloren
w(f"{L}/andere/lokal.txt", "alt"); w(f"{R}/andere/remote.txt", "alt"); sync()
w(f"{L}/neu.txt", "neu", now)
def uploads_with_edits(self, paths, failed, done=None):
    w(f"{L}/andere/lokal.txt", "waehrend-geaendert", now + 50)    # nicht im Plan
    w(f"{R}/andere/remote.txt", "remote-waehrend", now + 60)     # nicht im Plan
    return real_uploads(self, paths, failed, done=done)
ps.Syncer.uploads = uploads_with_edits
p = sync(); ps.Syncer.uploads = real_uploads
ok(p.upload == ["neu.txt"], "Lauf plant nur neu.txt")
p = sync()
ok("andere/lokal.txt" in p.upload and rd(f"{R}/andere/lokal.txt") == "waehrend-geaendert", "Lokale Aenderung waehrend des Laufs wird danach hochgeladen")
ok("andere/remote.txt" in p.download and rd(f"{L}/andere/remote.txt") == "remote-waehrend", "Remote-Aenderung waehrend des Laufs wird danach geholt")
# --- 6) Kontrolle liest nur betroffene Proton-Ordner
for i in range(8): w(f"{L}/ordner{i}/x.txt", "x")
sync(); w(f"{L}/ordner3/y.txt", "y", now + 100)
n_dirs = len(ps.scan_remote(ps.Cli(cfg["cli"]), "/my-files/R", ps.parse_excludes(ps.DEFAULT_EXCLUDES), lambda m: None, ps.CancelToken())[1]) + 1
reset(); p = sync()
lists = calls("filesystem list")
ok(len(lists) == 1 + n_dirs + 1, f"Kontrolle: {len(lists)} list-Aufrufe (Zielprüfung 1 + Einlesen {n_dirs} + 1 betroffener Ordner, früher {1 + 2 * n_dirs})")
# --- 7) Fortschrittsmeldungen
ps.PROGRESS_S = 0
for i in range(12): w(f"{L}/prog/p{i}.txt", "p" * 1000, now + 200)
for i in range(6): w(f"{R}/progr/q{i}.txt", "q" * 2000, now + 200)
p = sync()
ok(any("Proton Drive:" in l and "Ordnern gelesen" in l for l in logs), "Fortschritt beim Lesen von Proton Drive")
ok(any(l.strip().startswith("Vergleiche Dateiinhalte:") for l in logs), "Fortschritt beim Vergleichen")
ok(any("Fortschritt: 12 von 12 Dateien hochgeladen (11.7 KiB von 11.7 KiB)" in l for l in logs), "Fortschritt Hochladen mit Groesse")
ok(any("Fortschritt: 6 von 6 Dateien heruntergeladen" in l for l in logs), "Fortschritt Herunterladen")
ps.PROGRESS_S = 15

print(f"\n{len(FAILS)} Fehlschlaege" if FAILS else "\nAlle Tests bestanden.")
sys.exit(1 if FAILS else 0)
