# Prueft die Uebersetzungen: Vollstaendigkeit, Platzhalter, Sprachwahl und uebersetzte Ausgaben.
import ast, os, re, shutil, string, subprocess, sys, time
MODDIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = "/tmp/hadron-sync-test"
for d in ("i18n",):
    shutil.rmtree(f"{B}/{d}", ignore_errors=True)
os.environ.update(HOME=f"{B}/i18n/home", XDG_CONFIG_HOME=f"{B}/i18n/cfg", XDG_STATE_HOME=f"{B}/i18n/state",
                  FAKE_REMOTE=f"{B}/i18n/remote", FAKE_TRASH=f"{B}/i18n/trash")
os.environ["PATH"] = f"{B}/fakebin:" + os.environ["PATH"]
for d in ("home", "remote/my-files", "local"):
    os.makedirs(f"{B}/i18n/{d}")
sys.path.insert(0, MODDIR)
import hadron_sync as ps
FAILS = []
def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: FAILS.append(m)

# 1) Jeder T("...")-Aufruf hat einen Katalogeintrag
src = open(os.path.join(MODDIR, "hadron_sync.py")).read()
used = {n.args[0].value for n in ast.walk(ast.parse(src)) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
        and n.func.id == "T" and n.args and isinstance(n.args[0], ast.Constant)}
missing = [k for k in used if k not in ps.MESSAGES["de"]]
ok(not missing, f"Alle {len(used)} Texte im Katalog ({missing[:3]})")
for what in ("Upload", "Download", "Papierkorb", "Ordner-Papierkorb", "Übersprungen (Backslash im Namen): {path}",
             "Übersprungen (Sonderzeichen im Namen): {path}", "Übersprungen (unzulässiger Name): {path}",
             "Übersprungen (Ordnername beginnt mit „-“): {path}"):
    ok(what in ps.MESSAGES["de"], f"Dynamischer Text im Katalog: {what}")
# 2) Platzhalter und Vollstaendigkeit
f = string.Formatter(); bad = []
for row in ps.CATALOG:
    ph = [sorted({x[1] for x in f.parse(t) if x[1]}) for t in row]
    if len(row) != 4 or any(p != ph[0] for p in ph) or any(not t.strip() for t in row):
        bad.append(row[0])
ok(not bad, f"{len(ps.CATALOG)} Eintraege, Platzhalter in allen Sprachen gleich ({bad[:2]})")
ok(len({r[0] for r in ps.CATALOG}) == len(ps.CATALOG), "Keine doppelten Schluessel")
# 3) Jede Sprache liefert Text, unbekannter Schluessel faellt auf Deutsch zurueck
for code, word in (("de", "Bereit"), ("en", "Ready"), ("es", "Listo"), ("fr", "Prêt")):
    ps.set_language(code); ok(ps.T("Bereit") == word, f"{code}: {ps.T('Bereit')}")
ok(ps.T("Gibt es nicht") == "Gibt es nicht", "Unbekannter Text bleibt unveraendert")
# 4) Systemsprache
for env, exp in (({"LANG": "es_ES.UTF-8"}, "es"), ({"LANGUAGE": "fr_FR:en", "LANG": "de_DE.UTF-8"}, "fr"),
                 ({"LANG": "C.UTF-8"}, "en"), ({"LANG": "de_AT.UTF-8"}, "de"), ({"LANG": "it_IT.UTF-8"}, "en")):
    saved = {v: os.environ.pop(v, None) for v in ("LANGUAGE", "LC_ALL", "LC_MESSAGES", "LANG")}
    os.environ.update(env); got = ps.set_language("auto")
    for v, val in saved.items():
        os.environ.pop(v, None)
        if val is not None: os.environ[v] = val
    ok(got == exp, f"Automatisch {env} -> {got}")
ok(ps.set_language("xx") in ps.MESSAGES, "Ungueltiger Code -> Systemsprache")
# 5) Konfiguration
ps.save_config({"pairs": [], "language": "fr"}); ok(ps.load_config()["language"] == "fr", "Sprache wird gespeichert")
ps.save_config({"pairs": [], "language": "klingonisch"}); ok(ps.load_config()["language"] == "auto", "Ungueltige Sprache -> automatisch")
# 6) Sync-Ausgaben und Konfliktkopie in der gewaehlten Sprache
L = f"{B}/i18n/local"; R = f"{B}/i18n/remote/my-files/I"
cfg = {"local": L, "remote": "/my-files/I", "cli": f"{B}/fakebin/proton-drive", "excludes": ps.DEFAULT_EXCLUDES}
open(f"{L}/a.txt", "w").write("a"); os.utime(f"{L}/a.txt", (time.time() - 999,) * 2)
ps.set_language("fr"); logs = []
ps.run_sync(cfg, logs.append, ps.CancelToken(), confirm=lambda m: True)
ok(any(l.startswith("Plan : ") for l in logs) and any("Terminé" in l for l in logs), "Protokoll auf Franzoesisch")
ps.set_language("en")
open(f"{L}/a.txt", "w").write("lokal"); os.utime(f"{L}/a.txt", (time.time() - 100,) * 2)
open(f"{R}/a.txt", "w").write("remote"); os.utime(f"{R}/a.txt", (time.time() - 50,) * 2)
plan = ps.run_sync(cfg, [].append, ps.CancelToken(), confirm=lambda m: True)
ok(plan.conflict_copies and plan.conflict_copies[0].startswith("a (Conflict "), f"Konfliktkopie englisch benannt: {plan.conflict_copies}")
ps.set_language("es")
try:
    ps.validate_pairs([])
    ok(False, "Fehlermeldung")
except ps.SyncError as e:
    ok(str(e) == "No hay ningún par de carpetas configurado.", f"Fehlermeldung spanisch: {e}")
msgs = []
ps.set_language("es"); shutil.rmtree(f"{B}/i18n/cfg", ignore_errors=True)
L2 = f"{B}/i18n/local2"; os.makedirs(L2); open(f"{L2}/n.txt", "w").write("n")
ps.run_sync(dict(cfg, local=L2, remote="/my-files/Neu"), [].append, ps.CancelToken(), confirm=lambda m: (msgs.append(m), True)[1])
ok(msgs and msgs[0].startswith("Primera sincronización de"), "Rueckfrage beim ersten Abgleich spanisch")
# 7) Terminalmodus nutzt die gespeicherte Sprache
ps.save_config({"pairs": [{"local": L, "remote": "/my-files/I"}], "language": "es", "cli": f"{B}/fakebin/proton-drive"})
r = subprocess.run([sys.executable, os.path.join(MODDIR, "hadron_sync.py"), "--headless", "--dry-run"],
                   capture_output=True, text=True, env=os.environ)
ok(r.returncode == 0 and "Leyendo la carpeta local" in r.stdout and "Simulación" in r.stdout, "Headless auf Spanisch")
ps.save_config({"pairs": [], "language": "fr"})
r = subprocess.run([sys.executable, os.path.join(MODDIR, "hadron_sync.py"), "--headless"], capture_output=True, text=True, env=os.environ)
ok(r.returncode != 0 and "Aucune paire" in r.stderr, "Headless-Fehlermeldung auf Franzoesisch")

# 8) Sprachwechsel in der Oberflaeche baut Menue und Fenster neu auf
from unittest.mock import MagicMock
class G:
    @staticmethod
    def idle_add(fn, *a): fn(*a); return 1
    @staticmethod
    def timeout_add_seconds(s, fn, *a): return 1
    @staticmethod
    def source_remove(i): pass
ps.Gtk = MagicMock(); ps.Gio = MagicMock(); ps.GLib = G; ps.AppIndicator = MagicMock()
ps.save_config({"pairs": [{"local": L, "remote": "/my-files/I"}], "language": "de", "cli": f"{B}/fakebin/proton-drive"})
app = ps.SyncApp(background=True)
app.log_buf.get_line_count.return_value = 0
ok(ps._LANG == "de", "App startet mit gespeicherter Sprache")
app.build_tray()
app.show_window = MagicMock()
old_win = MagicMock(); old_win.get_visible.return_value = True; app.window = old_win
app.lbl_status = MagicMock()
ps.Gtk.MenuItem.reset_mock()
app.apply_settings(dict(app.cfg, language="fr"), ask_restart=False)
labels = [c.kwargs.get("label") for c in ps.Gtk.MenuItem.call_args_list]
ok(ps._LANG == "fr" and "Prêt" in labels and "Quitter" in labels, f"Tray-Menue neu auf Franzoesisch: {labels}")
ok(old_win.destroy.called and app.show_window.called, "Fenster wird in neuer Sprache neu aufgebaut")
ok(ps.load_config()["language"] == "fr", "Sprachwahl gespeichert")
ps.Gtk.MenuItem.reset_mock(); app.window = None
app.apply_settings(dict(app.cfg), ask_restart=False)
ok(not ps.Gtk.MenuItem.called, "Ohne Sprachwechsel kein Neuaufbau")

# 9) Beim Sprachwechsel ist schon die erste Meldung in der neuen Sprache
ps.set_language("de"); app.cfg["language"] = "de"; app.cfg["realtime"] = True; app.cfg["excludes"] = "*.tmp"
open(ps.LOG_FILE, "w").close()
app.apply_settings(dict(app.cfg, language="es", excludes="*.tmp, *.bak"), ask_restart=False)  # auch ueberwachungsrelevante Aenderung
logtxt = open(ps.LOG_FILE, encoding="utf-8").read()
ok("Supervisando" in logtxt and "Überwache" not in logtxt, "Nach Umstellung auf Spanisch keine deutsche Zeile mehr")
# 10) Rueckfrage: Fenster-gebunden, immer oben, mit Benachrichtigung
ps.Gtk.MessageDialog.reset_mock(); ps.Gio.Notification.new.reset_mock()
app.window = MagicMock(); app.window.get_visible.return_value = True
app.confirm("Erster Abgleich für\nX\n\nFortfahren?")
kw = ps.Gtk.MessageDialog.call_args.kwargs
dlg = ps.Gtk.MessageDialog.return_value
ok(kw.get("transient_for") is app.window and kw.get("modal") is True, "Rückfrage gehört zum Fenster")
ok(dlg.set_keep_above.called and dlg.present.called, "Rückfrage bleibt im Vordergrund")
ok(ps.Gio.Notification.new.called, "Rückfrage zusätzlich als Benachrichtigung")

print(f"\n{len(FAILS)} Fehlschlaege" if FAILS else "\nAlle Tests bestanden.")
sys.exit(1 if FAILS else 0)
