# Selbstheilung: beschaedigte Lock-Datei der Proton-CLI (z. B. nach hartem Reset).
# Wichtig ist hier vor allem, was NICHT angefasst wird: gueltige Dateien, fremde Ordner, eigene Dateien,
# frisch geaenderte Dateien und alles ausserhalb des Home-Verzeichnisses.
import os, shutil, sys, threading, time
MODDIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = "/tmp/hadron-sync-test/heal"
shutil.rmtree(B, ignore_errors=True)
HOME = f"{B}/home"
os.environ.update(HOME=HOME, XDG_CONFIG_HOME=f"{HOME}/.config", XDG_STATE_HOME=f"{HOME}/.local/state",
                  XDG_CACHE_HOME=f"{HOME}/.cache", XDG_DATA_HOME=f"{HOME}/.local/share",
                  FAKE_REMOTE=f"{B}/remote", FAKE_TRASH=f"{B}/trash")
os.environ["PATH"] = "/tmp/hadron-sync-test/fakebin:" + os.environ["PATH"]
os.makedirs(f"{B}/remote/my-files")
sys.path.insert(0, MODDIR)
import hadron_sync as ps
ps.set_language("de")
FAILS = []
def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: FAILS.append(m)

CLI = "/tmp/hadron-sync-test/fakebin/proton-drive"
CACHE = f"{HOME}/.cache/proton-drive"
LOCK = f"{CACHE}/events.lock"
DECOY = f"{HOME}/.cache/other-app/events.lock"      # Ordner ohne Bezug zur Proton-CLI
LOGF = f"{B}/calls.log"
os.makedirs(CACHE)
notes = []
ps.set_cli_notice(notes.append)
os.environ["FAKE_CLI_CACHE"] = CACHE
cli = ps.Cli(CLI)

def make(path, content, age=3600):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(content)
    t = time.time() - age
    os.utime(path, (t, t))

def backups(d=CACHE):
    return sorted(f for f in os.listdir(d) if ".corrupt-" in f)

def reset():
    ps._HEAL_STATE.update(at=None, ok=False)
    notes.clear()
    for f in backups():
        os.remove(os.path.join(CACHE, f))
    if os.path.exists(LOCK):
        os.remove(LOCK)
    for k in ("FAKE_LOCK_ERROR", "FAKE_LOCK_PATH_IN_MSG", "FAKE_LOG"):
        os.environ.pop(k, None)
    os.environ["FAKE_CLI_CACHE"] = CACHE

def raises_sync(fn):
    try:
        fn()
    except ps.SyncError as e:
        return e
    return None

make(DECOY, b"\x00" * 64)                       # kaputt aussehend, aber nicht von der Proton-CLI
os.makedirs(ps.CONFIG_DIR, exist_ok=True)
OWN = f"{ps.CONFIG_DIR}/state-abc123.lock"      # Hadron Syncs eigene (leere) Sperrdatei
make(OWN, b"")

# --- 1) Verschiedene Arten von Beschaedigung werden erkannt und behoben
for label, content in (("Nullbytes (typisch nach hartem Reset)", b"\x00" * 64), ("leere Datei", b""),
                       ("abgebrochenes JSON", b'{"pid": 12'), ("nur Leerraum", b"  \n")):
    reset(); make(LOCK, content)
    try:
        nodes = cli.list_dir("/my-files")
        gut = isinstance(nodes, list)
    except ps.SyncError as e:
        gut = False
    ok(gut, f"{label}: Aufruf gelingt nach automatischer Reparatur")
    ok(not os.path.exists(LOCK) and len(backups()) == 1, f"{label}: Datei wurde umbenannt, nicht geloescht")
    ok(any("beiseitegelegt" in n for n in notes), f"{label}: Meldung an den Benutzer")

# --- 2) Was nicht angefasst werden darf
ok(open(DECOY, "rb").read() == b"\x00" * 64, "Fremder Ordner ohne Bezug zur Proton-CLI bleibt unberuehrt")
ok(os.path.exists(OWN), "Hadron Syncs eigene Sperrdatei bleibt unberuehrt")

reset(); make(LOCK, b'{"pid": 123, "t": 1}'); os.environ["FAKE_LOCK_ERROR"] = "1"
e = raises_sync(lambda: cli.list_dir("/my-files"))
ok(e is not None and os.path.exists(LOCK) and open(LOCK, "rb").read() == b'{"pid": 123, "t": 1}' and not backups(),
   "Gueltige Lock-Datei wird nicht angefasst, der Fehler bleibt sichtbar")
ok(any("keine eindeutig beschädigte Datei" in n for n in notes), "Klare Meldung, dass nichts Eindeutiges gefunden wurde")
ok(e is not None and "Unexpected EOF" in str(e), "Fehlermeldung zeigt jetzt auch das Ende (dort steht die Ursache)")

reset(); make(LOCK, b"\x00" * 8, age=1)
e = raises_sync(lambda: cli.list_dir("/my-files"))
ok(e is not None and os.path.exists(LOCK) and not backups(), "Frisch geaenderte Datei (koennte gerade beschrieben werden) bleibt liegen")
t = time.time() - 3600; os.utime(LOCK, (t, t)); ps._HEAL_STATE.update(at=None, ok=False)
ok(isinstance(cli.list_dir("/my-files"), list) and len(backups()) == 1, "Sobald sie alt genug ist, wird sie behoben")

reset(); make(LOCK, b'{"ok": true}')
e = None
try:
    cli.list_dir("/my-files/gibt-es-nicht")
except ps.NotFound:
    e = "nf"
ok(e == "nf" and not notes and not backups(), "Fehler ohne Bezug zur Lock-Datei loesen keine Reparatur aus")

# --- 3) Keine Endlosschleife, kein Dauerfeuer
reset(); make(LOCK, b"\x00" * 8); os.environ["FAKE_LOCK_ERROR"] = "1"; os.environ["FAKE_LOG"] = LOGF
open(LOGF, "w").close()
def lists(): return sum(1 for l in open(LOGF) if l.startswith("filesystem list"))
raises_sync(lambda: cli.list_dir("/my-files"))
n1 = lists()
ok(n1 == 2, f"Hilft die Reparatur nicht, gibt es genau einen Wiederholungsversuch ({n1} Aufrufe)")
raises_sync(lambda: cli.list_dir("/my-files"))
ok(lists() - n1 == 1, "Innerhalb der Wartezeit wird danach nicht erneut repariert oder wiederholt")

# --- 4) Mehrere gleichzeitige Aufrufe (paralleles Einlesen): nur eine Reparatur
reset(); make(LOCK, b"\x00" * 64)
results = []
def worker():
    try:
        results.append(cli.list_dir("/my-files"))
    except Exception as ex:  # noqa
        results.append(ex)
threads = [threading.Thread(target=worker) for _ in range(8)]
for t_ in threads: t_.start()
for t_ in threads: t_.join()
ok(all(isinstance(r, list) for r in results), f"Alle 8 gleichzeitigen Aufrufe gelingen ({[type(r).__name__ for r in results]})")
ok(len(backups()) == 1 and sum("beiseitegelegt" in n for n in notes) == 1, "Es wird genau einmal repariert und gemeldet")

# --- 5) Pfad aus der Meldung der CLI - aber nur innerhalb des Home-Verzeichnisses und nie eigene Dateien
NEUTRAL = f"{HOME}/.local/state/neutral-app"
reset(); make(f"{NEUTRAL}/events.lock", b"\x00" * 16)
os.environ.update(FAKE_CLI_CACHE=NEUTRAL, FAKE_LOCK_PATH_IN_MSG="1")
ok(isinstance(cli.list_dir("/my-files"), list) and os.path.exists(f"{NEUTRAL}/events.lock.corrupt-{time.strftime('%Y%m%d')}-000000") is False
   and any(".corrupt-" in f for f in os.listdir(NEUTRAL)), "Nennt die CLI den Pfad selbst, wird er auch ausserhalb der ueblichen Ordner gefunden")

OUT = f"{B}/outside"
reset(); make(f"{OUT}/events.lock", b"\x00" * 16)
os.environ.update(FAKE_CLI_CACHE=OUT, FAKE_LOCK_PATH_IN_MSG="1")
e = raises_sync(lambda: cli.list_dir("/my-files"))
ok(e is not None and os.listdir(OUT) == ["events.lock"], "Pfade ausserhalb des Home-Verzeichnisses werden nie angefasst")

reset(); make(f"{ps.CONFIG_DIR}/events.lock", b"\x00" * 16)
os.environ.update(FAKE_CLI_CACHE=str(ps.CONFIG_DIR), FAKE_LOCK_PATH_IN_MSG="1")
e = raises_sync(lambda: cli.list_dir("/my-files"))
ok(e is not None and os.path.exists(f"{ps.CONFIG_DIR}/events.lock"), "Dateien in Hadron Syncs eigenem Ordner werden nie angefasst")
os.remove(f"{ps.CONFIG_DIR}/events.lock")

# --- 6) Ganzer Abgleich, ausgehend von einer beschaedigten Datei
reset(); make(LOCK, b"\x00" * 32)
L = f"{B}/local"; os.makedirs(L)
open(f"{L}/a.txt", "w").write("hallo")
cfg = {"local": L, "remote": "/my-files/H", "cli": CLI, "excludes": ps.DEFAULT_EXCLUDES}
p = ps.run_sync(cfg, [].append, ps.CancelToken(), confirm=lambda m: True)
ok(p.errors == 0 and open(f"{B}/remote/my-files/H/a.txt").read() == "hallo", "Ganzer Abgleich laeuft trotz beschaedigter Lock-Datei durch")
ok(len(backups()) == 1, "Dabei wurde die Datei genau einmal beiseitegelegt")

# --- 7) Kuerzen behaelt Anfang und Ende
lang = "A" * 500 + "ENDE"
k = ps.shorten(lang, 100)
ok(k.startswith("A") and k.endswith("ENDE") and len(k) <= 110, f"Kurze Fassung behaelt Anfang und Ende ({len(k)} Zeichen)")
ok(ps.shorten("kurz", 100) == "kurz" and ps.shorten(None) == "", "Kurze oder leere Texte bleiben unveraendert")

print(f"\n{len(FAILS)} Fehlschlaege" if FAILS else "\nAlle Tests bestanden.")
sys.exit(1 if FAILS else 0)
