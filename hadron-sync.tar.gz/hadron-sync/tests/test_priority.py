# Priorisierung lokaler Aenderungen waehrend eines laufenden Vollabgleichs:
#  - Zwischenspeicherung des Einlesens (kein Fortschrittsverlust bei Unterbrechung)
#  - lokale Aenderung unterbricht sofort und wird gezielt/bevorzugt behandelt
#  - danach setzt sich der Vollabgleich automatisch fort
import json, os, shutil, sys, time
MODDIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = "/tmp/hadron-sync-test/priority"
shutil.rmtree(B, ignore_errors=True)
os.environ.update(HOME=f"{B}/home", XDG_CONFIG_HOME=f"{B}/cfg", XDG_STATE_HOME=f"{B}/state",
                  FAKE_REMOTE=f"{B}/remote", FAKE_TRASH=f"{B}/trash")
os.environ["PATH"] = "/tmp/hadron-sync-test/fakebin:" + os.environ["PATH"]
for d in ("home", "remote/my-files/P", "local"):
    os.makedirs(f"{B}/{d}")
sys.path.insert(0, MODDIR)
import hadron_sync as ps
ps.set_language("de")
FAILS = []
def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: FAILS.append(m)
L, R = f"{B}/local", f"{B}/remote/my-files/P"
CLI = "/tmp/hadron-sync-test/fakebin/proton-drive"
cfg = {"local": L, "remote": "/my-files/P", "cli": CLI, "excludes": ps.DEFAULT_EXCLUDES, "parallel": 4}
now = time.time()
def w(p, t, ts=None):
    os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(t)
    if ts: os.utime(p, (ts, ts))
CALLS = f"{B}/calls.log"; os.environ["FAKE_LOG"] = CALLS
def calls(prefix=""): return [l for l in open(CALLS)] if os.path.exists(CALLS) else []
def reset_calls(): open(CALLS, "w").close()
cp_path = ps.scan_checkpoint_path(L, "/my-files/P")
sp = ps.state_path(L, "/my-files/P")

# --- 1) scan_remote fuer sich: Unterbrechung mitten im Einlesen verliert nichts, Fortsetzung liest den Rest
for i in range(30):
    os.makedirs(f"{R}/o{i}", exist_ok=True)
    open(f"{R}/o{i}/f.txt", "w").write(str(i))
excl = ps.parse_excludes(ps.DEFAULT_EXCLUDES)
cli = ps.Cli(CLI)

reset_calls()
seen_pending, seen_files, seen_dirs, seen_done = [], [], [], []
interrupt_after = 3   # nach so vielen gesicherten Zwischenstaenden unterbrechen (der erste betrifft nur
                     # den Wurzelordner selbst und enthaelt daher noch keine Dateien - erst danach werden
                     # die entdeckten Unterordner gelesen)
tok = ps.CancelToken()
def cp_spy(pending, files, dirs, done):
    seen_pending.append(list(pending)); seen_files.append(dict(files)); seen_dirs.append(set(dirs)); seen_done.append(done)
    if len(seen_files) == interrupt_after:
        tok.request_priority()
try:
    ps.scan_remote(cli, "/my-files/P", excl, print, tok, workers=2, checkpoint=cp_spy)
    ok(False, "haette unterbrechen muessen")
except ps.Priority:
    ok(len(seen_files) >= 1, "Zwischenstand wurde mindestens einmal gesichert, bevor unterbrochen wurde")
ok(0 < len(seen_files[-1]) < 30, f"Beim Abbruch war ein echter Teil bereits gelesen, nicht alles ({len(seen_files[-1])} von 30)")
# Ordner, die schon VOR der Unterbrechung fertig gelesen waren (entdeckt, aber nicht mehr in "pending"):
bereits_fertig = seen_dirs[-1] - set(seen_pending[-1])
ok(0 < len(bereits_fertig) < 30, f"Ein Teil der entdeckten Ordner war beim Abbruch schon fertig gelesen ({len(bereits_fertig)})")

reset_calls()
files2, dirs2 = ps.scan_remote(cli, "/my-files/P", excl, print, ps.CancelToken(), workers=2,
                               resume=(seen_pending[-1], seen_files[-1], seen_dirs[-1], seen_done[-1]))
ok(len(files2) == 30, f"Nach Fortsetzen sind alle 30 Dateien bekannt ({len(files2)})")
# Bereits fertig gelesene Ordner werden bei der Fortsetzung nicht noch einmal abgefragt
abgefragt = {l.split()[2] for l in calls() if l.startswith("filesystem list")}
erneut_abgefragt = [a for a in abgefragt if a.rstrip("/").rpartition("/")[2] in bereits_fertig]
ok(not erneut_abgefragt, f"Bereits fertig gelesene Ordner werden bei der Fortsetzung nicht erneut abgefragt ({erneut_abgefragt})")
ok(all(a.rstrip("/").rpartition("/")[2] in seen_pending[-1] for a in abgefragt),
   f"Bei der Fortsetzung werden nur noch offene Ordner abgefragt ({abgefragt - {'/my-files/P/' + p for p in seen_pending[-1]}})")

# Ohne Unterbrechung liefert ein normaler Durchlauf dasselbe Ergebnis (Referenz)
files_ref, dirs_ref = ps.scan_remote(cli, "/my-files/P", excl, print, ps.CancelToken(), workers=2)
ok(files_ref == files2 and dirs_ref == dirs2, "Fortgesetztes Einlesen liefert dasselbe Ergebnis wie ein normaler Durchlauf")

# --- 2) Checkpoint-Datei: speichern, laden, loeschen
ps.save_scan_checkpoint(cp_path, ["a", "b"], files2, dirs2, 12)
geladen = ps.load_scan_checkpoint(cp_path)
ok(geladen is not None and geladen[0] == ["a", "b"] and geladen[2] == dirs2 and geladen[3] == 12,
   "Zwischenstand wird korrekt gespeichert und wieder geladen")
ok(os.stat(cp_path).st_mode & 0o777 == 0o600, "Zwischenspeicher-Datei nur fuer den eigenen Benutzer lesbar")
ps.clear_scan_checkpoint(cp_path)
ok(ps.load_scan_checkpoint(cp_path) is None, "Nach dem Loeschen kein Zwischenstand mehr vorhanden")
ok(ps.load_scan_checkpoint(cp_path.parent / "gibts-nicht.json") is None, "Fehlende Datei liefert None statt Fehler")

# --- 3) Voller Abgleich: Unterbrechung mitten im Einlesen wird beim naechsten Versuch fortgesetzt
for i in range(30, 40):
    os.makedirs(f"{R}/o{i}", exist_ok=True); open(f"{R}/o{i}/f.txt", "w").write(str(i))
tok2 = ps.CancelToken()
orig_save_cp = ps.save_scan_checkpoint
saved_once = {"n": 0}
def save_cp_once(*a, **k):
    orig_save_cp(*a, **k)
    saved_once["n"] += 1
    if saved_once["n"] == 1:
        tok2.request_priority()
ps.save_scan_checkpoint = save_cp_once
try:
    ps.run_sync(cfg, print, tok2, confirm=lambda m: True)
    ok(False, "haette unterbrechen muessen")
except ps.Priority:
    ok(cp_path.exists(), "Zwischenstand des Vollabgleichs liegt nach der Unterbrechung vor")
finally:
    ps.save_scan_checkpoint = orig_save_cp
ok(not sp.exists() or not ps.state_complete(sp), "Noch kein vollstaendiger Sync-Stand vorhanden")
logs = []
plan = ps.run_sync(cfg, logs.append, ps.CancelToken(), confirm=lambda m: True)
ok(any("Setze unterbrochenes Einlesen fort" in l for l in logs), "Meldung: unterbrochenes Einlesen wird fortgesetzt")
ok(plan.errors == 0 and len(plan.upload) == 0, f"Fortgesetzter Vollabgleich laedt nichts erneut hoch ({plan.upload})")
ok(not cp_path.exists(), "Zwischenstand ist nach erfolgreichem Abschluss wieder aufgeraeumt")
ok(all(os.path.isfile(f"{L}/o{i}/f.txt") for i in range(40)), "Alle 40 Ordner sind am Ende lokal vorhanden")

print(f"\n{len(FAILS)} Fehlschlaege" if FAILS else "\nAlle Tests bestanden.")
sys.exit(1 if FAILS else 0)
