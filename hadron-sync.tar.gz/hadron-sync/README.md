# Hadron Sync

Version 1.10.0 (2026-09-24)

**Autor:** Dennis Peteranderl · **Kontakt:** hadron.unfreeze611@passmail.net

> **Hinweis:** Hadron Sync ist ein **inoffizielles, privates und nicht-kommerzielles Projekt**. Es steht in keiner
> Verbindung zu Proton AG und wird von Proton weder unterstützt noch geprüft. Die Software wurde mithilfe der
> KI-Assistenten **Claude (Anthropic)** und **Mistral AI** erstellt. **Installation und Nutzung erfolgen auf eigenes
> Risiko und ohne Gewähr.** Lege vor der Nutzung Sicherungskopien deiner Daten an.

Zweiwege-Synchronisation beliebig vieler lokaler Ordner mit Ordnern in Proton Drive, mit Tray-Symbol,
Einstellungsfenster und Oberfläche auf Deutsch, Englisch, Spanisch und Französisch. Baut auf der offiziellen
[Proton Drive CLI](https://proton.me/support/drive-cli) auf.

## Installation

```
tar xzf hadron-sync.tar.gz
cd hadron-sync
./install.sh
```

Der Installer

1. installiert fehlende Systempakete (Python/GTK, Tray-Unterstützung, Schlüsselbund) – mit Rückfrage, per `sudo`,
2. lädt die **jeweils aktuelle Proton Drive CLI** aus Protons offiziellem Download-Index
   (`https://proton.me/download/drive/cli/index.html`), prüft sie gegen die dort veröffentlichte **SHA-512-Prüfsumme**
   und installiert sie nach `/usr/local/bin` (mit `--user` nach `~/.local/bin`, ohne sudo),
3. wählt die passende Variante automatisch (x64, ARM64, musl; ältere CPUs ohne AVX2 erhalten die Baseline-Version),
4. installiert Hadron Sync nach `~/.local/share/hadron-sync`, legt Menüeintrag, Symbole und den Befehl
   `hadron-sync` an,
5. fragt nach Autostart und bietet die Anmeldung bei Proton an (Browser).

Vorher zeigt der Installer den obigen Hinweis und installiert erst nach deiner Bestätigung
(ohne Rückfrage: `--yes`, das gilt dann als Bestätigung).

Nicht als root ausführen – das Werkzeug wird für deinen Benutzer eingerichtet.

**Aktualisieren:** `./install.sh` aus einer neueren Paketversion erneut ausführen. Die CLI wird nur
heruntergeladen, wenn es eine neue Version gibt. Ordnerpaare, Einstellungen und Sync-Stand bleiben erhalten;
ein laufendes Hadron Sync wird beendet und neu gestartet.

### Optionen

| Option | Wirkung |
|---|---|
| `--user` | CLI nach `~/.local/bin` statt `/usr/local/bin` (kein sudo nötig) |
| `--no-deps` | keine Systempakete installieren |
| `--skip-cli` | CLI nicht installieren/aktualisieren |
| `--force` | CLI auch bei gleicher Version neu laden |
| `--autostart` / `--no-autostart` | Autostart beim Anmelden ein/aus |
| `--no-login`, `--no-start` | keine Anmeldung anbieten / nicht starten |
| `-y`, `--yes` | alle Rückfragen mit Ja beantworten |

## Erste Schritte

Beim ersten Start führt ein **Assistent** durch die Einrichtung: Hinweis, Proton-Anmeldung, erstes Ordnerpaar,
Autostart/Intervall. Findet er Einstellungen einer früheren Installation, kannst du sie übernehmen oder komplett neu
einrichten (dabei bleiben deine Dateien in jedem Fall erhalten, verworfen werden nur Einstellungen und Sync-Stand).

Das Hauptfenster zeigt Logo, einen farbigen Fortschrittsbalken mit geschätzter Restzeit und ein farblich
hervorgehobenes Protokoll (Fehler rot, Uploads blau, Downloads violett, Konflikte orange). Alle Grundeinstellungen –
Ordnerpaare, Ausschlüsse, CLI-Pfad, Sprache, Autostart, Sofort-Sync, Vorschaubilder, Intervall und gleichzeitige
Abfragen – stehen im eigenen Fenster **Einstellungen …**. Mit „Speichern & anwenden“ gelten sie sofort; läuft gerade
ein Abgleich, kann er auf Rückfrage direkt mit den neuen Werten neu gestartet werden.

**Tray-Symbol:** Lila = bereit, gelb = liest/vergleicht Dateien, blau = lädt gerade tatsächlich hoch oder herunter,
rot = Fehler. Das blaue Sync-Symbol erscheint also wirklich nur während einer echten Übertragung. Nach einem
abgeschlossenen Abgleich mit Änderungen erscheint zusätzlich eine kurze Benachrichtigung.

**Speicheranzeige:** Die CLI liefert kein Konto-Kontingent. Angezeigt wird der belegte Platz der abgeglichenen Ordner
aus dem letzten Abgleich; trägst du dein Kontingent in den Einstellungen ein, wird daraus ein Balken mit Prozentwert.

1. Hadron Sync aus dem Anwendungsmenü starten (oder `hadron-sync`).
2. **Hinzufügen …**: lokalen Ordner und Ordner in Proton Drive wählen.
3. Erst **Trockenlauf** – das Protokoll zeigt, was passieren würde. Dann **Speichern & anwenden**.

## Entfernen

```
~/.local/share/hadron-sync/uninstall.sh
```

Entfernt Programm, Menüeintrag, Autostart und Symbole. Auf Rückfrage (oder mit `--purge`, `--logout`,
`--remove-cli`) auch Einstellungen, die Proton-Anmeldung und die CLI. **Synchronisierte Dateien werden nie gelöscht.**

## Systemvoraussetzungen

- Ausgelegt für Debian/Ubuntu-basierte Systeme (Zorin OS, Ubuntu, Mint, Debian). Der Installer wurde unter
  Ubuntu 24.04 mit simulierter CLI getestet, noch nicht auf einer echten Desktop-Installation. Für Fedora, Arch und
  openSUSE sind die Paketnamen hinterlegt, aber **nicht getestet**.
- Für das Tray-Symbol braucht GNOME eine AppIndicator-Erweiterung (Ubuntu und Zorin OS bringen eine mit).
- Die Proton-Anmeldung liegt im Schlüsselbund (GNOME Keyring). Bei automatischer Anmeldung am Rechner ohne Passwort
  bleibt der Schlüsselbund gesperrt – dann muss man sich in Hadron Sync ggf. neu anmelden.

## Wichtige Hinweise

- Geprüft gegen die Befehle von **cli-drive 0.7.0 und 0.8.0** (0.8.0 kennt die Kurzoption `-c` nicht mehr). Der Installer holt immer die neueste CLI
  (derzeit 0.8.0). Ändert Proton das Verhalten der CLI, kann das den Abgleich beeinflussen – nach einem CLI-Update
  daher zuerst einen **Trockenlauf** machen.
- Lässt sich für eine Datei kein Vorschaubild erzeugen (z. B. eine `.PNG`, die kein PNG ist), lädt Hadron Sync sie
  automatisch ohne Vorschaubild hoch. In den Einstellungen lassen sich Vorschaubilder auch ganz abschalten – das
  beschleunigt das Hochladen vieler Bilder, dafür zeigt Proton Drive dann keine Vorschau.
- Dateinamen mit `[` `]` `*` `?` werden beim Hochladen maskiert, weil die CLI sie sonst als Suchmuster liest.
- Die Proton-CLI ersetzt beim Herunterladen Zeichen wie `"` `:` `*` `?` `<` `>` `|` durch `_`. Hadron Sync stellt den
  Originalnamen danach wieder her. Unterscheiden sich zwei Dateien in Proton Drive nur in einem solchen Zeichen, kann
  eine davon lokal nicht angelegt werden; sie wird als Fehler gemeldet.
- Löschungen gehen immer in den Papierkorb (lokal bzw. Proton Drive), nie endgültig. Bei Konflikten bleiben beide
  Versionen erhalten (`Name (Konflikt …).ext`).

## Dateien und Datenschutz

| Pfad | Inhalt | Rechte |
|---|---|---|
| `~/.config/hadron-sync/` | Einstellungen, Sync-Stand je Ordnerpaar | 700 / 600 |
| `~/.local/state/hadron-sync/sync.log` | Protokoll (Dateinamen; Login-Links werden geschwärzt) | 600 |
| `<Sync-Ordner>/.hadron-sync-tmp` | kurzzeitig: laufende Downloads | 700 |

Passwörter und Sitzungsschlüssel speichert Hadron Sync nicht – die verwaltet die Proton-CLI im Schlüsselbund.

## Tests

```
python3 tests/run_tests.py
```

Installer und Deinstallation sprechen Deutsch, Englisch, Spanisch und Französisch (nach Systemsprache, sonst
Englisch); die Texte stehen in `messages.sh`.

Läuft vollständig offline gegen eine simulierte CLI und einen simulierten Download-Index; verändert weder deine
Ordner noch Proton Drive (arbeitet nur in `/tmp/hadron-sync-test`). Die Installer-Tests brauchen einen normalen
Benutzer (nicht root).
